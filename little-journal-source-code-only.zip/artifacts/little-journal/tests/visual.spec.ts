import { expect, test, type Page } from '@playwright/test';

type Surface = {
  id: string;
  label: string;
  path: string;
  ready: (page: Page) => Promise<void>;
};

const surfaces: Surface[] = [
  {
    id: 'landing',
    label: 'landing page',
    path: '/',
    ready: async (page) => {
      await expect(
        page.getByRole('heading', { name: /Your memories deserve/i }),
      ).toBeVisible();
    },
  },
  {
    id: 'onboarding',
    label: 'guest onboarding',
    path: '/onboarding?demo=1',
    ready: async (page) => {
      await expect(
        page.getByRole('heading', { name: /Choose the journal that feels like yours/i }),
      ).toBeVisible();
    },
  },
  {
    id: 'editor',
    label: 'guest editor',
    path: '/journal?demo=1',
    ready: async (page) => {
      await expect(page.locator('.journal-flipbook-page').first()).toBeVisible();
      await expect(page.getByText('Saved', { exact: true })).toBeVisible();
    },
  },
  {
    id: 'auth-shell',
    label: 'auth shell',
    path: '/sign-in',
    ready: async (page) => {
      await expect(page.locator('.auth-shell')).toBeVisible();
      await expect(page.locator('.auth-intro__eyebrow')).toHaveText(
        'A quiet place for your memories',
      );
    },
  },
  {
    id: 'not-found',
    label: '404 screen',
    path: '/visual-regression-missing',
    ready: async (page) => {
      await expect(
        page.getByRole('heading', { name: /This page slipped out of the journal/i }),
      ).toBeVisible();
    },
  },
];

async function assertHealthySurface(page: Page, surface: Surface) {
  const consoleErrors: string[] = [];
  const pageErrors: string[] = [];

  page.on('console', (message) => {
    if (message.type() === 'error') {
      consoleErrors.push(message.text());
    }
  });
  page.on('pageerror', (error) => {
    pageErrors.push(error.message);
  });

  await page.goto(surface.path, { waitUntil: 'domcontentloaded' });
  await surface.ready(page);

  await page.evaluate(async () => {
    await document.fonts?.ready;
    const images = Array.from(document.images);
    await Promise.all(
      images.map(
        (image) =>
          image.complete
            ? Promise.resolve()
            : new Promise<void>((resolve) => {
                image.addEventListener('load', () => resolve(), { once: true });
                image.addEventListener('error', () => resolve(), { once: true });
              }),
      ),
    );
  });

  const brokenImages = await page.locator('img').evaluateAll((images) =>
    images
      .filter((image) => !image.complete || image.naturalWidth === 0)
      .map((image) => image.getAttribute('src') || image.getAttribute('alt') || '<unnamed image>'),
  );
  expect(brokenImages, `${surface.label} contains broken images`).toEqual([]);

  const overflow = await page.evaluate(() => ({
    clientWidth: document.documentElement.clientWidth,
    scrollWidth: document.documentElement.scrollWidth,
  }));
  expect(
    overflow.scrollWidth,
    `${surface.label} has horizontal overflow (${overflow.scrollWidth}px > ${overflow.clientWidth}px)`,
  ).toBeLessThanOrEqual(overflow.clientWidth + 1);

  expect(consoleErrors, `${surface.label} logged browser console errors`).toEqual([]);
  expect(pageErrors, `${surface.label} threw page errors`).toEqual([]);
}

for (const surface of surfaces) {
  test(`${surface.label} stays visually stable`, async ({ page }, testInfo) => {
    await assertHealthySurface(page, surface);

    await expect(page).toHaveScreenshot(`${surface.id}-${testInfo.project.name}.png`, {
      animations: 'disabled',
      caret: 'hide',
      fullPage: true,
      maxDiffPixelRatio: 0.015,
      maxDiffPixels: surface.id === 'editor' ? 5000 : 3000,
      scale: 'css',
    });
  });
}