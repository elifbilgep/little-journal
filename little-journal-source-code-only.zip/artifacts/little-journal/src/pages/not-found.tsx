import { ArrowLeft, BookDashed } from 'lucide-react';
import { Link } from 'wouter';

export default function NotFound() {
  return (
    <main className="flex min-h-[100dvh] w-full items-center justify-center bg-[var(--lj-mist)] p-6">
      <section className="relative w-full max-w-xl overflow-hidden rounded-[24px] border border-[var(--lj-line)] bg-white p-8 text-center shadow-[var(--lj-shadow-card)] md:p-12">
        <div className="absolute inset-0 opacity-30 [background-image:linear-gradient(rgba(16,16,16,.06)_1px,transparent_1px),linear-gradient(90deg,rgba(16,16,16,.06)_1px,transparent_1px)] [background-size:30px_30px]" aria-hidden="true" />
        <div className="relative">
          <div className="mx-auto mb-6 grid h-12 w-12 place-items-center rounded-xl bg-[var(--lj-black)] text-white">
            <BookDashed size={22} strokeWidth={1.8} aria-hidden="true" />
          </div>
          <p className="text-[10px] font-bold uppercase tracking-[0.26em] text-[var(--lj-blue)]">404 / Missing page</p>
          <h1 className="mt-3 font-sans text-4xl font-extrabold tracking-[-0.06em] text-[var(--lj-black)] md:text-5xl">
            This page slipped out of the journal.
          </h1>
          <p className="mx-auto mt-4 max-w-sm text-sm leading-6 text-[var(--lj-muted)]">
            The page may have moved, or the link may no longer be part of this journal.
          </p>
          <Link
            href="/"
            className="mt-7 inline-flex items-center gap-2 rounded-[var(--lj-control-radius)] border border-[var(--lj-black)] bg-[var(--lj-black)] px-5 py-3 text-[11px] font-bold text-white transition hover:-translate-y-0.5 hover:bg-white hover:text-[var(--lj-black)] focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-[var(--lj-blue)]/60"
          >
            <ArrowLeft size={14} aria-hidden="true" />
            Back to Little Journal
          </Link>
        </div>
      </section>
    </main>
  );
}
