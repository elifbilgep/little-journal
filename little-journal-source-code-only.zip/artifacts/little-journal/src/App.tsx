import { type ReactNode, useEffect, useState } from 'react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter, Redirect } from 'wouter';
import { RotateCw } from 'lucide-react';
import JournalHome from '@/components/journal/JournalHome';
import JournalApp from '@/components/journal/JournalApp';
import Onboarding from '@/components/journal/Onboarding';
import { JOURNAL_COVERS, PAGE_STYLES } from '@/lib/constants';
import { loadLocalJournal, saveLocalJournal } from '@/lib/local-journal-db';
import { createInitialJournalPages, ensureJournalPageSpread } from '@/lib/journal-pages';
import type { Journal } from '@/lib/types';

function LoadingJournal() {
  return <div className="flex min-h-[100dvh] items-center justify-center bg-[var(--lj-mist)]"><div className="h-9 w-9 animate-spin rounded-full border-2 border-[var(--lj-black)] border-t-transparent" /></div>;
}

function JournalLoadError({ error }: { error: Error }) {
  return <div className="flex min-h-[100dvh] items-center justify-center bg-[var(--lj-mist)] px-6 text-center"><div><h1 className="font-sans text-3xl font-extrabold tracking-[-0.06em] text-[var(--lj-black)]">We could not open your local journal.</h1><p className="mt-3 text-sm text-[var(--lj-muted)]">{error.message}</p></div></div>;
}

function useLocalJournal() {
  const [state, setState] = useState<{ journal: Journal | null; error: Error | null; loaded: boolean }>({ journal: null, error: null, loaded: false });
  useEffect(() => {
    void loadLocalJournal()
      .then(async (storedJournal) => {
        if (!storedJournal) {
          setState({ journal: null, error: null, loaded: true });
          return;
        }

        const journal = ensureJournalPageSpread(storedJournal);
        if (journal !== storedJournal) {
          await saveLocalJournal(journal);
        }
        setState({ journal, error: null, loaded: true });
      })
      .catch(error => setState({ journal: null, error: error instanceof Error ? error : new Error('Unable to read local storage.'), loaded: true }));
  }, []);
  return state;
}

function JournalRoute() {
  const { journal, error, loaded } = useLocalJournal();
  if (!loaded) return <LoadingJournal />;
  if (error) return <JournalLoadError error={error} />;
  if (!journal) return <Redirect to="/onboarding" />;
  return <JournalApp initialJournal={journal} />;
}

function OnboardingRoute() {
  const [, setLocation] = useLocation();
  const { journal, error, loaded } = useLocalJournal();
  if (!loaded) return <LoadingJournal />;
  if (error) return <JournalLoadError error={error} />;
  if (journal) return <Redirect to="/journal" />;

  const handleComplete = async (coverStyle: string, pageStyle: string) => {
    const validCover = JOURNAL_COVERS.some(cover => cover.id === coverStyle) ? coverStyle : JOURNAL_COVERS[0].id;
    const validPageStyle = PAGE_STYLES.some(style => style.id === pageStyle) ? pageStyle : 'lined';
    const now = new Date().toISOString();
    await saveLocalJournal({
      id: 0,
      title: 'My Little Journal',
      coverStyle: validCover,
      createdAt: now,
      updatedAt: now,
      pages: createInitialJournalPages(validPageStyle),
    });
    setLocation('/journal');
  };
  return <Onboarding onComplete={handleComplete} onBack={() => setLocation('/')} />;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function LandscapeOnly({ children }: { children: ReactNode }) {
  return <div className="landscape-guard"><div className="landscape-guard__app">{children}</div><div className="landscape-guard__lock" role="status" aria-live="polite"><div className="landscape-guard__card"><div className="landscape-guard__icon" aria-hidden="true"><div className="landscape-guard__phone" /><RotateCw size={22} strokeWidth={1.8} /></div><p className="landscape-guard__eyebrow">LITTLE JOURNAL</p><h1>Turn your device sideways</h1><p>Little Journal is designed for landscape screens.</p></div></div></div>;
}

function App() {
  return <TooltipProvider><LandscapeOnly><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><RoutedErrorBoundary><Switch><Route path="/" component={JournalHome} /><Route path="/journal" component={JournalRoute} /><Route path="/onboarding" component={OnboardingRoute} /><Route component={NotFound} /></Switch></RoutedErrorBoundary></WouterRouter><Toaster /></LandscapeOnly></TooltipProvider>;
}

export default App;