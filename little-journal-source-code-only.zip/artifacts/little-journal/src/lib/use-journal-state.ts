import { useState, useCallback, useRef, useEffect } from 'react';
import { Journal, JournalPage, JournalElement } from './types';
import { saveLocalJournal } from './local-journal-db';
import { createBlankJournalPage, ensureJournalPageSpread } from './journal-pages';

type HistoryState = {
  past: Journal[];
  present: Journal | null;
  future: Journal[];
};

type JournalSave = Journal;

export function isElementOffscreen(element: JournalElement) {
  const angle = (element.rotation * Math.PI) / 180;
  const halfWidth = element.width / 2;
  const halfHeight = element.height / 2;
  const centerX = element.x + halfWidth;
  const centerY = element.y + halfHeight;
  const extentX = Math.abs(Math.cos(angle)) * halfWidth + Math.abs(Math.sin(angle)) * halfHeight;
  const extentY = Math.abs(Math.sin(angle)) * halfWidth + Math.abs(Math.cos(angle)) * halfHeight;

  return (
    centerX + extentX <= 0 ||
    centerX - extentX >= 100 ||
    centerY + extentY <= 0 ||
    centerY - extentY >= 100
  );
}

export function useJournalState(
  initialJournal: Journal | null,
  options: { localPersistence?: boolean; persistenceEnabled?: boolean } = {},
) {
  const localPersistence = options.localPersistence ?? false;
  const persistenceEnabled = options.persistenceEnabled ?? localPersistence;
  const [history, setHistory] = useState<HistoryState>({
    past: [],
    present: initialJournal,
    future: [],
  });

  const [activePageIndex, setActivePageIndex] = useState(0);
  const [selectedElementId, setSelectedElementId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState<Error | null>(null);
  const historyRef = useRef(history);
  const saveTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const latestSaveRef = useRef<JournalSave | null>(null);
  const saveInFlightRef = useRef(false);
  const isMountedRef = useRef(true);
  const saveLatestSnapshot = useCallback(async () => {
    if (!persistenceEnabled || saveInFlightRef.current || !latestSaveRef.current) return;

    const snapshot = latestSaveRef.current;
    let saved = false;
    latestSaveRef.current = null;
    saveInFlightRef.current = true;

    try {
      if (!localPersistence) {
        throw new Error('Local persistence is required to save this journal.');
      }
      await saveLocalJournal(snapshot);
      saved = true;
      if (isMountedRef.current) setSaveError(null);
    } catch (error) {
      // A newer edit supersedes this failed snapshot, otherwise leave it queued for Retry.
      latestSaveRef.current ??= snapshot;
      if (isMountedRef.current) {
        setSaveError(error instanceof Error ? error : new Error('Unable to save journal.'));
      }
    } finally {
      saveInFlightRef.current = false;
    }

    if (saved && latestSaveRef.current) {
      void saveLatestSnapshot();
    } else if (isMountedRef.current) {
      setIsSaving(false);
    }
  }, [localPersistence, persistenceEnabled]);

  const scheduleSave = useCallback((journal: Journal, delay = 1000) => {
    if (!persistenceEnabled) return;

    latestSaveRef.current = {
      ...journal,
      updatedAt: new Date().toISOString(),
    };
    if (isMountedRef.current) {
      setIsSaving(true);
      setSaveError(null);
    }
    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    saveTimeoutRef.current = setTimeout(() => {
      saveTimeoutRef.current = null;
      void saveLatestSnapshot();
    }, delay);
  }, [persistenceEnabled, saveLatestSnapshot]);

  const retrySave = useCallback(() => {
    if (!latestSaveRef.current || !persistenceEnabled) return;
    if (isMountedRef.current) {
      setSaveError(null);
      setIsSaving(true);
    }
    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    saveTimeoutRef.current = null;
    void saveLatestSnapshot();
  }, [persistenceEnabled, saveLatestSnapshot]);

  // Guard initialization
  const initializedId = useRef<number | null>(null);
  useEffect(() => {
    if (initialJournal && initializedId.current !== initialJournal.id) {
      initializedId.current = initialJournal.id;
      const nextHistory = { ...historyRef.current, present: initialJournal };
      historyRef.current = nextHistory;
      setHistory(nextHistory);
    }
  }, [initialJournal]);

  const commitChange = useCallback((newJournal: Journal) => {
    const current = historyRef.current;
    if (!current.present) return;
    const nextHistory = {
      past: [...current.past, current.present].slice(-20),
      present: newJournal,
      future: [],
    };
    historyRef.current = nextHistory;
    setHistory(nextHistory);
    scheduleSave(newJournal);
  }, [scheduleSave]);

  const undo = useCallback(() => {
    const current = historyRef.current;
    if (current.past.length === 0 || !current.present) return;
    const previous = current.past[current.past.length - 1];
    const nextHistory = {
      past: current.past.slice(0, current.past.length - 1),
      present: previous,
      future: [current.present, ...current.future],
    };
    historyRef.current = nextHistory;
    setHistory(nextHistory);
    scheduleSave(previous);
  }, [scheduleSave]);

  const redo = useCallback(() => {
    const current = historyRef.current;
    if (current.future.length === 0 || !current.present) return;
    const next = current.future[0];
    const nextHistory = {
      past: [...current.past, current.present],
      present: next,
      future: current.future.slice(1),
    };
    historyRef.current = nextHistory;
    setHistory(nextHistory);
    scheduleSave(next);
  }, [scheduleSave]);

  useEffect(() => {
    isMountedRef.current = true;
    const flushPendingSave = () => {
      if (!persistenceEnabled || !latestSaveRef.current) return;
      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
      saveTimeoutRef.current = null;
      void saveLatestSnapshot();
    };

    window.addEventListener('pagehide', flushPendingSave);
    return () => {
      isMountedRef.current = false;
      window.removeEventListener('pagehide', flushPendingSave);
      flushPendingSave();
      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    };
  }, [persistenceEnabled, saveLatestSnapshot]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z') {
        if (e.shiftKey) {
          e.preventDefault();
          redo();
        } else {
          e.preventDefault();
          undo();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [undo, redo]);

  const journal = history.present;

  const updatePage = useCallback((pageId: string, updater: (page: JournalPage) => JournalPage) => {
    if (!journal) return;
    const newPages = journal.pages.map(p => p.id === pageId ? updater(p) : p);
    commitChange({ ...journal, pages: newPages });
  }, [journal, commitChange]);

  const updateElement = useCallback((pageId: string, elementId: string, updater: (el: JournalElement) => JournalElement) => {
    updatePage(pageId, page => ({
      ...page,
      elements: page.elements.map(e => e.id === elementId ? updater(e) : e)
    }));
  }, [updatePage]);

  const moveElementToPage = useCallback((
    sourcePageId: string,
    targetPageId: string,
    elementId: string,
    updater: (el: JournalElement) => JournalElement,
  ) => {
    if (!journal || sourcePageId === targetPageId) return;

    const sourcePage = journal.pages.find(page => page.id === sourcePageId);
    const targetPage = journal.pages.find(page => page.id === targetPageId);
    const sourceElement = sourcePage?.elements.find(element => element.id === elementId);
    if (!sourcePage || !targetPage || !sourceElement) return;

    const targetMaxZ = Math.max(0, ...targetPage.elements.map(element => element.zIndex));
    const movedElement = {
      ...updater(sourceElement),
      zIndex: targetMaxZ + 1,
    };
    const newPages = journal.pages.map(page => {
      if (page.id === sourcePageId) {
        return {
          ...page,
          elements: page.elements.filter(element => element.id !== elementId),
        };
      }
      if (page.id === targetPageId) {
        return {
          ...page,
          elements: [...page.elements, movedElement],
        };
      }
      return page;
    });

    commitChange({ ...journal, pages: newPages });
    setSelectedElementId(elementId);
  }, [commitChange, journal]);

  const addElement = useCallback((pageId: string, element: Omit<JournalElement, 'id'>) => {
    const newElement: JournalElement = {
      ...element,
      id: `el-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };
    updatePage(pageId, page => ({
      ...page,
      elements: [...page.elements, newElement]
    }));
    setSelectedElementId(newElement.id);
  }, [updatePage]);

  const deleteElement = useCallback((pageId: string, elementId: string) => {
    updatePage(pageId, page => ({
      ...page,
      elements: page.elements.filter(e => e.id !== elementId)
    }));
    if (selectedElementId === elementId) {
      setSelectedElementId(null);
    }
  }, [updatePage, selectedElementId]);

  const bringToFront = useCallback((pageId: string, elementId: string) => {
    const page = journal?.pages.find(candidate => candidate.id === pageId);
    const selectedElement = page?.elements.find(element => element.id === elementId);
    const maxZ = Math.max(0, ...(page?.elements.map(element => element.zIndex) ?? []));
    if (!page || !selectedElement || selectedElement.zIndex >= maxZ) return;

    updatePage(pageId, page => {
      return {
        ...page,
        elements: page.elements.map(e => e.id === elementId ? { ...e, zIndex: maxZ + 1 } : e)
      };
    });
  }, [journal, updatePage]);

  const sendToBack = useCallback((pageId: string, elementId: string) => {
    updatePage(pageId, page => {
      const minZ = Math.min(1, ...page.elements.map(e => e.zIndex));
      return {
        ...page,
        elements: page.elements.map(e => e.id === elementId ? { ...e, zIndex: minZ - 1 } : e)
      };
    });
  }, [updatePage]);

  const bringElementIntoView = useCallback((pageId: string, elementId: string) => {
    updateElement(pageId, elementId, element => {
      const angle = (element.rotation * Math.PI) / 180;
      const halfWidth = element.width / 2;
      const halfHeight = element.height / 2;
      const extentX = Math.abs(Math.cos(angle)) * halfWidth + Math.abs(Math.sin(angle)) * halfHeight;
      const extentY = Math.abs(Math.sin(angle)) * halfWidth + Math.abs(Math.cos(angle)) * halfHeight;
      const visibleCenterX = Math.min(100 - extentX, Math.max(extentX, 50));
      const visibleCenterY = Math.min(100 - extentY, Math.max(extentY, 50));

      return {
        ...element,
        x: visibleCenterX - halfWidth,
        y: visibleCenterY - halfHeight,
      };
    });
  }, [updateElement]);

  const addPage = useCallback(() => {
    if (!journal) return;
    const pageStyle = journal.pages[activePageIndex]?.backgroundStyle
      ?? journal.pages[0]?.backgroundStyle
      ?? 'cream';
    const pagesToAdd = journal.pages.length % 2 === 0 ? 2 : 1;
    const newPages = Array.from({ length: pagesToAdd }, (_, index) =>
      createBlankJournalPage(journal.pages.length + index + 1, pageStyle),
    );
    const nextJournal = ensureJournalPageSpread({
      ...journal,
      pages: [...journal.pages, ...newPages],
    });
    commitChange(nextJournal);
    const firstNewPageIndex = journal.pages.length;
    setActivePageIndex(firstNewPageIndex % 2 === 0 ? firstNewPageIndex : firstNewPageIndex - 1);
  }, [activePageIndex, journal, commitChange]);

  const updateCover = useCallback((updates: Partial<Pick<Journal, 'title' | 'coverStyle'>>) => {
    if (!journal) return;
    commitChange({ ...journal, ...updates });
  }, [journal, commitChange]);

  return {
    journal,
    activePageIndex,
    setActivePageIndex,
    selectedElementId,
    setSelectedElementId,
    isSaving,
    saveError,
    retrySave,
    updateElement,
    moveElementToPage,
    addElement,
    deleteElement,
    updatePage,
    addPage,
    updateCover,
    bringToFront,
    sendToBack,
    bringElementIntoView,
    undo,
    redo,
    canUndo: history.past.length > 0,
    canRedo: history.future.length > 0
  };
}
