const LAST_SESSION_KEY = 'little-journal:last-session-id';
const LAST_OPENED_KEY = 'little-journal:last-opened-at';
const CLOSE_AFTER_MS = 6 * 60 * 60 * 1000;

export function shouldJournalStartClosed(sessionId?: string | null): boolean {
  if (!sessionId) return true;

  const lastSessionId = window.localStorage.getItem(LAST_SESSION_KEY);
  const lastOpenedAt = Number(window.localStorage.getItem(LAST_OPENED_KEY));
  const sessionChanged = lastSessionId !== sessionId;
  const wasAwayTooLong = !Number.isFinite(lastOpenedAt)
    || Date.now() - lastOpenedAt > CLOSE_AFTER_MS;

  return sessionChanged || wasAwayTooLong;
}

export function markJournalOpened(sessionId?: string | null): void {
  if (!sessionId) return;

  window.localStorage.setItem(LAST_SESSION_KEY, sessionId);
  window.localStorage.setItem(LAST_OPENED_KEY, String(Date.now()));
}