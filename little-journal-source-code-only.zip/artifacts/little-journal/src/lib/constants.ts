export const STICKERS = [
  { id: 'heart', path: 'M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z' },
  { id: 'star', path: 'M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z' },
  { id: 'flower', path: 'M12 2c1.1 0 2 .9 2 2 0 .5-.2.9-.5 1.2.7.2 1.4.6 2 1.1.9-.9 2.3-.9 3.2 0s.9 2.3 0 3.2c.5.6.9 1.3 1.1 2 .3-.3.7-.5 1.2-.5 1.1 0 2 .9 2 2s-.9 2-2 2c-.5 0-.9-.2-1.2-.5-.2.7-.6 1.4-1.1 2 .9.9.9 2.3 0 3.2s-2.3.9-3.2 0c-.6.5-1.3.9-2 1.1.3.3.5.7.5 1.2 0 1.1-.9 2-2 2s-2-.9-2-2c0-.5.2-.9.5-1.2-.7-.2-1.4-.6-2-1.1-.9.9-2.3.9-3.2 0s-.9-2.3 0-3.2c-.5-.6-.9-1.3-1.1-2-.3.3-.7.5-1.2.5-1.1 0-2-.9-2-2s.9-2 2-2c.5 0 .9.2 1.2.5.2-.7.6-1.4 1.1-2-.9-.9-.9-2.3 0-3.2s2.3-.9 3.2 0c.6-.5 1.3-.9 2-1.1-.3-.3-.5-.7-.5-1.2 0-1.1.9-2 2-2zM12 9c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z' },
  { id: 'tape', path: 'M2 8 l 4 -2 l 4 2 l 4 -2 l 4 2 l 4 -2 v 12 l -4 2 l -4 -2 l -4 2 l -4 -2 l -4 2 z', isFill: true, color: '#f5f0eb', opacity: 0.8 },
  { id: 'smiley', path: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5c-2.33 0-4.31-1.46-5.11-3.5h10.22c-.8 2.04-2.78 3.5-5.11 3.5zM8.5 11C7.67 11 7 10.33 7 9.5S7.67 8 8.5 8 10 8.67 10 9.5 9.33 11 8.5 11zm7 0c-.83 0-1.5-.67-1.5-1.5S14.67 8 15.5 8s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z' },
  { id: 'sparkles', path: 'M11.5,1.5 L12.5,8 L19,9 L12.5,10 L11.5,16.5 L10.5,10 L4,9 L10.5,8 Z M6,14 L6.5,16.5 L9,17 L6.5,17.5 L6,20 L5.5,17.5 L3,17 L5.5,16.5 Z', color: '#ffb74d' },
  { id: 'cloud', path: 'M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96z', color: '#e3f2fd' },
  { id: 'arrow', path: 'M2 12l10-10v6h10v8H12v6z', color: '#8c7a70' },
  { id: 'cherry', path: 'M18 10c0-3.31-2.69-6-6-6s-6 2.69-6 6c0 1.25.39 2.41 1.05 3.35L5.71 18H2v2h11v-2H9.29l1.45-4.8c.4.19.82.3 1.26.3 3.31 0 6-2.69 6-6zm-6 4c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4z', color: '#ef5350' },
  { id: 'moon', name: 'Moon', path: 'M20.5 15.4A9 9 0 0 1 8.6 3.5 9.5 9.5 0 1 0 20.5 15.4z', color: '#7c6fca' },
  { id: 'sun', name: 'Sun', path: 'M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10zM11 1h2v4h-2zM11 19h2v4h-2zM1 11h4v2H1zM19 11h4v2h-4zM3.5 4.9l1.4-1.4 2.8 2.8-1.4 1.4zM16.3 17.7l1.4-1.4 2.8 2.8-1.4 1.4zM3.5 19.1l2.8-2.8 1.4 1.4-2.8 2.8zM16.3 6.3l2.8-2.8 1.4 1.4-2.8 2.8z', color: '#f6b93b' },
  { id: 'lightning', name: 'Lightning', path: 'M13 2 3 14h8l-1 8 11-13h-8z', color: '#f2c94c' },
  { id: 'butterfly', name: 'Butterfly', path: 'M11 11C8 4 2 3 2 8c0 3 3 5 7 5-4 1-6 4-4 7 2 2 5-2 7-6 2 4 5 8 7 6 2-3 0-6-4-7 4 0 7-2 7-5 0-5-6-4-9 3z', color: '#a783d6' },
  { id: 'music', name: 'Music Note', path: 'M9 3v12.3A4 4 0 1 0 11 19V8h8v5.3A4 4 0 1 0 21 17V3z', color: '#4b74ff' },
  { id: 'camera', name: 'Camera', path: 'M4 6h3l2-3h6l2 3h3a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2zm8 3a5 5 0 1 0 0 10 5 5 0 0 0 0-10zm0 2a3 3 0 1 1 0 6 3 3 0 0 1 0-6z', color: '#59616d' },
  { id: 'paw', name: 'Paw', path: 'M12 13c-3.5 0-6 2.6-6 5.1C6 20.5 8.2 22 12 22s6-1.5 6-3.9C18 15.6 15.5 13 12 13zM5.5 7C3.9 7 3 8.3 3 10s.9 3 2.5 3S8 11.7 8 10 7.1 7 5.5 7zm13 0C16.9 7 16 8.3 16 10s.9 3 2.5 3 2.5-1.3 2.5-3-.9-3-2.5-3zM9 2C7.4 2 6.5 3.3 6.5 5S7.4 8 9 8s2.5-1.3 2.5-3S10.6 2 9 2zm6 0c-1.6 0-2.5 1.3-2.5 3S13.4 8 15 8s2.5-1.3 2.5-3S16.6 2 15 2z', color: '#9a6b55' },
  { id: 'leaf', name: 'Leaf', path: 'M21 3C12 3 5 7 4 15c-.2 1.7.4 3.2 1.5 4.3L3 22l1.4 1.4 2.7-2.7C8.1 21.5 9.5 22 11 22c8 0 10-10 10-19zM8 18c2-4 5-7 10-10-3 4-6 7-10 10z', color: '#67a36f' },
  { id: 'crown', name: 'Crown', path: 'M3 6l5 4 4-7 4 7 5-4-2 13H5zm2.5 11h13l.6-4-3.6 2.5L12 9l-3.5 6.5L4.9 13z', color: '#d9a928' },
  { id: 'diamond', name: 'Diamond', path: 'M6 3h12l4 6-10 13L2 9zm1 2L4.5 9H9zm3 0 2 4 2-4zm7 0-2 4h4.5zM5.5 11 10 17l-2-6zm4.5 0 2 7 2-7zm6 0-2 6 4.5-6z', color: '#62b6cb' },
  { id: 'bow', name: 'Bow', path: 'M11 9C8 5 3 3 2 7c-1 4 4 5 8 4-3 2-6 6-4 9 2 2 5-2 6-7 1 5 4 9 6 7 2-3-1-7-4-9 4 1 9 0 8-4-1-4-6-2-9 2z', color: '#e98aaa' },
  { id: 'coffee', name: 'Coffee', path: 'M3 5h14v3h2a4 4 0 0 1 0 8h-2v1a5 5 0 0 1-5 5H8a5 5 0 0 1-5-5zm14 5v4h2a2 2 0 0 0 0-4zM6 1h2v3H6zm4 0h2v3h-2zm4 0h2v3h-2z', color: '#8c5a3c' },
];

export const STICKER_COLORS = [
  '#101010',
  '#ffffff',
  '#e5484d',
  '#e54872',
  '#e98aaa',
  '#ff9f43',
  '#f2c94c',
  '#67a36f',
  '#45a6a6',
  '#4b74ff',
  '#7c6fca',
  '#9a6b55',
];

export const PAGE_STYLES = [
  { id: 'cream', name: 'Plain Cream' },
  { id: 'lined', name: 'Lined Notebook' },
  { id: 'grid', name: 'Grid Paper' },
  { id: 'pink', name: 'Soft Pink' },
  { id: 'sage', name: 'Sage Green' },
  { id: 'kraft', name: 'Kraft Paper' },
  { id: 'dot', name: 'Dotted Journal' },
];

export const JOURNAL_COVERS = [
  { id: 'studio-scrap-journal-cover-11.png', name: 'Pink Plaid', src: 'studio-scrap-journal-cover-11.png' },
  { id: 'studio-scrap-journal-cover-12.png', name: 'Pink Stars', src: 'studio-scrap-journal-cover-12.png' },
  { id: 'studio-scrap-journal-cover-13.png', name: 'Charcoal Dots', src: 'studio-scrap-journal-cover-13.png' },
  { id: 'studio-scrap-journal-cover-14.png', name: 'Mint Floral', src: 'studio-scrap-journal-cover-14.png' },
  { id: 'studio-scrap-journal-cover-15.png', name: 'Purple Plaid', src: 'studio-scrap-journal-cover-15.png' },
  { id: 'studio-scrap-journal-cover-16.png', name: 'Cream Cats', src: 'studio-scrap-journal-cover-16.png' },
  { id: 'studio-scrap-journal-cover-17.png', name: 'Black Dots', src: 'studio-scrap-journal-cover-17.png' },
  { id: 'studio-scrap-journal-cover-18.png', name: 'White Dots', src: 'studio-scrap-journal-cover-18.png' },
] as const;

const LEGACY_COVER_MAP: Record<string, string> = {
  cream: JOURNAL_COVERS[5].src,
  pink: JOURNAL_COVERS[0].src,
  sage: JOURNAL_COVERS[3].src,
  brown: JOURNAL_COVERS[1].src,
  navy: JOURNAL_COVERS[6].src,
};

export function getJournalCoverFilename(coverStyle?: string): string {
  if (coverStyle && JOURNAL_COVERS.some((cover) => cover.id === coverStyle)) {
    return coverStyle;
  }

  return LEGACY_COVER_MAP[coverStyle ?? ''] ?? JOURNAL_COVERS[0].src;
}

export const COVER_STYLES = [
  { id: 'cream', name: 'Cream' },
  { id: 'pink', name: 'Faded Pink' },
  { id: 'sage', name: 'Sage Green' },
  { id: 'brown', name: 'Soft Brown' },
  { id: 'navy', name: 'Dark Navy' },
];

export const FONTS = [
  { id: 'var(--app-font-handwriting)', name: 'Handwritten' },
  { id: 'var(--app-font-serif)', name: 'Serif' },
  { id: 'var(--app-font-sans)', name: 'Clean Sans' },
  { id: 'var(--app-font-mono)', name: 'Typewriter' },
];

export const COLORS = [
  '#101010', // Near Black
  '#4b74ff', // Cobalt Blue
  '#e5484d', // Red
  '#76767d', // Muted Gray
  '#2b3a4a', // Navy
  '#dedee3', // Light Gray
];
