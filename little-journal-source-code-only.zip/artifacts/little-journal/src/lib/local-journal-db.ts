import type { Journal } from './types';

const DATABASE_NAME = 'little-journal';
const DATABASE_VERSION = 1;
const JOURNAL_STORE = 'journals';
const CURRENT_JOURNAL_KEY = 'current';

function databaseError(action: string, error?: unknown): Error {
  const detail = error instanceof Error && error.message ? ` ${error.message}` : '';
  return new Error(`Local journal storage is unavailable while trying to ${action}.${detail}`);
}

function openDatabase(): Promise<IDBDatabase> {
  if (typeof indexedDB === 'undefined') {
    return Promise.reject(databaseError('open IndexedDB'));
  }

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains(JOURNAL_STORE)) {
        request.result.createObjectStore(JOURNAL_STORE);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(databaseError('open IndexedDB', request.error));
    request.onblocked = () => reject(databaseError('open IndexedDB because it is blocked'));
  });
}

export async function loadLocalJournal(): Promise<Journal | null> {
  const database = await openDatabase();
  try {
    return await new Promise<Journal | null>((resolve, reject) => {
      const transaction = database.transaction(JOURNAL_STORE, 'readonly');
      const request = transaction.objectStore(JOURNAL_STORE).get(CURRENT_JOURNAL_KEY);
      request.onsuccess = () => {
        if (request.result === undefined) return resolve(null);
        try {
          resolve(JSON.parse(request.result as string) as Journal);
        } catch (error) {
          reject(databaseError('read the saved journal', error));
        }
      };
      request.onerror = () => reject(databaseError('read the saved journal', request.error));
      transaction.onerror = () => reject(databaseError('read the saved journal', transaction.error));
    });
  } finally {
    database.close();
  }
}

export async function saveLocalJournal(journal: Journal): Promise<void> {
  let serialized: string;
  try {
    serialized = JSON.stringify(journal);
  } catch (error) {
    throw databaseError('serialize the journal', error);
  }
  const database = await openDatabase();
  try {
    await new Promise<void>((resolve, reject) => {
      const transaction = database.transaction(JOURNAL_STORE, 'readwrite');
      transaction.objectStore(JOURNAL_STORE).put(serialized, CURRENT_JOURNAL_KEY);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(databaseError('save the journal', transaction.error));
      transaction.onabort = () => reject(databaseError('save the journal', transaction.error));
    });
  } finally {
    database.close();
  }
}