export interface Journal {
  id: number;
  title: string;
  coverStyle: string;
  pages: JournalPage[];
  createdAt: string;
  updatedAt: string;
}

export interface JournalPage {
  id: string;
  pageNumber: number;
  backgroundStyle: string;
  elements: JournalElement[];
}

export type JournalElementType = 'photo' | 'text' | 'sticker';

export interface JournalElement {
  id: string;
  type: JournalElementType;
  x: number; // percentage 0-100
  y: number; // percentage 0-100
  width: number; // percentage
  height: number; // percentage
  rotation: number; // degrees
  zIndex: number;
  content: string; // text content, image URL, or sticker ID
  style: any; // specific styles (fontFamily, color, etc.)
}

const mockElement = (
  id: string,
  type: JournalElementType,
  content: string,
  layout: Pick<JournalElement, 'x' | 'y' | 'width' | 'height' | 'rotation'>,
  style: any = {},
  zIndex = 1,
): JournalElement => ({
  id,
  type,
  content,
  ...layout,
  zIndex,
  style,
});

export const createMockPages = (): JournalPage[] => [
  {
    id: "page-1",
    pageNumber: 1,
    backgroundStyle: "cream",
    elements: [
      mockElement("mock-1-photo", "photo", "demo:coffee", { x: 9, y: 9, width: 68, height: 46, rotation: -3 }),
      mockElement("mock-1-title", "text", "slow mornings + strong coffee", { x: 13, y: 67, width: 72, height: 14, rotation: -1 }, { fontFamily: "var(--app-font-handwriting)", fontSize: "1.65rem", color: "#665349" }, 2),
      mockElement("mock-1-tape", "sticker", "tape", { x: 70, y: 3, width: 18, height: 13, rotation: 8 }, {}, 3),
    ],
  },
  {
    id: "page-2",
    pageNumber: 2,
    backgroundStyle: "grid",
    elements: [
      mockElement("mock-2-title", "text", "A perfect afternoon", { x: 12, y: 8, width: 75, height: 14, rotation: -1 }, { fontFamily: "var(--app-font-serif)", fontSize: "2rem", color: "#33241d" }),
      mockElement("mock-2-scenery", "photo", "demo:scenery", { x: 33, y: 27, width: 52, height: 38, rotation: 4 }, {}, 2),
      mockElement("mock-2-abstract", "photo", "demo:abstract", { x: 8, y: 42, width: 37, height: 32, rotation: -4 }, {}, 3),
      mockElement("mock-2-star", "sticker", "star", { x: 68, y: 69, width: 16, height: 16, rotation: 12 }, { color: "#ffb74d" }, 4),
    ],
  },
  {
    id: "page-3",
    pageNumber: 3,
    backgroundStyle: "pink",
    elements: [
      mockElement("mock-3-title", "text", "little joys", { x: 14, y: 11, width: 70, height: 15, rotation: 2 }, { fontFamily: "var(--app-font-handwriting)", fontSize: "2.2rem", color: "#d16f80" }),
      mockElement("mock-3-note", "text", "fresh flowers, a song I love, and nowhere to rush", { x: 13, y: 33, width: 73, height: 22, rotation: -2 }, { fontFamily: "var(--app-font-sans)", fontSize: "1rem", color: "#665349" }, 2),
      mockElement("mock-3-flower", "sticker", "flower", { x: 69, y: 67, width: 19, height: 19, rotation: 10 }, { color: "#d16f80" }, 3),
      mockElement("mock-3-heart", "sticker", "heart", { x: 12, y: 69, width: 14, height: 14, rotation: -12 }, { color: "#d16f80" }, 4),
    ],
  },
  {
    id: "page-4",
    pageNumber: 4,
    backgroundStyle: "sage",
    elements: [
      mockElement("mock-4-photo", "photo", "demo:scenery", { x: 10, y: 12, width: 79, height: 43, rotation: 2 }),
      mockElement("mock-4-note", "text", "city walks / 17:42", { x: 14, y: 64, width: 65, height: 14, rotation: -2 }, { fontFamily: "var(--app-font-mono)", fontSize: "0.95rem", color: "#6d967b" }, 2),
      mockElement("mock-4-sparkles", "sticker", "sparkles", { x: 77, y: 69, width: 14, height: 14, rotation: 8 }, { color: "#ffb74d" }, 3),
    ],
  },
  {
    id: "page-5",
    pageNumber: 5,
    backgroundStyle: "lined",
    elements: [
      mockElement("mock-5-title", "text", "notes from today", { x: 12, y: 8, width: 75, height: 14, rotation: -1 }, { fontFamily: "var(--app-font-serif)", fontSize: "1.85rem", color: "#33241d" }),
      mockElement("mock-5-list", "text", "1. call grandma\n2. buy peaches\n3. keep the window open", { x: 14, y: 28, width: 70, height: 30, rotation: 1 }, { fontFamily: "var(--app-font-handwriting)", fontSize: "1.4rem", color: "#665349" }, 2),
      mockElement("mock-5-smiley", "sticker", "smiley", { x: 68, y: 72, width: 18, height: 18, rotation: 7 }, { color: "#b08d6a" }, 3),
    ],
  },
  {
    id: "page-6",
    pageNumber: 6,
    backgroundStyle: "kraft",
    elements: [
      mockElement("mock-6-title", "text", "weekend picnic", { x: 10, y: 9, width: 80, height: 14, rotation: -2 }, { fontFamily: "var(--app-font-handwriting)", fontSize: "2rem", color: "#665349" }),
      mockElement("mock-6-photo", "photo", "demo:abstract", { x: 17, y: 28, width: 64, height: 40, rotation: -5 }, {}, 2),
      mockElement("mock-6-tape", "sticker", "tape", { x: 39, y: 23, width: 20, height: 12, rotation: -4 }, {}, 3),
      mockElement("mock-6-heart", "sticker", "heart", { x: 76, y: 72, width: 13, height: 13, rotation: 15 }, { color: "#d16f80" }, 4),
    ],
  },
  {
    id: "page-7",
    pageNumber: 7,
    backgroundStyle: "dot",
    elements: [
      mockElement("mock-7-title", "text", "things worth remembering", { x: 10, y: 10, width: 80, height: 15, rotation: 1 }, { fontFamily: "var(--app-font-serif)", fontSize: "1.55rem", color: "#33241d" }),
      mockElement("mock-7-note", "text", "the smell after rain\nwarm bread in paper bags\nlaughing until midnight", { x: 15, y: 31, width: 68, height: 29, rotation: -2 }, { fontFamily: "var(--app-font-handwriting)", fontSize: "1.35rem", color: "#665349" }, 2),
      mockElement("mock-7-star", "sticker", "star", { x: 78, y: 68, width: 14, height: 14, rotation: -10 }, { color: "#ffb74d" }, 3),
    ],
  },
  {
    id: "page-8",
    pageNumber: 8,
    backgroundStyle: "pink",
    elements: [
      mockElement("mock-8-photo", "photo", "demo:scenery", { x: 12, y: 12, width: 76, height: 45, rotation: 3 }),
      mockElement("mock-8-note", "text", "the sky turned cotton-candy pink", { x: 17, y: 66, width: 67, height: 14, rotation: -2 }, { fontFamily: "var(--app-font-handwriting)", fontSize: "1.45rem", color: "#d16f80" }, 2),
      mockElement("mock-8-heart", "sticker", "heart", { x: 78, y: 6, width: 14, height: 14, rotation: 12 }, { color: "#d16f80" }, 3),
    ],
  },
  {
    id: "page-9",
    pageNumber: 9,
    backgroundStyle: "grid",
    elements: [
      mockElement("mock-9-title", "text", "dear future me", { x: 11, y: 9, width: 78, height: 15, rotation: -1 }, { fontFamily: "var(--app-font-serif)", fontSize: "1.9rem", color: "#33241d" }),
      mockElement("mock-9-note", "text", "I hope you still make room for small beautiful things.", { x: 13, y: 31, width: 73, height: 18, rotation: 2 }, { fontFamily: "var(--app-font-handwriting)", fontSize: "1.5rem", color: "#665349" }, 2),
      mockElement("mock-9-photo", "photo", "demo:coffee", { x: 29, y: 55, width: 49, height: 31, rotation: -3 }, {}, 3),
      mockElement("mock-9-flower", "sticker", "flower", { x: 9, y: 69, width: 16, height: 16, rotation: -8 }, { color: "#d16f80" }, 4),
    ],
  },
  {
    id: "page-10",
    pageNumber: 10,
    backgroundStyle: "cream",
    elements: [
      mockElement("mock-10-title", "text", "end of this little chapter", { x: 10, y: 27, width: 80, height: 21, rotation: 0 }, { fontFamily: "var(--app-font-serif)", fontSize: "1.7rem", color: "#33241d", textAlign: "center" }),
      mockElement("mock-10-note", "text", "more soon ♡", { x: 25, y: 58, width: 50, height: 14, rotation: -2 }, { fontFamily: "var(--app-font-handwriting)", fontSize: "1.6rem", color: "#d16f80", textAlign: "center" }, 2),
      mockElement("mock-10-sparkles", "sticker", "sparkles", { x: 42, y: 13, width: 16, height: 16, rotation: 5 }, { color: "#ffb74d" }, 3),
    ],
  },
];

export const createFallbackJournal = (): Journal => ({
  id: 0,
  title: "My Little Journal",
  coverStyle: "cream",
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  pages: createMockPages(),
});
