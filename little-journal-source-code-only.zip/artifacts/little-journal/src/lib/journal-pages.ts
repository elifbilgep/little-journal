import type { Journal, JournalPage } from './types';

export const INITIAL_EMPTY_PAGE_COUNT = 10;

export function createBlankJournalPage(
  pageNumber: number,
  backgroundStyle = 'cream',
): JournalPage {
  return {
    id: `page-${Date.now()}-${pageNumber}-${Math.random().toString(36).slice(2, 8)}`,
    pageNumber,
    backgroundStyle,
    elements: [],
  };
}

export function createInitialJournalPages(backgroundStyle: string): JournalPage[] {
  return Array.from({ length: INITIAL_EMPTY_PAGE_COUNT }, (_, index) =>
    createBlankJournalPage(index + 1, backgroundStyle),
  );
}

export function ensureJournalPageSpread(journal: Journal): Journal {
  const pages = journal.pages;

  if (pages.length === 0) {
    return {
      ...journal,
      pages: createInitialJournalPages('cream'),
    };
  }

  if (pages.length === 1 && pages[0].elements.length === 0) {
    const backgroundStyle = pages[0].backgroundStyle || 'cream';
    return {
      ...journal,
      pages: [
        pages[0],
        ...Array.from({ length: INITIAL_EMPTY_PAGE_COUNT - 1 }, (_, index) =>
          createBlankJournalPage(index + 2, backgroundStyle),
        ),
      ],
    };
  }

  if (pages.length % 2 === 1) {
    const backgroundStyle = pages[0]?.backgroundStyle || 'cream';
    return {
      ...journal,
      pages: [
        ...pages,
        createBlankJournalPage(pages.length + 1, backgroundStyle),
      ],
    };
  }

  return journal;
}