import {
  Component,
  type ComponentType,
  type ErrorInfo,
  type ReactNode,
} from 'react';

export interface ErrorFallbackProps {
  error: Error;
  resetError: () => void;
}

interface ErrorBoundaryProps {
  children: ReactNode;
  FallbackComponent?: ComponentType<ErrorFallbackProps>;
  /** Changing this clears a caught error. Pass the route to recover on navigation. */
  resetKey?: unknown;
}

interface ErrorBoundaryState {
  error: Error | null;
}

function toError(value: unknown): Error {
  if (value instanceof Error) {
    return value;
  }
  if (typeof value === 'string') {
    return new Error(value);
  }
  try {
    return new Error(JSON.stringify(value));
  } catch {
    return new Error(String(value));
  }
}

function DefaultFallback({ error, resetError }: ErrorFallbackProps) {
  return (
    <div className="flex min-h-[100dvh] w-full items-center justify-center bg-[var(--lj-mist)] p-6">
      <div className="w-full max-w-lg rounded-[24px] border border-[var(--lj-line)] bg-white p-8 text-center shadow-[var(--lj-shadow-card)]">
        <p className="text-[10px] font-bold uppercase tracking-[0.24em] text-[var(--lj-blue)]">Little Journal</p>
        <h1 className="mt-3 font-sans text-3xl font-extrabold tracking-[-0.06em] text-[var(--lj-black)]">
          Something went wrong
        </h1>
        <p className="mt-3 text-sm leading-6 text-[var(--lj-muted)]">
          This part of the app hit an error. The rest of the app is still
          running.
        </p>
        {/* Dev only: messages can carry API responses and other internals. */}
        {import.meta.env.DEV ? (
          <pre className="mt-5 overflow-x-auto rounded-[var(--lj-control-radius)] border border-[var(--lj-line)] bg-[var(--lj-soft)] p-3 text-left font-mono text-xs text-[var(--lj-black)]">
            {error.message || String(error)}
          </pre>
        ) : null}
        <button
          type="button"
          onClick={resetError}
          className="mt-6 rounded-[var(--lj-control-radius)] border border-[var(--lj-black)] bg-[var(--lj-black)] px-5 py-3 text-[11px] font-bold text-white transition hover:bg-[var(--lj-blue)] focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-[var(--lj-blue)]/60"
        >
          Try again
        </button>
      </div>
    </div>
  );
}

export class ErrorBoundary extends Component<
  ErrorBoundaryProps,
  ErrorBoundaryState
> {
  state: ErrorBoundaryState = { error: null };

  static getDerivedStateFromError(error: unknown): ErrorBoundaryState {
    return { error: toError(error) };
  }

  componentDidCatch(error: unknown, info: ErrorInfo): void {
    console.error(
      'ErrorBoundary caught an error:',
      toError(error),
      info.componentStack,
    );
  }

  componentDidUpdate(prevProps: ErrorBoundaryProps): void {
    if (
      this.state.error !== null &&
      prevProps.resetKey !== this.props.resetKey
    ) {
      this.resetError();
    }
  }

  resetError = (): void => {
    this.setState({ error: null });
  };

  render(): ReactNode {
    const { error } = this.state;
    if (error === null) {
      return this.props.children;
    }
    const Fallback = this.props.FallbackComponent ?? DefaultFallback;
    return <Fallback error={error} resetError={this.resetError} />;
  }
}
