import { useEffect, useState } from 'react';
import { ArrowUpRight, HardDrive, Menu, MousePointer2, X } from 'lucide-react';
import { Link } from 'wouter';
import './JournalHome.css';

const asset = (filename: string) => {
  const base = import.meta.env.BASE_URL.endsWith('/')
    ? import.meta.env.BASE_URL
    : `${import.meta.env.BASE_URL}/`;
  return `${base}images/${filename}`;
};

const floatingScraps = [
  { src: asset('sticker-star.png'), className: 'scrap scrap--star', alt: 'Leopard star patch' },
  { src: asset('sticker-heart.png'), className: 'scrap scrap--heart', alt: 'Fabric heart patch' },
  { src: asset('sticker-dog.png'), className: 'scrap scrap--dog', alt: 'Pink dog patch' },
  { src: asset('sticker-cat.png'), className: 'scrap scrap--cat', alt: 'Cat mermaid patch' },
  { src: asset('sticker-button-heart.png'), className: 'scrap scrap--button-heart', alt: 'Plaid heart button' },
  { src: asset('sticker-button.png'), className: 'scrap scrap--button', alt: 'Yellow button' },
  { src: asset('sticker-bow.png'), className: 'scrap scrap--bow', alt: 'Polka dot bow' },
  { src: asset('camera.png'), className: 'scrap scrap--camera', alt: 'Compact camera' },
];

const cards = [
  { src: asset('journal-photo-headphones.png'), label: 'late night', alt: 'A child wearing headphones and sunglasses' },
  { src: asset('journal-photo-besties.png'), label: 'besties', alt: 'Two friends making silly faces outdoors' },
  { src: asset('journal-photo-bubbles.png'), label: 'summer', alt: 'A friend surrounded by iridescent bubbles' },
  { src: asset('journal-photo-guitars.png'), label: 'music store', alt: 'A wall of colorful guitars' },
  { src: asset('journal-photo-skate.png'), label: 'sky high', alt: 'A skateboarder jumping against a blue sky' },
];

const journalCovers = [
  { src: asset('studio-scrap-journal-cover-11.png'), alt: 'Pink plaid journal cover' },
  { src: asset('studio-scrap-journal-cover-12.png'), alt: 'Pink star journal cover' },
  { src: asset('studio-scrap-journal-cover-13.png'), alt: 'Charcoal polka dot journal cover' },
  { src: asset('studio-scrap-journal-cover-14.png'), alt: 'Mint floral journal cover' },
  { src: asset('studio-scrap-journal-cover-15.png'), alt: 'Purple plaid journal cover' },
  { src: asset('studio-scrap-journal-cover-16.png'), alt: 'Cream cat journal cover' },
  { src: asset('studio-scrap-journal-cover-17.png'), alt: 'Black polka dot journal cover' },
  { src: asset('studio-scrap-journal-cover-18.png'), alt: 'White polka dot journal cover' },
];

export default function JournalHome() {
  const [journalCoverIndex, setJournalCoverIndex] = useState(0);
  const [isCoverChanging, setIsCoverChanging] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const journalCover = journalCovers[journalCoverIndex];

  useEffect(() => {
    journalCovers.forEach(({ src }) => {
      const image = new Image();
      image.decoding = 'async';
      image.src = src;
    });
  }, []);

  useEffect(() => {
    let changeTimeout: number | undefined;
    let resetTimeout: number | undefined;
    const coverTimer = window.setInterval(() => {
      setIsCoverChanging(true);
      changeTimeout = window.setTimeout(() => {
        setJournalCoverIndex((index) => (index + 1) % journalCovers.length);
      }, 220);
      resetTimeout = window.setTimeout(() => setIsCoverChanging(false), 760);
    }, 4200);

    return () => {
      window.clearInterval(coverTimer);
      if (changeTimeout !== undefined) {
        window.clearTimeout(changeTimeout);
      }
      if (resetTimeout !== undefined) {
        window.clearTimeout(resetTimeout);
      }
    };
  }, []);

  return (
    <main className="studio-scrap">
      <div className="studio-scrap__shell">
        <header className="studio-scrap__header">
          <a className="studio-scrap__new" href="#journal">
            <span>✣</span> NEW
          </a>
          <nav className={`studio-scrap__nav ${menuOpen ? 'is-open' : ''}`}>
            <a href="#journal">Journal</a>
            <a href="#features">How it works</a>
            <a href="#features">Features</a>
          </nav>
          <Link className="studio-scrap__start" href="/onboarding">
            Start a journal <ArrowUpRight size={13} />
          </Link>
          <button
            className="studio-scrap__menu"
            onClick={() => setMenuOpen((open) => !open)}
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
          >
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </header>

        <section className="studio-scrap__hero" id="journal">
          <h1>Your memories deserve<br />more than a camera roll.</h1>
          <p className="studio-scrap__intro">
            Turn real-looking pages. Drop in Polaroids, notes and stickers.
            Move everything until the page feels like yours.
          </p>
          <div className="studio-scrap__scene">
            <div className="studio-scrap__scene-grid" />
            {floatingScraps.map((scrap) => (
              <img key={scrap.className} {...scrap} />
            ))}

            <Link
              className="studio-scrap__journal"
              href="/onboarding"
              aria-label="Başlamak için günlüğü aç"
            >
              <span className="studio-scrap__journal-hint">
                Başlamak için kapağa tıkla
              </span>
              <img
                className={`studio-scrap__journal-closed ${isCoverChanging ? 'is-changing' : ''}`}
                src={journalCover.src}
                alt={journalCover.alt}
              />
            </Link>

            <div className="studio-scrap__callout studio-scrap__callout--drag">
              <MousePointer2 size={13} /> drag, resize, rotate
            </div>
            <div className="studio-scrap__callout studio-scrap__callout--cloud">
              <HardDrive size={13} /> saved in this browser
            </div>
          </div>

          <div className="studio-scrap__card-stage">
            <div className="studio-scrap__card-strip" aria-hidden="true" />
            <div className="studio-scrap__card-row" aria-label="Scrapbook elements">
              {cards.map((card, index) => (
                <div className={`studio-scrap__card studio-scrap__card--${index + 1}`} key={card.label}>
                  <img src={card.src} alt={card.alt} />
                  <span>{card.label}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="studio-scrap__dark" id="features">
          <div className="studio-scrap__dark-label"><span /> HOW IT WORKS</div>
          <div className="studio-scrap__dark-copy">
            <h2>Flip it. Fill it.<br />Make it unmistakably yours.</h2>
            <p>
              A private digital scrapbook that behaves like a real journal —
              tactile pages, loose memories and no rigid templates.
            </p>
          </div>
          <div className="studio-scrap__feature-grid">
            <article>
              <span>01</span>
              <h3>Turn the page</h3>
              <p>Drag the corner and move through a journal with real 3D page motion.</p>
            </article>
            <article>
              <span>02</span>
              <h3>Leave a trace</h3>
              <p>Add photos as Polaroids, then move, resize and rotate every object.</p>
            </article>
            <article>
              <span>03</span>
              <h3>Come back to it</h3>
              <p>Your pages are saved locally in this browser.</p>
            </article>
          </div>
        </section>
      </div>
    </main>
  );
}