import { useRef } from 'react';
import { motion } from 'framer-motion';
import { JournalPage, JournalElement } from '@/lib/types';
import ElementNode from './ElementNode';

const OVERHANG_TILE_SIZE = 100;
const TILE_EDGE_EPSILON = 0.0001;

export function getSpineCrossingElements(
  page: JournalPage,
  isLeft: boolean,
) {
  return page.elements.filter((element) => {
    const angle = (element.rotation * Math.PI) / 180;
    const halfWidth = element.width / 2;
    const halfHeight = element.height / 2;
    const centerX = element.x + halfWidth;
    const extentX =
      Math.abs(Math.cos(angle)) * halfWidth +
      Math.abs(Math.sin(angle)) * halfHeight;
    const minX = centerX - extentX;
    const maxX = centerX + extentX;

    return isLeft ? minX < 100 && maxX > 100 : minX < 0 && maxX > 0;
  });
}

function getOverhangTiles(
  element: JournalElement,
  region: 'all' | 'outer' | 'cover-left' | 'cover-right' = 'all',
) {
  const angle = (element.rotation * Math.PI) / 180;
  const halfWidth = element.width / 2;
  const halfHeight = element.height / 2;
  const centerX = element.x + halfWidth;
  const centerY = element.y + halfHeight;
  const extentX = Math.abs(Math.cos(angle)) * halfWidth + Math.abs(Math.sin(angle)) * halfHeight;
  const extentY = Math.abs(Math.sin(angle)) * halfWidth + Math.abs(Math.cos(angle)) * halfHeight;
  const minTileX = Math.floor((centerX - extentX) / OVERHANG_TILE_SIZE);
  const maxTileX = Math.floor((centerX + extentX - TILE_EDGE_EPSILON) / OVERHANG_TILE_SIZE);
  const minTileY = Math.floor((centerY - extentY) / OVERHANG_TILE_SIZE);
  const maxTileY = Math.floor((centerY + extentY - TILE_EDGE_EPSILON) / OVERHANG_TILE_SIZE);
  const tiles: Array<{ x: number; y: number }> = [];

  for (let x = minTileX; x <= maxTileX; x += 1) {
    for (let y = minTileY; y <= maxTileY; y += 1) {
      if (
        (region === 'all' && (x !== 0 || y !== 0)) ||
        (region === 'outer' && x < 0) ||
        (region === 'cover-left' && x === 0 && y !== 0) ||
        (region === 'cover-right' && (x > 0 || (x === 0 && y !== 0)))
      ) {
        tiles.push({ x, y });
      }
    }
  }

  return tiles;
}

export default function JournalPageComp({ 
  page, 
  state, 
  isLeft,
  onTurn,
  animateEntrance = false,
  interactive = true,
  overhangOnly = false,
  mirrorOverhangX = false,
  overhangBackFace = false,
  overhangRegion = 'all',
  spineCrossingElements = [],
  spineCrossingSourceIsLeft = false,
}: { 
  page: JournalPage; 
  state: any; 
  isLeft: boolean;
  onTurn?: (e: React.MouseEvent) => void;
  animateEntrance?: boolean;
  interactive?: boolean;
  overhangOnly?: boolean;
  mirrorOverhangX?: boolean;
  overhangBackFace?: boolean;
  overhangRegion?: 'all' | 'outer' | 'cover-left' | 'cover-right';
  spineCrossingElements?: JournalElement[];
  spineCrossingSourceIsLeft?: boolean;
}) {
  const pageRef = useRef<HTMLDivElement>(null);
  const sortedElements = [...page.elements].sort((a, b) => a.zIndex - b.zIndex);
  const spineCrossingIds = new Set(
    getSpineCrossingElements(page, isLeft).map((element) => element.id),
  );
  const regularElements = sortedElements.filter(
    (element) => !spineCrossingIds.has(element.id),
  );
  const spineElements = sortedElements.filter((element) =>
    spineCrossingIds.has(element.id),
  );
  const overhangElements = mirrorOverhangX
    ? sortedElements.map((element) => ({
        ...element,
        x: 100 - element.x - element.width,
        rotation: -element.rotation,
      }))
    : sortedElements;

  // Stop click from deselecting if clicked inside page but not on element
  const handlePageClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    state.setSelectedElementId(null);
  };

  if (overhangOnly) {
    return (
      <div
        ref={pageRef}
        className="journal-page-overhangs pointer-events-none absolute inset-0 overflow-visible"
        aria-hidden="true"
      >
        {overhangElements.flatMap((element) =>
          getOverhangTiles(element, overhangRegion).map(({ x, y }) => (
            <div
              key={`${element.id}:${x}:${y}`}
              className="absolute h-full w-full overflow-hidden"
              style={{
                left: `${x * OVERHANG_TILE_SIZE}%`,
                top: `${y * OVERHANG_TILE_SIZE}%`,
              }}
            >
              <div
                className="absolute h-full w-full"
                style={{
                  left: `${x * -OVERHANG_TILE_SIZE}%`,
                  top: `${y * -OVERHANG_TILE_SIZE}%`,
                }}
              >
                <ElementNode
                  element={element}
                  pageId={page.id}
                  state={state}
                  pageRef={pageRef}
                  readOnly
                  overhangClone
                  backFace={overhangBackFace}
                />
              </div>
            </div>
          )),
        )}
      </div>
    );
  }

  const renderElement = (element: JournalElement) => (
    <ElementNode
      key={element.id}
      element={element}
      pageId={page.id}
      state={state}
      pageRef={pageRef}
    />
  );

  return (
    <motion.div
      ref={pageRef}
      initial={animateEntrance ? { rotateY: isLeft ? 15 : -15, opacity: 0.5 } : false}
      animate={{ rotateY: 0, opacity: 1 }}
      exit={animateEntrance ? { rotateY: isLeft ? -15 : 15, opacity: 0 } : undefined}
      transition={animateEntrance ? { duration: 0.5, ease: "easeInOut" } : { duration: 0 }}
      className="journal-page relative h-full w-full overflow-visible"
      onClick={handlePageClick}
      style={{ transformOrigin: isLeft ? 'right' : 'left' }}
    >
      <div
        className={`journal-page-paper pointer-events-none absolute inset-0 overflow-hidden page-style-${page.backgroundStyle} ${isLeft ? 'rounded-l-lg page-shadow border-r border-black/5' : 'rounded-r-lg page-shadow-right border-l border-black/5'}`}
      >
        <div className="absolute inset-0 opacity-40 paper-texture mix-blend-multiply" />
      </div>

      {regularElements.map(renderElement)}

      {spineElements.map((element) => (
        <div
          key={`spine-source-${element.id}`}
          className="journal-page-spine-source absolute inset-0 overflow-hidden"
          style={{ zIndex: element.zIndex }}
        >
          {renderElement(element)}
        </div>
      ))}

      {spineCrossingElements.map((element) => (
        <div
          key={`spine-continuation-${element.id}`}
          className="journal-page-spine-continuation absolute left-0 top-0 h-full w-full overflow-hidden"
          style={{ zIndex: element.zIndex }}
          aria-hidden="true"
        >
          <ElementNode
            element={
              spineCrossingSourceIsLeft
                ? { ...element, x: element.x - 100 }
                : { ...element, x: element.x + 100 }
            }
            pageId={page.id}
            state={state}
            pageRef={pageRef}
            readOnly
            overhangClone
          />
        </div>
      ))}

      {/* Page Number */}
      <div className={`pointer-events-none absolute bottom-4 ${isLeft ? 'left-6' : 'right-6'} text-[var(--lj-black)] font-mono text-[10px] opacity-40 font-bold`}>
        {page.pageNumber}
      </div>
    </motion.div>
  );
}
