import { ImagePlus, Type, Sticker, Palette, FilePlus, Settings, Layers, LocateFixed } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { STICKERS, PAGE_STYLES, JOURNAL_COVERS } from '@/lib/constants';
import { isElementOffscreen } from '@/lib/use-journal-state';

const asset = (filename: string) => {
  const base = import.meta.env.BASE_URL.endsWith('/')
    ? import.meta.env.BASE_URL
    : `${import.meta.env.BASE_URL}/`;
  return `${base}images/${filename}`;
};

const toolButtonClass = 'flex h-12 w-12 items-center justify-center rounded-[var(--lj-control-radius)] text-[var(--lj-black)] transition-colors hover:bg-[var(--lj-soft)] hover:text-[var(--lj-blue)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--lj-blue)]';
const popoverClass = 'border border-[var(--lj-line)] bg-white shadow-lg rounded-xl';

export default function Toolbar({ state }: { state: any }) {
  const {
    journal,
    activePageIndex,
    selectedElementId,
    updatePage,
    addPage,
    addElement,
    updateCover,
    setSelectedElementId,
    bringToFront,
    bringElementIntoView,
  } = state;
  const activePage = journal?.pages[activePageIndex];
  const pageElements = activePage?.elements ?? [];
  const selectedElement = pageElements.find((element: any) => element.id === selectedElementId);

  const elementLabel = (element: any, index: number) => {
    const typeLabel = element.type === 'photo' ? 'Photo' : element.type === 'sticker' ? 'Sticker' : 'Note';
    const contentLabel = element.type === 'text' && element.content.trim()
      ? ` — ${element.content.trim().split('\n')[0].slice(0, 24)}`
      : '';
    return `${typeLabel} ${index + 1}${contentLabel}`;
  };

  const selectElement = (elementId: string) => {
    setSelectedElementId(elementId);
    if (activePage) bringToFront(activePage.id, elementId);
  };

  const addPhotoElement = (content: string) => {
    if (!activePage) return;

    addElement(activePage.id, {
      type: 'photo',
      x: 25 + Math.random() * 10,
      y: 20 + Math.random() * 10,
      width: 45,
      height: 50,
      rotation: Math.random() * 8 - 4,
      zIndex: 5,
      content,
      style: {}
    });
  };

  const handleAddText = () => {
    if (!activePage) return;
    addElement(activePage.id, {
      type: 'text',
      x: 30,
      y: 30,
      width: 40,
      height: 15,
      rotation: Math.random() * 4 - 2,
      zIndex: 10,
      content: '',
      style: { fontFamily: 'var(--app-font-handwriting)', fontSize: '1.5rem', color: '#101010' }
    });
  };

  const handleAddSticker = (stickerId: string) => {
    if (!activePage) return;
    const sticker = STICKERS.find((candidate) => candidate.id === stickerId);
    addElement(activePage.id, {
      type: 'sticker',
      x: 40 + Math.random() * 10,
      y: 40 + Math.random() * 10,
      width: 15,
      height: 15,
      rotation: Math.random() * 30 - 15,
      zIndex: 10,
      content: stickerId,
      style: { color: sticker?.color ?? '#4b74ff' }
    });
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !activePage) return;

    try {
      const content = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => typeof reader.result === 'string'
          ? resolve(reader.result)
          : reject(new Error('The selected photo could not be read.'));
        reader.onerror = () => reject(reader.error ?? new Error('The selected photo could not be read.'));
        reader.readAsDataURL(file);
      });
      addPhotoElement(content);
      e.target.value = '';
    } catch (err) {
      console.error('Photo read failed', err);
      alert('We couldn’t read that photo. Please try uploading it again.');
      e.target.value = '';
    }
  };

  return (
    <div
      data-journal-toolbar
      className="fixed bottom-5 left-1/2 z-50 flex max-w-[calc(100vw-1.5rem)] -translate-x-1/2 flex-row gap-1 overflow-x-auto rounded-xl border border-[var(--lj-line)] bg-white p-2 shadow-[var(--lj-shadow-card)]"
      onClick={(event) => event.stopPropagation()}
      onPointerDown={(event) => event.stopPropagation()}
    >
      
      {/* Add Photo */}
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="relative">
            <input 
              type="file" 
              accept="image/jpeg, image/png, image/webp" 
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              onChange={handlePhotoUpload}
              title="Add Photo"
            />
            <button
              className={`${toolButtonClass} pointer-events-none`}
              aria-label="Add Photo"
            >
              <ImagePlus className="w-5 h-5" />
            </button>
          </div>
        </TooltipTrigger>
         <TooltipContent side="top">Add Photo</TooltipContent>
      </Tooltip>

      {/* Add Text */}
      <Tooltip>
        <TooltipTrigger asChild>
          <button 
            onClick={handleAddText}
            className={toolButtonClass}
            aria-label="Add Text"
          >
            <Type className="w-5 h-5" />
          </button>
        </TooltipTrigger>
         <TooltipContent side="top">Add Text</TooltipContent>
      </Tooltip>

      {/* Stickers */}
      <Popover>
        <Tooltip>
          <TooltipTrigger asChild>
            <PopoverTrigger asChild>
              <button className={toolButtonClass} aria-label="Browse page elements">
                <Layers className="w-5 h-5" />
              </button>
            </PopoverTrigger>
          </TooltipTrigger>
          <TooltipContent side="top">Page Elements</TooltipContent>
        </Tooltip>
        <PopoverContent side="top" align="center" className={`w-72 p-3 ${popoverClass}`}>
          <div className="mb-2 flex items-center justify-between">
            <h4 className="text-[10px] font-bold uppercase tracking-[0.12em] text-[var(--lj-black)]">
              Page {activePage?.pageNumber ?? '—'} elements
            </h4>
            <span className="text-[10px] text-[var(--lj-muted)]">{pageElements.length}</span>
          </div>
          <div className="flex max-h-56 flex-col gap-1 overflow-y-auto">
            {pageElements.length === 0 ? (
              <p className="px-2 py-3 text-center text-xs text-[var(--lj-muted)]">No elements on this page yet.</p>
            ) : (
              pageElements.map((element: any, index: number) => {
                const offscreen = isElementOffscreen(element);
                const selected = element.id === selectedElementId;
                return (
                  <button
                    key={element.id}
                    onClick={(event) => {
                      event.stopPropagation();
                      selectElement(element.id);
                    }}
                    className={`flex items-center justify-between gap-3 rounded-lg px-2.5 py-2 text-left text-xs transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--lj-blue)] ${selected ? 'bg-[var(--lj-soft)] text-[var(--lj-blue)]' : 'text-[var(--lj-black)] hover:bg-[var(--lj-soft)]'}`}
                    aria-pressed={selected}
                  >
                    <span className="min-w-0 truncate">{elementLabel(element, index)}</span>
                    {offscreen && (
                      <span className="shrink-0 rounded-full bg-[#fff4df] px-2 py-0.5 text-[9px] font-bold uppercase tracking-[0.08em] text-[#9a681c]">
                        Off canvas
                      </span>
                    )}
                  </button>
                );
              })
            )}
          </div>
          {selectedElement && isElementOffscreen(selectedElement) && (
            <button
              onClick={(event) => {
                event.stopPropagation();
                if (activePage) bringElementIntoView(activePage.id, selectedElement.id);
              }}
              className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg bg-[var(--lj-blue)] px-3 py-2 text-xs font-bold text-white transition-colors hover:brightness-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--lj-blue)] focus-visible:ring-offset-2"
            >
              <LocateFixed className="h-4 w-4" />
              Bring into view
            </button>
          )}
        </PopoverContent>
      </Popover>

      {/* Stickers */}
      <Popover>
        <Tooltip>
          <TooltipTrigger asChild>
            <PopoverTrigger asChild>
              <button className={toolButtonClass} aria-label="Add Sticker">
                <Sticker className="w-5 h-5" />
              </button>
            </PopoverTrigger>
          </TooltipTrigger>
          <TooltipContent side="top">Stickers</TooltipContent>
        </Tooltip>
        <PopoverContent side="right" className={`w-72 p-3 ${popoverClass}`}>
          <div className="mb-2 text-[10px] font-bold uppercase tracking-[0.12em] text-[var(--lj-muted)]">
            Sticker collection
          </div>
          <div className="grid max-h-72 grid-cols-5 gap-2 overflow-y-auto pr-1">
            {STICKERS.map(s => (
              <button
                key={s.id}
                onClick={() => handleAddSticker(s.id)}
                className="flex aspect-square items-center justify-center rounded-lg p-2 transition-colors hover:bg-[var(--lj-soft)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--lj-blue)]"
                aria-label={`Add ${s.name ?? s.id} sticker`}
                title={s.name ?? s.id}
              >
                <svg viewBox="0 0 24 24" className="h-full w-full" style={{ fill: s.color || 'var(--lj-black)' }}>
                  <path d={s.path} />
                </svg>
              </button>
            ))}
          </div>
        </PopoverContent>
      </Popover>

      {/* Page Style */}
      <Popover>
        <Tooltip>
          <TooltipTrigger asChild>
            <PopoverTrigger asChild>
              <button className={toolButtonClass} aria-label="Page Background">
                <Palette className="w-5 h-5" />
              </button>
            </PopoverTrigger>
          </TooltipTrigger>
          <TooltipContent side="top">Page Background</TooltipContent>
        </Tooltip>
        <PopoverContent side="right" className={`w-48 p-2 ${popoverClass}`}>
          <div className="flex flex-col gap-1">
            {PAGE_STYLES.map(style => (
              <button
                key={style.id}
                onClick={() => {
                  if (activePage) updatePage(activePage.id, (p: any) => ({ ...p, backgroundStyle: style.id }));
                }}
                className={`flex items-center gap-3 rounded-lg px-3 py-2 text-left text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--lj-blue)] ${activePage?.backgroundStyle === style.id ? 'bg-[var(--lj-soft)] font-medium text-[var(--lj-blue)]' : 'text-[var(--lj-black)] hover:bg-[var(--lj-soft)]'}`}
              >
                <div className={`w-4 h-4 rounded-full border border-black/10 page-style-${style.id}`} />
                {style.name}
              </button>
            ))}
          </div>
        </PopoverContent>
      </Popover>

      {/* Add Page */}
      <Tooltip>
        <TooltipTrigger asChild>
          <button 
            onClick={() => addPage()}
            className={toolButtonClass}
              aria-label="Add page spread"
          >
            <FilePlus className="w-5 h-5" />
          </button>
        </TooltipTrigger>
          <TooltipContent side="top">Add page spread</TooltipContent>
      </Tooltip>

      {/* Settings / Cover */}
      <Popover>
        <Tooltip>
          <TooltipTrigger asChild>
            <PopoverTrigger asChild>
              <button
                className={`${toolButtonClass} ml-1 border-l border-[var(--lj-line)]`}
                aria-label="Journal Settings"
              >
                <Settings className="w-5 h-5" />
              </button>
            </PopoverTrigger>
          </TooltipTrigger>
          <TooltipContent side="top">Journal Settings</TooltipContent>
        </Tooltip>
        <PopoverContent side="right" className={`w-56 p-3 ${popoverClass}`}>
          <h4 className="mb-3 text-[10px] font-bold uppercase tracking-[0.12em] text-[var(--lj-black)]">Journal Cover</h4>
          <div className="grid grid-cols-4 gap-2 mb-4">
            {JOURNAL_COVERS.map(style => (
              <button
                key={style.id}
                onClick={() => updateCover({ coverStyle: style.id })}
                className={`aspect-[4/5] overflow-hidden rounded-md border-2 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--lj-blue)] ${journal?.coverStyle === style.id ? 'scale-105 border-[var(--lj-blue)]' : 'border-transparent opacity-75 hover:scale-105 hover:opacity-100'}`}
                title={style.name}
              >
                <img src={asset(style.src)} alt="" className="h-full w-full object-cover" />
              </button>
            ))}
          </div>
          <h4 className="mb-2 mt-4 text-[10px] font-bold uppercase tracking-[0.12em] text-[var(--lj-black)]">Journal Title</h4>
          <input 
            type="text" 
            value={journal?.title || ''}
            onChange={(e) => updateCover({ title: e.target.value })}
            className="w-full rounded-[var(--lj-control-radius)] border border-[var(--lj-line)] bg-[var(--lj-soft)] px-3 py-2 text-sm transition-all focus:border-[var(--lj-blue)] focus:outline-none focus:ring-1 focus:ring-[var(--lj-blue)]"
          />
        </PopoverContent>
      </Popover>
      
    </div>
  );
}
