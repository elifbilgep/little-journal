import { useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { ArrowLeft, MousePointer2 } from 'lucide-react';
import { getJournalCoverFilename } from '@/lib/constants';

const asset = (filename: string) => {
  const base = import.meta.env.BASE_URL.endsWith('/')
    ? import.meta.env.BASE_URL
    : `${import.meta.env.BASE_URL}/`;
  return `${base}images/${filename}`;
};

export default function ClosedJournal({
  coverStyle,
  title,
  onOpen,
  onBack,
}: {
  coverStyle: string;
  title: string;
  onOpen: () => void;
  onBack: () => void;
}) {
  const [isOpening, setIsOpening] = useState(false);
  const reducedMotion = useReducedMotion();

  const openJournal = () => {
    if (isOpening) return;
    setIsOpening(true);
    window.setTimeout(onOpen, reducedMotion ? 80 : 780);
  };

  return (
    <motion.main
      className="relative flex min-h-[100dvh] w-full items-center justify-center overflow-hidden bg-[var(--lj-mist)] px-4 py-16 perspective-[2200px]"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <div className="absolute left-[8%] top-[12%] h-36 w-36 rounded-full bg-[#101010]/5 blur-3xl" />
      <div className="absolute bottom-[8%] right-[10%] h-44 w-44 rounded-full bg-[var(--lj-blue)]/10 blur-3xl" />

      <button
        type="button"
        onClick={onBack}
        className="absolute left-5 top-5 z-30 inline-flex items-center gap-2 rounded-full border border-[var(--lj-line)] bg-white px-4 py-2 text-xs font-bold uppercase tracking-[0.12em] text-[var(--lj-black)] shadow-[0_2px_10px_rgba(16,16,16,0.04)] transition hover:bg-[var(--lj-soft)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--lj-blue)]"
      >
        <ArrowLeft size={14} />
        Home
      </button>

      <div className="relative z-10 flex w-full max-w-3xl flex-col items-center">
        <p className="mb-2 text-[10px] font-bold uppercase tracking-[0.28em] text-[var(--lj-blue)]">
          Your journal is waiting
        </p>
        <h1 className="mb-7 text-center font-sans text-3xl font-extrabold tracking-[-0.06em] text-[var(--lj-black)] md:text-5xl">
          {title}
        </h1>

        <motion.button
          type="button"
          drag={isOpening ? false : 'x'}
          dragConstraints={{ left: -125, right: 35 }}
          dragElastic={0.16}
          onDragEnd={(_, info) => {
            if (Math.abs(info.offset.x) > 52 || Math.abs(info.velocity.x) > 420) {
              openJournal();
            }
          }}
          onClick={openJournal}
          className="relative h-[min(62vh,620px)] w-[min(78vw,500px)] cursor-grab touch-pan-y rounded-[28px] bg-transparent focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[var(--lj-blue)]/70 active:cursor-grabbing"
          style={{ transformStyle: 'preserve-3d', transformOrigin: 'left center' }}
          animate={isOpening
            ? { rotateY: -118, x: -42, scale: 0.96, opacity: 0.12 }
            : { rotateY: -5, rotateX: 2, y: [0, -5, 0] }}
          transition={isOpening
            ? { duration: reducedMotion ? 0.08 : 0.78, ease: [0.22, 1, 0.36, 1] }
            : { y: { duration: 4.5, repeat: Infinity, ease: 'easeInOut' } }}
          aria-label="Open your journal"
        >
          <div className="absolute inset-[10%_8%_11%] rounded-[24px] bg-black/10 shadow-[0_36px_70px_rgba(16,16,16,0.15)]" />
          <img
            src={asset(getJournalCoverFilename(coverStyle))}
            alt=""
            className="relative h-full w-full select-none object-contain drop-shadow-[0_28px_25px_rgba(16,16,16,0.15)]"
            draggable={false}
          />
          <span className="absolute bottom-[18%] left-1/2 inline-flex -translate-x-1/2 items-center gap-2 whitespace-nowrap rounded-full border border-[var(--lj-line)] bg-white px-4 py-2 text-[10px] font-bold uppercase tracking-[0.16em] text-[var(--lj-black)] shadow-[0_12px_24px_rgba(16,16,16,0.08)]">
            <MousePointer2 size={13} />
            Tap or drag to open
          </span>
        </motion.button>
      </div>
    </motion.main>
  );
}