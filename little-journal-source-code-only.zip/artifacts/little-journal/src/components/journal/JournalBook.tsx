import {
  createContext,
  forwardRef,
  useCallback,
  useContext,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import HTMLFlipBook from 'react-pageflip';
import { flushSync } from 'react-dom';
import { BookOpen, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { JournalElement, JournalPage } from '@/lib/types';
import { getJournalCoverFilename } from '@/lib/constants';
import ElementNode from './ElementNode';
import JournalPageComp, { getSpineCrossingElements } from './JournalPage';

type PageFlipRef = {
  pageFlip: () => {
    turnToPage: (pageIndex: number) => void;
    getCurrentPageIndex: () => number;
    getPageCount: () => number;
    flipNext: (corner?: 'top' | 'bottom') => void;
    flipPrev: (corner?: 'top' | 'bottom') => void;
  } | undefined;
};

type BookPageProps = {
  pageId: string;
  pageIndex: number;
};

type PageRenderContextValue = {
  pages: JournalPage[];
  coverStyle: string;
  state: any;
};

const PageRenderContext = createContext<PageRenderContextValue | null>(null);

function usePageRenderContext() {
  const context = useContext(PageRenderContext);
  if (!context) {
    throw new Error('Journal pages must render inside PageRenderContext');
  }
  return context;
}

type DragPreviewState = {
  pageId: string;
  element: JournalElement;
  pageRect: { left: number; top: number; width: number; height: number };
  stageRect: { left: number; top: number; width: number; height: number };
  offsetX: number;
  offsetY: number;
};

type PageGestureState = {
  pointerId: number;
  startX: number;
  startY: number;
};

function getShortLandscapePageSize() {
  if (typeof window === 'undefined') {
    return { width: 180, height: 252 };
  }

  const height = Math.max(220, Math.min(360, window.innerHeight - 96));
  return {
    width: Math.round((height * 5) / 7),
    height,
  };
}

const asset = (filename: string) => {
  const base = import.meta.env.BASE_URL.endsWith('/')
    ? import.meta.env.BASE_URL
    : `${import.meta.env.BASE_URL}/`;
  return `${base}images/${filename}`;
};

const JournalCoverPage = forwardRef<HTMLDivElement>((_, ref) => {
  const { coverStyle } = usePageRenderContext();

  return (
    <div
      ref={ref}
      className="journal-flipbook-page journal-cover-page"
      data-density="hard"
      data-page-index="cover"
      aria-label="Journal cover"
    >
      <img
        src={asset(getJournalCoverFilename(coverStyle))}
        alt=""
        className="journal-cover-image"
        draggable={false}
      />
    </div>
  );
});

JournalCoverPage.displayName = 'JournalCoverPage';

const BookPage = forwardRef<HTMLDivElement, BookPageProps>(
  ({ pageId, pageIndex }, ref) => {
    const { pages, state } = usePageRenderContext();
    const page = pages.find((candidate) => candidate.id === pageId);
    const pairedPage =
      pageIndex % 2 === 0 ? pages[pageIndex + 1] : pages[pageIndex - 1];
    const spineCrossingElements = pairedPage
      ? getSpineCrossingElements(pairedPage, pageIndex % 2 !== 0)
      : [];

    if (!page) {
      return (
        <div
          ref={ref}
          className="journal-flipbook-page"
          data-density="hard"
          data-page-index={pageIndex}
        />
      );
    }

    return (
      <div
        ref={ref}
        className={`journal-flipbook-page page-style-${page.backgroundStyle}`}
        data-density="hard"
        data-page-index={pageIndex}
      >
        <JournalPageComp
          page={page}
          state={state}
          isLeft={pageIndex % 2 === 0}
          interactive={false}
          spineCrossingElements={spineCrossingElements}
          spineCrossingSourceIsLeft={pageIndex % 2 === 1}
        />
      </div>
    );
  },
);

BookPage.displayName = 'BookPage';

function DragPreview({
  preview,
  stageRef,
}: {
  preview: DragPreviewState;
  stageRef: React.RefObject<HTMLDivElement | null>;
}) {
  const { element, pageId, pageRect, stageRect, offsetX, offsetY } = preview;
  const previewElement: JournalElement = {
    ...element,
    x:
      ((pageRect.left -
        stageRect.left +
        (element.x / 100) * pageRect.width +
        offsetX) /
        stageRect.width) *
      100,
    y:
      ((pageRect.top -
        stageRect.top +
        (element.y / 100) * pageRect.height +
        offsetY) /
        stageRect.height) *
      100,
    width: (element.width * pageRect.width) / stageRect.width,
    height: (element.height * pageRect.height) / stageRect.height,
    zIndex: 1,
  };

  return (
    <ElementNode
      element={previewElement}
      pageId={pageId}
      state={{ selectedElementId: null }}
      pageRef={stageRef}
      readOnly
      dragPreview
    />
  );
}

export default function JournalBook({
  state,
  onCoverVisibilityChange,
}: {
  state: any;
  onCoverVisibilityChange?: (isVisible: boolean) => void;
}) {
  const { journal, activePageIndex, setActivePageIndex } = state;
  const bookRef = useRef<PageFlipRef | null>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const turnDirectionRef = useRef<'forward' | 'back' | null>(null);
  const programmaticActivePageRef = useRef<number | null>(null);
  const blockedBookGestureRef = useRef(false);
  const pageGestureRef = useRef<PageGestureState | null>(null);
  const [isShortLandscape, setIsShortLandscape] = useState(() =>
    typeof window !== 'undefined' &&
    window.matchMedia('(orientation: landscape) and (max-height: 600px)').matches,
  );
  const [shortLandscapePageSize, setShortLandscapePageSize] = useState(
    getShortLandscapePageSize,
  );
  const [isFlipping, setIsFlipping] = useState(false);
  const [bookBounds, setBookBounds] = useState({
    left: 0,
    top: 0,
    width: 0,
    height: 0,
    pageWidth: 0,
  });
  const [dragPreview, setDragPreview] = useState<DragPreviewState | null>(null);
  const [draggingElementId, setDraggingElementId] = useState<string | null>(null);
  const [isCoverVisible, setIsCoverVisible] = useState(true);
  const [isClosingCover, setIsClosingCover] = useState(false);
  const pages: JournalPage[] = journal?.pages ?? [];
  const handleElementDragStart = useCallback(
    (pageId: string, element: JournalElement) => {
      const stage = stageRef.current;
      const pageIndex = pages.findIndex((page) => page.id === pageId);
      const sourcePage = pageIndex >= 0
        ? stage?.querySelector<HTMLElement>(
            `.journal-flipbook-page[data-page-index="${pageIndex}"]`,
          )
        : null;
      if (!stage || !sourcePage) return;

      const stageRect = stage.getBoundingClientRect();
      const pageRect = sourcePage.getBoundingClientRect();
      flushSync(() => {
        setDraggingElementId(element.id);
        setDragPreview({
          pageId,
          element: { ...element },
          pageRect: {
            left: pageRect.left,
            top: pageRect.top,
            width: pageRect.width,
            height: pageRect.height,
          },
          stageRect: {
            left: stageRect.left,
            top: stageRect.top,
            width: stageRect.width,
            height: stageRect.height,
          },
          offsetX: 0,
          offsetY: 0,
        });
      });
    },
    [pages],
  );

  const handleElementDragMove = useCallback(
    (pageId: string, elementId: string, offsetX: number, offsetY: number) => {
      setDragPreview((current) =>
        current?.pageId === pageId && current.element.id === elementId
          ? { ...current, offsetX, offsetY }
          : current,
      );
    },
    [],
  );

  const handleElementDragEnd = useCallback(
    () => {
      flushSync(() => {
        setDragPreview(null);
        setDraggingElementId(null);
      });
    },
    [],
  );

  const pageInteractionState = useMemo(
    () => ({
      selectedElementId: state.selectedElementId,
      setSelectedElementId: state.setSelectedElementId,
      draggingElementId,
      pages,
      updateElement: state.updateElement,
      moveElementToPage: state.moveElementToPage,
      deleteElement: state.deleteElement,
      bringToFront: state.bringToFront,
      sendToBack: state.sendToBack,
      bringElementIntoView: state.bringElementIntoView,
      onElementDragStart: handleElementDragStart,
      onElementDragMove: handleElementDragMove,
      onElementDragEnd: handleElementDragEnd,
    }),
    [
      state.bringElementIntoView,
      state.bringToFront,
      state.deleteElement,
      state.selectedElementId,
      state.sendToBack,
      state.setSelectedElementId,
      state.updateElement,
      state.moveElementToPage,
      pages,
      handleElementDragEnd,
      handleElementDragMove,
      handleElementDragStart,
      draggingElementId,
    ],
  );
  const pageRenderContext = useMemo(
    () => ({
      pages,
      coverStyle: journal?.coverStyle ?? '',
      state: pageInteractionState,
    }),
    [journal?.coverStyle, pageInteractionState, pages],
  );
  const pageIds = useMemo(
    () => pages.map((page) => page.id),
    [journal?.id, pages.length],
  );
  const pageNodes = useMemo(
    () =>
      [
        <JournalCoverPage key="journal-cover" />,
        ...pageIds.map((pageId, pageIndex) => (
          <BookPage
            key={pageId}
            pageId={pageId}
            pageIndex={pageIndex}
          />
        )),
      ],
    [pageIds],
  );

  useEffect(() => {
    const media = window.matchMedia(
      '(orientation: landscape) and (max-height: 600px)',
    );
    const updateLayout = (event: MediaQueryListEvent) => {
      setIsShortLandscape(event.matches);
      setShortLandscapePageSize(getShortLandscapePageSize());
    };
    const updatePageSize = () => {
      setShortLandscapePageSize(getShortLandscapePageSize());
    };

    media.addEventListener('change', updateLayout);
    window.addEventListener('resize', updatePageSize);
    return () => {
      media.removeEventListener('change', updateLayout);
      window.removeEventListener('resize', updatePageSize);
    };
  }, []);

  useLayoutEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;

    const measureBook = () => {
      const book = stage.querySelector<HTMLElement>('.journal-flipbook');
      const activePageSelector = isCoverVisible
        ? '.journal-flipbook-page[data-page-index="cover"]'
        : `.journal-flipbook-page[data-page-index="${activePageIndex}"]`;
      const activePage = stage.querySelector<HTMLElement>(
        activePageSelector,
      );
      if (!book || !activePage) return;

      const stageBounds = stage.getBoundingClientRect();
      const bookRect = book.getBoundingClientRect();
      const pageRect = activePage.getBoundingClientRect();
      const visiblePageCount = bookRect.width > pageRect.width * 1.5 ? 2 : 1;
      setBookBounds({
        left: pageRect.left - stageBounds.left,
        top: pageRect.top - stageBounds.top,
        width: pageRect.width * visiblePageCount,
        height: pageRect.height,
        pageWidth: pageRect.width,
      });
    };

    const frame = window.requestAnimationFrame(measureBook);
    const observer = new ResizeObserver(measureBook);
    observer.observe(stage);
    const book = stage.querySelector<HTMLElement>('.journal-flipbook');
    if (book) observer.observe(book);
    const activePage = stage.querySelector<HTMLElement>(
      isCoverVisible
        ? '.journal-flipbook-page[data-page-index="cover"]'
        : `.journal-flipbook-page[data-page-index="${activePageIndex}"]`,
    );
    if (activePage) observer.observe(activePage);
    window.addEventListener('resize', measureBook);

    return () => {
      window.cancelAnimationFrame(frame);
      observer.disconnect();
      window.removeEventListener('resize', measureBook);
    };
  }, [activePageIndex, isCoverVisible, pages.length]);

  const handleFlip = useCallback((event: { data: number }) => {
    const bookPageIndex = Number(event.data);
    const coverIsVisible = bookPageIndex === 0;
    setIsClosingCover(false);
    setIsCoverVisible(coverIsVisible);
    onCoverVisibilityChange?.(coverIsVisible);

    if (coverIsVisible) {
      programmaticActivePageRef.current = null;
      setActivePageIndex(0);
      return;
    }

    const programmaticPageIndex = programmaticActivePageRef.current;
    const programmaticBookPageIndex =
      programmaticPageIndex === null ? null : programmaticPageIndex + 1;
    if (
      programmaticPageIndex !== null &&
      programmaticBookPageIndex !== null &&
      (programmaticBookPageIndex === bookPageIndex ||
        programmaticBookPageIndex === bookPageIndex + 1)
    ) {
      programmaticActivePageRef.current = null;
      setActivePageIndex(programmaticPageIndex);
      return;
    }

    programmaticActivePageRef.current = null;
    setActivePageIndex(bookPageIndex - 1);
  }, [onCoverVisibilityChange, setActivePageIndex]);

  const clearTurningPageClass = useCallback(() => {
    stageRef.current
      ?.querySelectorAll<HTMLElement>('.journal-flipbook-page.journal-turning-page')
      .forEach((page) => page.classList.remove('journal-turning-page'));
  }, []);

  const handleFlipState = useCallback((event: { data: string }) => {
    // PageFlip reports a held manual page drag as `user_fold`, then switches
    // to `flipping` only after release. Both phases need the page-local
    // overhang layer so protruding scrapbook elements never blink out.
    const isTurning = event.data === 'user_fold' || event.data === 'flipping';
    setIsFlipping(isTurning);

    if (!isTurning) {
      setIsClosingCover(false);
      clearTurningPageClass();
      turnDirectionRef.current = null;
      return;
    }

    const currentPageIndex =
      bookRef.current?.pageFlip()?.getCurrentPageIndex() ?? activePageIndex;
    const flippingBookPageIndex =
      turnDirectionRef.current === 'back'
        ? currentPageIndex - 1
        : currentPageIndex + 2;
    const flippingPageIndex = flippingBookPageIndex - 1;

    window.requestAnimationFrame(() => {
      clearTurningPageClass();
      if (flippingPageIndex >= 0) {
        stageRef.current
          ?.querySelector<HTMLElement>(
            `.journal-flipbook-page[data-page-index="${flippingPageIndex}"]`,
          )
          ?.classList.add('journal-turning-page');
      }
    });
  }, [activePageIndex, clearTurningPageClass]);

  const syncToExpectedPage = useCallback(() => {
    const pageFlip = bookRef.current?.pageFlip();
    if (!pageFlip || isFlipping) return;

    const currentIndex = pageFlip.getCurrentPageIndex();
    const expectedIndex = isCoverVisible ? 0 : activePageIndex + 1;
    if (currentIndex !== expectedIndex) {
      programmaticActivePageRef.current = isCoverVisible
        ? null
        : activePageIndex;
      pageFlip.turnToPage(expectedIndex);
    }
  }, [activePageIndex, isCoverVisible, isFlipping]);

  const handleBookUpdate = useCallback(() => {
    window.requestAnimationFrame(syncToExpectedPage);
  }, [syncToExpectedPage]);

  useEffect(() => {
    let frame = 0;
    let attempts = 0;
    const expectedPageCount = pages.length + 1;

    const syncWhenReady = () => {
      const pageFlip = bookRef.current?.pageFlip();
      if (
        pageFlip?.getPageCount() === expectedPageCount ||
        attempts >= 10
      ) {
        syncToExpectedPage();
        return;
      }

      attempts += 1;
      frame = window.requestAnimationFrame(syncWhenReady);
    };

    frame = window.requestAnimationFrame(syncWhenReady);

    return () => window.cancelAnimationFrame(frame);
  }, [pages.length, syncToExpectedPage]);

  useEffect(() => {
    const flipbook = stageRef.current?.querySelector<HTMLElement>('.journal-flipbook');
    if (!flipbook) return;

    flipbook.classList.toggle('is-flipping', isFlipping);
    return () => flipbook.classList.remove('is-flipping');
  }, [isFlipping]);

  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;

    const blockPageFlipStart = (event: Event) => {
      const target = event.target;
      if (
        target instanceof Element &&
        target.closest(
          '[data-journal-element], [data-journal-drag-preview], [data-journal-overhang-clone]',
        )
      ) {
        event.stopPropagation();
      }
    };

    stage.addEventListener('mousedown', blockPageFlipStart, true);
    stage.addEventListener('touchstart', blockPageFlipStart, {
      capture: true,
      passive: true,
    });

    return () => {
      stage.removeEventListener('mousedown', blockPageFlipStart, true);
      stage.removeEventListener('touchstart', blockPageFlipStart, true);
    };
  }, []);

  useEffect(() => {
    const isJournalElementTarget = (event: Event) => {
      const target = event.target;
      return (
        target instanceof Element &&
        Boolean(
          target.closest(
            '[data-journal-element], [data-journal-element-drag-handle], [data-journal-drag-preview], [data-journal-overhang-clone]',
          ),
        )
      );
    };

    const blockDocumentGestureStart = (event: Event) => {
      if (!isJournalElementTarget(event)) return;

      blockedBookGestureRef.current = true;
      event.stopPropagation();
    };

    const blockDocumentGestureEnd = (event: Event) => {
      if (!blockedBookGestureRef.current) return;

      event.stopPropagation();
      blockedBookGestureRef.current = false;
    };

    document.addEventListener('mousedown', blockDocumentGestureStart, true);
    document.addEventListener('touchstart', blockDocumentGestureStart, {
      capture: true,
      passive: true,
    });
    document.addEventListener('mouseup', blockDocumentGestureEnd, true);
    document.addEventListener('touchend', blockDocumentGestureEnd, true);
    document.addEventListener('touchcancel', blockDocumentGestureEnd, true);

    return () => {
      document.removeEventListener('mousedown', blockDocumentGestureStart, true);
      document.removeEventListener('touchstart', blockDocumentGestureStart, true);
      document.removeEventListener('mouseup', blockDocumentGestureEnd, true);
      document.removeEventListener('touchend', blockDocumentGestureEnd, true);
      document.removeEventListener('touchcancel', blockDocumentGestureEnd, true);
    };
  }, []);

  const handlePageGestureStart = useCallback(
    (event: React.PointerEvent<HTMLDivElement>) => {
      const target = event.target as HTMLElement;
      if (
        target.closest(
          '[data-journal-element], [data-journal-element-drag-handle], [data-journal-drag-preview], [data-journal-overhang-clone]',
        )
      ) {
        return;
      }

      if (!target.closest('.journal-flipbook-page')) return;

      pageGestureRef.current = {
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
      };
      event.currentTarget.setPointerCapture(event.pointerId);
    },
    [],
  );

  const handlePageGestureEnd = useCallback(
    (event: React.PointerEvent<HTMLDivElement>) => {
      const gesture = pageGestureRef.current;
      if (!gesture || gesture.pointerId !== event.pointerId) return;

      pageGestureRef.current = null;
      if (event.currentTarget.hasPointerCapture(event.pointerId)) {
        event.currentTarget.releasePointerCapture(event.pointerId);
      }

      const deltaX = event.clientX - gesture.startX;
      const deltaY = event.clientY - gesture.startY;
      const stageWidth = stageRef.current?.getBoundingClientRect().width ?? 0;
      const horizontalThreshold = Math.max(36, stageWidth * 0.05);

      if (
        Math.abs(deltaX) < horizontalThreshold ||
        Math.abs(deltaX) <= Math.abs(deltaY)
      ) {
        return;
      }

      const direction = deltaX < 0 ? 'forward' : 'back';
      turnDirectionRef.current = direction;
      setIsClosingCover(
        direction === 'back' && !isCoverVisible && activePageIndex === 0,
      );
      if (direction === 'forward') {
        bookRef.current?.pageFlip()?.flipNext('bottom');
      } else {
        bookRef.current?.pageFlip()?.flipPrev('bottom');
      }
    },
    [activePageIndex, isCoverVisible],
  );

  const handlePageGestureCancel = useCallback(
    (event: React.PointerEvent<HTMLDivElement>) => {
      if (pageGestureRef.current?.pointerId === event.pointerId) {
        pageGestureRef.current = null;
      }
      if (event.currentTarget.hasPointerCapture(event.pointerId)) {
        event.currentTarget.releasePointerCapture(event.pointerId);
      }
    },
    [],
  );

  const handleStageKeyDown = useCallback(
    (event: React.KeyboardEvent<HTMLDivElement>) => {
      const target = event.target;
      if (
        target !== event.currentTarget ||
        (target instanceof HTMLElement &&
          target.closest(
            'input, textarea, select, button, [contenteditable="true"], [role="textbox"], [role="button"]',
          ))
      ) {
        return;
      }

      const pageFlip = bookRef.current?.pageFlip();
      if (!pageFlip) return;

      const isForward =
        event.key === 'Enter' ||
        event.key === ' ' ||
        event.key === 'Spacebar' ||
        event.key === 'ArrowRight' ||
        event.key === 'PageDown';
      const isBackward = event.key === 'ArrowLeft' || event.key === 'PageUp';
      if (!isForward && !isBackward) return;

      event.preventDefault();
      const direction = isForward ? 'forward' : 'back';
      turnDirectionRef.current = direction;
      setIsClosingCover(
        isBackward && !isCoverVisible && activePageIndex === 0,
      );
      if (isForward) {
        pageFlip.flipNext('bottom');
      } else {
        pageFlip.flipPrev('bottom');
      }
    },
    [activePageIndex, isCoverVisible],
  );

  if (!journal) return null;

  if (pages.length === 0) {
    return (
      <div className="journal-book-frame relative flex h-[75vh] w-full max-w-[1200px] items-center justify-center px-4 py-8 md:h-[80vh] md:px-12">
        <section
          className="w-full max-w-md rounded-[2rem] border border-[var(--lj-line)] bg-white/90 px-8 py-12 text-center shadow-[0_24px_70px_rgba(16,16,16,0.10)] backdrop-blur-sm"
          aria-labelledby="empty-journal-title"
          aria-describedby="empty-journal-description"
        >
          <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-[var(--lj-soft)] text-[var(--lj-black)]">
            <BookOpen className="h-7 w-7" aria-hidden="true" />
          </div>
          <h2
            id="empty-journal-title"
            className="text-2xl font-semibold tracking-tight text-[var(--lj-black)]"
          >
            Your journal is ready
          </h2>
          <p
            id="empty-journal-description"
            className="mx-auto mt-3 max-w-sm text-sm leading-6 text-[var(--lj-muted)]"
          >
            Add your first page and start collecting the moments, words, and
            memories that matter to you.
          </p>
          <Button
            type="button"
            onClick={state.addPage}
            className="mt-7 rounded-full px-6"
          >
            <Plus className="mr-2 h-4 w-4" aria-hidden="true" />
            Add first page
          </Button>
        </section>
      </div>
    );
  }

  return (
    <div
      className="journal-book-frame relative w-full max-w-[1200px] h-[75vh] md:h-[80vh] flex items-center justify-center px-4 md:px-12 py-8 mt-12 mb-24 md:mb-16"
      data-journal-page-count={pages.length}
      data-active-page-index={activePageIndex}
      data-active-page-style={pages[activePageIndex]?.backgroundStyle ?? ''}
      data-cover-visible={isCoverVisible}
      data-cover-closing={isClosingCover}
      data-book-flipping={isFlipping}
    >
      <div
        ref={stageRef}
        className="journal-book-stage relative w-full h-full max-w-[1000px] flex items-center justify-center"
        tabIndex={0}
        role="region"
        aria-label="Little Journal book"
        aria-describedby="journal-book-keyboard-instructions"
        onKeyDown={handleStageKeyDown}
        onPointerDownCapture={handlePageGestureStart}
        onPointerUpCapture={handlePageGestureEnd}
        onPointerCancelCapture={handlePageGestureCancel}
      >
        <p id="journal-book-keyboard-instructions" className="sr-only">
          Use Enter or Space to open or advance the journal. Use the right
          arrow or Page Down to advance, and the left arrow or Page Up to go
          back. Select an item on a page to edit it.
        </p>
        {bookBounds.width > 0 && activePageIndex > 0 && (
          <div
            className="journal-book-overhang-layer"
            aria-hidden="true"
            style={{
              left: bookBounds.left,
              top: bookBounds.top,
              width: bookBounds.width,
              height: bookBounds.height,
            }}
          >
            {pages
              .slice(0, activePageIndex)
              .map((page, pageIndex) => (
              <div
                key={`past-overhang-${page.id}`}
                className="journal-book-overhang-page"
                style={{ width: bookBounds.pageWidth, zIndex: pageIndex + 1 }}
              >
                <JournalPageComp
                  page={page}
                  state={state}
                  isLeft={true}
                  interactive={false}
                  overhangOnly
                  mirrorOverhangX={pageIndex % 2 === 1}
                  overhangBackFace={pageIndex % 2 === 1}
                  overhangRegion="outer"
                />
              </div>
              ))}
          </div>
        )}
        {bookBounds.width > 0 && isCoverVisible && !isFlipping && pages[0] && (
          <div
            className="journal-book-cover-overhang-layer"
            aria-hidden="true"
            style={{
              left: bookBounds.left,
              top: bookBounds.top,
              width: bookBounds.pageWidth,
              height: bookBounds.height,
            }}
          >
            {pages.slice(0, 2).map((page, pageIndex) => (
              <div
                key={`cover-overhang-${page.id}`}
                className="journal-book-overhang-page"
                style={{ width: bookBounds.pageWidth, zIndex: pageIndex + 1 }}
              >
                <JournalPageComp
                  page={page}
                  state={pageInteractionState}
                  isLeft={pageIndex === 0}
                  interactive={false}
                  overhangOnly
                  overhangRegion={pageIndex === 0 ? 'cover-left' : 'cover-right'}
                />
              </div>
            ))}
          </div>
        )}

        <PageRenderContext.Provider value={pageRenderContext}>
          <HTMLFlipBook
            ref={bookRef}
            className="journal-flipbook"
            style={{}}
            width={isShortLandscape ? shortLandscapePageSize.width : 500}
            height={isShortLandscape ? shortLandscapePageSize.height : 700}
            size={isShortLandscape ? 'fixed' : 'stretch'}
            minWidth={isShortLandscape ? shortLandscapePageSize.width : 280}
            maxWidth={isShortLandscape ? shortLandscapePageSize.width : 500}
            minHeight={isShortLandscape ? shortLandscapePageSize.height : 420}
            maxHeight={isShortLandscape ? shortLandscapePageSize.height : 760}
            startPage={0}
            drawShadow={false}
            flippingTime={850}
            usePortrait={!isShortLandscape}
            startZIndex={10}
            autoSize={!isShortLandscape}
            maxShadowOpacity={0}
            showCover
            mobileScrollSupport
            clickEventForward={false}
            useMouseEvents={false}
            swipeDistance={30}
            showPageCorners={false}
            disableFlipByClick
            renderOnlyPageLengthChange
            onFlip={handleFlip}
            onChangeState={handleFlipState}
            onUpdate={handleBookUpdate}
            onInit={(event: { data: { page: number } }) => {
              setActivePageIndex(event.data.page);
            }}
          >
            {pageNodes}
          </HTMLFlipBook>
        </PageRenderContext.Provider>
        {!isCoverVisible && isFlipping && bookBounds.height > 0 && (
            <div
              className="journal-book-spine-fold"
              aria-hidden="true"
              style={{
                left: '50%',
                top: bookBounds.top,
                height: bookBounds.height,
              }}
            />
          )}
        {dragPreview && dragPreview.stageRect.width > 0 && dragPreview.stageRect.height > 0 && (
          <div className="journal-book-drag-layer" aria-hidden="true">
            <DragPreview
              preview={dragPreview}
              stageRef={stageRef}
            />
          </div>
        )}
      </div>
    </div>
  );
}