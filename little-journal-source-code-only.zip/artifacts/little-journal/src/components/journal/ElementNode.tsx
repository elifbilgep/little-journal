import { useRef, useState, useEffect } from 'react';
import { motion, useDragControls, useMotionValue } from 'framer-motion';
import { JournalElement } from '@/lib/types';
import { Trash2, RotateCw, Type, AlignLeft, AlignCenter, AlignRight, Coffee, LocateFixed, Palette } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { FONTS, COLORS, STICKERS, STICKER_COLORS } from '@/lib/constants';
import { isElementOffscreen } from '@/lib/use-journal-state';

export default function ElementNode({ 
  element, 
  pageId, 
  state,
  pageRef,
  readOnly = false,
  dragPreview = false,
  overhangClone = false,
  backFace = false,
}: { 
  element: JournalElement; 
  pageId: string; 
  state: any;
  pageRef: React.RefObject<HTMLDivElement | null>;
  readOnly?: boolean;
  dragPreview?: boolean;
  overhangClone?: boolean;
  backFace?: boolean;
}) {
  const isSelected = state.selectedElementId === element.id;
  const isHiddenDragSource =
    !dragPreview && state.draggingElementId === element.id;
  const elRef = useRef<HTMLDivElement>(null);
  const textEditorRef = useRef<HTMLDivElement>(null);
  const textInputChangedRef = useRef(false);
  const dragX = useMotionValue(0);
  const dragY = useMotionValue(0);
  const dragControls = useDragControls();
  const isEditingText = element.type === 'text' && isSelected;

  useEffect(() => {
    const node = elRef.current;
    if (!node || readOnly) return;

    // PageFlip listens for native mouse/touch events on the book root.
    // Keep element editing gestures local so dragging a photo or text block
    // never starts turning the paper underneath it.
    const stopPageTurn = (event: Event) => event.stopPropagation();
    node.addEventListener('mousedown', stopPageTurn);
    node.addEventListener('touchstart', stopPageTurn, { passive: true });

    return () => {
      node.removeEventListener('mousedown', stopPageTurn);
      node.removeEventListener('touchstart', stopPageTurn);
    };
  }, [readOnly]);

  useEffect(() => {
    if (readOnly || element.type !== 'text' || !isSelected) return;

    const frame = window.requestAnimationFrame(() => {
      const editor = textEditorRef.current;
      if (!editor) return;

      editor.focus({ preventScroll: true });

      const selection = window.getSelection();
      if (!selection) return;

      const range = document.createRange();
      range.selectNodeContents(editor);
      range.collapse(false);
      selection.removeAllRanges();
      selection.addRange(range);
    });

    return () => window.cancelAnimationFrame(frame);
  }, [element.id, element.type, isSelected, readOnly]);

  useEffect(() => {
    if (readOnly || !isSelected || element.type === 'text') return;

    const frame = window.requestAnimationFrame(() => {
      elRef.current?.focus({ preventScroll: true });
    });

    return () => window.cancelAnimationFrame(frame);
  }, [element.id, element.type, isSelected, readOnly]);
  
  const selectElement = () => {
    state.setSelectedElementId(element.id);
    state.bringToFront(pageId, element.id);
  };

  const handleSelect = (e: React.SyntheticEvent) => {
    if (readOnly) return;
    e.stopPropagation();
    selectElement();
  };

  const handleDragEnd = () => {
    const preserveSelection = () => {
      window.requestAnimationFrame(() => {
        state.setSelectedElementId(element.id);
      });
    };

    if (!pageRef.current) {
      state.onElementDragEnd?.(pageId, element.id, elRef.current);
      preserveSelection();
      return;
    }
    const pageBounds = pageRef.current.getBoundingClientRect();

    const nextX = element.x + (dragX.get() / pageBounds.width) * 100;
    const nextY = element.y + (dragY.get() / pageBounds.height) * 100;

    dragX.set(0);
    dragY.set(0);

    const sourcePageIndex = state.pages?.findIndex(
      (page: { id: string }) => page.id === pageId,
    ) ?? -1;
    const sourceIsLeft = sourcePageIndex >= 0 && sourcePageIndex % 2 === 0;
    const targetPageIndex = sourceIsLeft
      ? sourcePageIndex + 1
      : sourcePageIndex - 1;
    const targetPage = state.pages?.[targetPageIndex];
    const angle = (element.rotation * Math.PI) / 180;
    const halfWidth = element.width / 2;
    const halfHeight = element.height / 2;
    const centerX = nextX + halfWidth;
    const extentX =
      Math.abs(Math.cos(angle)) * halfWidth +
      Math.abs(Math.sin(angle)) * halfHeight;
    const minX = centerX - extentX;
    const maxX = centerX + extentX;
    const crossedIntoAdjacentPage =
      targetPage &&
      ((sourceIsLeft && minX >= 100) ||
        (!sourceIsLeft && maxX <= 0));
    const spineX = sourceIsLeft ? 100 : 0;
    const nearSpine =
      sourceIsLeft ? maxX >= spineX - 3 : minX <= spineX + 3;
    const shouldSnapToSpine =
      element.type === 'photo' &&
      Boolean(targetPage) &&
      !crossedIntoAdjacentPage &&
      nearSpine;
    const settledX = shouldSnapToSpine
      ? spineX - element.width / 2
      : nextX;
    const transferredX = sourceIsLeft ? nextX - 100 : nextX + 100;
    const updatePosition = (el: JournalElement) => ({
      ...el,
      x: crossedIntoAdjacentPage ? transferredX : settledX,
      y: nextY,
    });

    if (crossedIntoAdjacentPage) {
      state.moveElementToPage(
        pageId,
        targetPage.id,
        element.id,
        updatePosition,
      );
    } else {
      state.updateElement(pageId, element.id, updatePosition);
    }
    state.onElementDragEnd?.(pageId, element.id, elRef.current);
    preserveSelection();
  };

  const handleDragStart = () => {
    if (readOnly) return;
    if (element.type !== 'text') {
      state.onElementDragStart?.(pageId, element, elRef.current);
    }
  };

  const handleDrag = () => {
    if (readOnly) return;
    if (element.type !== 'text') {
      state.onElementDragMove?.(pageId, element.id, dragX.get(), dragY.get());
    }
  };

  const handleSelectedTextDragStart = (
    event: React.PointerEvent<HTMLDivElement>,
  ) => {
    event.stopPropagation();
    dragControls.start(event);
  };

  const handleSelectedElementDragStart = (
    event: React.PointerEvent<HTMLDivElement>,
  ) => {
    if (readOnly || !isSelected || element.type === 'text') return;
    event.stopPropagation();
    dragControls.start(event);
  };

  const handleDelete = () => {
    state.deleteElement(pageId, element.id);
  };

  const handleElementKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    if (
      readOnly ||
      !isSelected ||
      event.target !== event.currentTarget ||
      event.altKey && !event.key.startsWith('Arrow')
    ) {
      return;
    }

    const arrowDirections: Record<string, { x: number; y: number }> = {
      ArrowLeft: { x: -1, y: 0 },
      ArrowRight: { x: 1, y: 0 },
      ArrowUp: { x: 0, y: -1 },
      ArrowDown: { x: 0, y: 1 },
    };
    const direction = arrowDirections[event.key];

    if (event.key === 'Delete' || event.key === 'Backspace') {
      event.preventDefault();
      event.stopPropagation();
      handleDelete();
      return;
    }

    if (!direction) return;

    event.preventDefault();
    event.stopPropagation();
    if (event.altKey) {
      const rotationStep =
        event.key === 'ArrowLeft' || event.key === 'ArrowUp' ? -5 : 5;
      state.updateElement(pageId, element.id, (current: JournalElement) => ({
        ...current,
        rotation: current.rotation + rotationStep,
      }));
      return;
    }

    if (event.shiftKey) {
      const resizeStep =
        event.key === 'ArrowLeft' || event.key === 'ArrowUp' ? -1 : 1;
      state.updateElement(pageId, element.id, (current: JournalElement) => ({
        ...current,
        width: Math.max(5, current.width + resizeStep),
        height: Math.max(5, current.height + resizeStep),
      }));
      return;
    }

    state.updateElement(pageId, element.id, (current: JournalElement) => ({
      ...current,
      x: current.x + direction.x,
      y: current.y + direction.y,
    }));
  };

  // Custom Rotation handler
  const handleRotate = (e: React.PointerEvent<HTMLDivElement>) => {
    e.stopPropagation();
    e.preventDefault();
    if (!elRef.current) return;

    const pointerId = e.pointerId;
    const elBounds = elRef.current.getBoundingClientRect();
    const centerX = elBounds.left + elBounds.width / 2;
    const centerY = elBounds.top + elBounds.height / 2;

    const onMove = (moveEvent: PointerEvent) => {
      if (moveEvent.pointerId !== pointerId) return;
      moveEvent.preventDefault();

      const angle =
        Math.atan2(moveEvent.clientY - centerY, moveEvent.clientX - centerX) *
          (180 / Math.PI) +
        90;
      state.updateElement(pageId, element.id, (el: JournalElement) => ({
        ...el,
        rotation: Math.round(angle)
      }));
    };

    const onUp = (upEvent: PointerEvent) => {
      if (upEvent.pointerId !== pointerId) return;
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointercancel', onUp);
    };

    window.addEventListener('pointermove', onMove, { passive: false });
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);
  };

  // Custom Resize handler
  const handleResize = (e: React.PointerEvent<HTMLDivElement>) => {
    e.stopPropagation();
    e.preventDefault();
    if (!elRef.current || !pageRef.current) return;

    const pointerId = e.pointerId;
    const startX = e.clientX;
    const startWidth = element.width;
    const startHeight = element.height;
    const pageBounds = pageRef.current.getBoundingClientRect();
    let nextWidth = startWidth;
    let nextHeight = startHeight;
    let resizeFinished = false;

    const onMove = (moveEvent: PointerEvent) => {
      if (moveEvent.pointerId !== pointerId) return;
      moveEvent.preventDefault();

      const dx = ((moveEvent.clientX - startX) / pageBounds.width) * 100;

      // proportional scaling
      const scale = Math.max(0.1, 1 + (dx / startWidth));
      nextWidth = Math.max(5, startWidth * scale);
      nextHeight = Math.max(5, startHeight * scale);

      // Keep resize feedback synchronous with the pointer. Persist the final
      // dimensions once on release instead of committing every intermediate
      // frame to journal history.
      if (elRef.current) {
        elRef.current.style.width = `${nextWidth}%`;
        elRef.current.style.height = `${nextHeight}%`;
      }
    };

    const onUp = (upEvent: PointerEvent) => {
      if (upEvent.pointerId !== pointerId || resizeFinished) return;
      resizeFinished = true;
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp, true);
      window.removeEventListener('pointercancel', onUp, true);

      state.updateElement(pageId, element.id, (el: JournalElement) => ({
        ...el,
        width: nextWidth,
        height: nextHeight,
      }));
    };

    window.addEventListener('pointermove', onMove, { passive: false });
    window.addEventListener('pointerup', onUp, true);
    window.addEventListener('pointercancel', onUp, true);
  };

  return (
    <motion.div
      ref={elRef}
      data-journal-element={dragPreview || overhangClone ? undefined : element.id}
      data-journal-drag-preview={dragPreview ? element.id : undefined}
      data-journal-overhang-clone={overhangClone ? element.id : undefined}
      data-element-type={element.type}
      aria-hidden={readOnly || undefined}
      tabIndex={isSelected && !readOnly ? 0 : -1}
      aria-label={
        isSelected && !readOnly
          ? `Selected ${element.type} element`
          : undefined
      }
      aria-describedby={
        isSelected && !readOnly
          ? `journal-element-keyboard-instructions-${element.id}`
          : undefined
      }
      aria-keyshortcuts={
        isSelected && !readOnly
          ? 'ArrowLeft ArrowRight ArrowUp ArrowDown Shift+ArrowLeft Shift+ArrowRight Shift+ArrowUp Shift+ArrowDown Alt+ArrowLeft Alt+ArrowRight Alt+ArrowUp Alt+ArrowDown Delete Backspace'
          : undefined
      }
      className={`absolute ${readOnly ? 'pointer-events-none' : 'cursor-grab active:cursor-grabbing'} ${isSelected && !readOnly ? 'z-50' : ''} ${isHiddenDragSource ? 'journal-element-source-hidden' : ''}`}
      style={{
        left: `${element.x}%`,
        top: `${element.y}%`,
        width: `${element.width}%`,
        height: `${element.height}%`,
        x: dragX,
        y: dragY,
        rotate: element.rotation,
        zIndex: isSelected && !readOnly ? 999 : element.zIndex,
      }}
      drag={!readOnly}
      dragControls={dragControls}
      dragListener={!isSelected}
      dragMomentum={false}
      dragElastic={0}
      onDragStart={handleDragStart}
      onDrag={handleDrag}
      onDragEnd={readOnly ? undefined : handleDragEnd}
      onKeyDown={handleElementKeyDown}
      onPointerDown={
        readOnly
          ? undefined
          : (event) => {
              if (element.type === 'text' && !isSelected) {
                event.stopPropagation();
                return;
              }
              handleSelect(event);
            }
      }
      onClick={
        readOnly
          ? undefined
          : (event) => {
              event.stopPropagation();
              if (element.type === 'text' && !isSelected) {
                selectElement();
              }
            }
      }
    >
      {isSelected && !readOnly && (
        <span
          id={`journal-element-keyboard-instructions-${element.id}`}
          className="sr-only"
        >
          Arrow keys move this element. Shift plus an arrow resizes it. Alt
          plus an arrow rotates it. Delete or Backspace removes it.
        </span>
      )}
      <div
        className={`relative w-full h-full transition-shadow duration-200 ${isSelected ? 'element-selected' : ''}`}
        onPointerDown={handleSelectedElementDragStart}
      >
        
        {/* Render Content Based on Type */}
        {element.type === 'photo' && backFace && (
          <div className="journal-photo-back h-full w-full rounded-[2px] border border-black/10 bg-[#fffdf8] shadow-[0_3px_9px_rgba(0,0,0,0.12)]" />
        )}

        {element.type === 'photo' && !backFace && (
          <div className="w-full h-full polaroid-frame flex flex-col pointer-events-none bg-white">
            {element.content.startsWith('/') ||
            element.content.startsWith('blob:') ||
            element.content.startsWith('data:image/') ? (
              <img 
                src={element.content} 
                className="w-full h-full object-cover rounded-[2px]" 
                alt="Memory" 
                draggable={false}
              />
            ) : element.content === 'demo:coffee' ? (
              <div className="relative flex h-full w-full items-center justify-center overflow-hidden rounded-[2px] bg-gradient-to-br from-[var(--lj-mist)] to-[var(--lj-line)]">
                <div className="absolute w-16 h-16 rounded-full border-4 border-white/80" />
                <div className="absolute w-20 h-20 rounded-full border border-white/60 translate-x-4 -translate-y-4" />
                <Coffee className="w-6 h-6 text-black/20" />
              </div>
            ) : element.content === 'demo:scenery' ? (
              <div className="relative flex h-full w-full items-center justify-center overflow-hidden rounded-[2px] bg-gradient-to-t from-[var(--lj-line)] to-white">
                <div className="absolute bottom-0 h-1/2 w-[150%] translate-y-10 scale-125 rounded-t-[100%] bg-[var(--lj-mist)]" />
                <div className="absolute w-8 h-8 bg-white rounded-full top-4 right-4" />
              </div>
            ) : element.content === 'demo:abstract' ? (
              <div className="relative flex h-full w-full items-center justify-center overflow-hidden rounded-[2px] bg-[var(--lj-soft)]">
                <div className="absolute h-full w-full bg-gradient-to-tr from-[var(--lj-mist)] to-transparent" />
                <div className="absolute -bottom-8 -left-8 h-24 w-24 rounded-full border-[12px] border-[var(--lj-line)]" />
                <div className="absolute right-8 top-8 h-12 w-12 rounded-full bg-[var(--lj-line)]/50" />
              </div>
            ) : (
              <div className="relative flex h-full w-full items-center justify-center overflow-hidden rounded-[2px] bg-gradient-to-br from-[var(--lj-line)] to-white">
                <div className="absolute w-32 h-32 rounded-full bg-white/50 blur-xl -top-10 -left-10" />
                <div className="absolute w-24 h-24 rounded-full bg-black/5 blur-lg bottom-0 right-0" />
              </div>
            )}
          </div>
        )}

        {element.type === 'sticker' && (
          <div className="w-full h-full flex items-center justify-center pointer-events-none drop-shadow-sm">
            <svg viewBox="0 0 24 24" className="h-full w-full" style={{ fill: element.style?.color || 'var(--lj-black)' }}>
              {STICKERS.find(s => s.id === element.content)?.path && (
                 <path d={STICKERS.find(s => s.id === element.content)?.path} />
              )}
            </svg>
          </div>
        )}

        {element.type === 'text' && (
          <div
            ref={textEditorRef}
            className="w-full h-full outline-none focus:outline-none leading-snug p-2"
            style={{
              fontFamily: element.style?.fontFamily || 'var(--app-font-handwriting)',
              fontSize: element.style?.fontSize || '1.5rem',
              color: element.style?.color || 'var(--lj-black)',
              textAlign: element.style?.textAlign || 'left',
            }}
            contentEditable={!readOnly && isSelected}
            suppressContentEditableWarning
            data-placeholder="Write something..."
            data-journal-text-editor={element.id}
            role="textbox"
            aria-label="Journal text"
            aria-multiline="true"
            spellCheck
            onFocus={() => {
              textInputChangedRef.current = false;
            }}
            onInput={() => {
              textInputChangedRef.current = true;
            }}
            onBlur={(e) => {
              const content = e.currentTarget.innerText;
              const wasEdited = textInputChangedRef.current;
              textInputChangedRef.current = false;

              if (!content.trim() && element.content.trim() && !wasEdited) {
                e.currentTarget.innerText = element.content;
                return;
              }
              if (content === element.content) return;

              state.updateElement(pageId, element.id, (el: JournalElement) => ({
                ...el,
                content,
              }));
            }}
            onKeyDown={(e) => e.stopPropagation()}
            onPointerDown={(e) => {
              if (!readOnly && isSelected) {
                e.stopPropagation();
              }
            }}
            onContextMenu={(e) => {
              if (!readOnly && isSelected) {
                e.stopPropagation();
              }
            }}
          >
            {element.content}
          </div>
        )}

        {/* Controls Overlay */}
        {isSelected && !readOnly && (
          <div className="absolute -inset-4 pointer-events-none">
            {element.type === 'text' && (
              <>
                <div
                  className="pointer-events-auto absolute left-2 right-2 top-2 z-40 h-4 touch-none cursor-move"
                  data-journal-element-drag-handle={element.id}
                  onPointerDown={handleSelectedTextDragStart}
                  aria-hidden="true"
                />
                <div
                  className="pointer-events-auto absolute bottom-2 left-2 right-2 z-40 h-4 touch-none cursor-move"
                  data-journal-element-drag-handle={element.id}
                  onPointerDown={handleSelectedTextDragStart}
                  aria-hidden="true"
                />
                <div
                  className="pointer-events-auto absolute bottom-2 left-2 top-2 z-40 w-4 touch-none cursor-move"
                  data-journal-element-drag-handle={element.id}
                  onPointerDown={handleSelectedTextDragStart}
                  aria-hidden="true"
                />
                <div
                  className="pointer-events-auto absolute bottom-2 right-2 top-2 z-40 w-4 touch-none cursor-move"
                  data-journal-element-drag-handle={element.id}
                  onPointerDown={handleSelectedTextDragStart}
                  aria-hidden="true"
                />
              </>
            )}

            {/* Delete */}
            <button 
              className="pointer-events-auto absolute -left-3 -top-3 z-50 flex h-8 w-8 items-center justify-center rounded-full border border-[var(--lj-line)] bg-white text-[var(--lj-danger)] shadow-[0_4px_12px_rgba(16,16,16,0.1)] transition-all hover:scale-110 hover:bg-[#fff0f0] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--lj-blue)]"
              onPointerDown={(e) => { e.stopPropagation(); handleDelete(); }}
              aria-label="Delete element"
            >
              <Trash2 className="w-4 h-4" />
            </button>

            {isElementOffscreen(element) && (
              <button
                className="pointer-events-auto absolute -right-3 -top-3 z-50 flex h-8 w-8 items-center justify-center rounded-full border border-[var(--lj-line)] bg-white text-[var(--lj-blue)] shadow-[0_4px_12px_rgba(16,16,16,0.1)] transition-all hover:scale-110 hover:bg-[var(--lj-soft)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--lj-blue)]"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  state.bringElementIntoView(pageId, element.id);
                }}
                aria-label="Bring element into view"
                title="Bring into view"
              >
                <LocateFixed className="h-4 w-4" />
              </button>
            )}
            
            {/* Rotate */}
            <div 
              className="pointer-events-auto absolute -top-8 left-1/2 z-50 flex h-8 w-8 -translate-x-1/2 touch-none cursor-ew-resize items-center justify-center rounded-full border border-[var(--lj-line)] bg-white text-[var(--lj-black)] shadow-[0_4px_12px_rgba(16,16,16,0.1)] transition-transform hover:scale-110"
              onPointerDown={handleRotate}
            >
              <RotateCw className="w-4 h-4" />
            </div>

            {/* Resize */}
            <div 
              className="pointer-events-auto absolute -bottom-3 -right-3 z-50 flex h-8 w-8 touch-none cursor-nwse-resize items-center justify-center rounded-full border border-[var(--lj-line)] bg-white text-[var(--lj-black)] shadow-[0_4px_12px_rgba(16,16,16,0.1)] transition-transform hover:scale-110"
              onPointerDown={handleResize}
            >
              <div className="h-2 w-2 rounded-full bg-[var(--lj-blue)]" />
            </div>

            {/* Text Formatting Menu */}
            {element.type === 'text' && (
              <Popover>
                <PopoverTrigger asChild>
                  <button 
                    className="pointer-events-auto absolute -bottom-10 left-1/2 z-50 flex -translate-x-1/2 items-center gap-2 rounded-full border border-[var(--lj-line)] bg-white px-3 py-1 text-[10px] font-bold uppercase tracking-[0.05em] text-[var(--lj-black)] shadow-[0_4px_12px_rgba(16,16,16,0.1)] hover:bg-[var(--lj-soft)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--lj-blue)]"
                    onPointerDown={(e) => e.stopPropagation()}
                  >
                    <Type className="w-3.5 h-3.5" /> Format
                  </button>
                </PopoverTrigger>
                <PopoverContent className="pointer-events-auto w-auto rounded-xl border border-[var(--lj-line)] bg-white p-2 shadow-lg" onPointerDown={e => e.stopPropagation()}>
                  <div className="flex flex-col gap-2">
                    <div className="flex gap-1">
                      {FONTS.map(f => (
                        <Button 
                          key={f.id} 
                          variant="ghost" 
                          size="sm" 
                          style={{ fontFamily: f.id }}
                          onClick={() => state.updateElement(pageId, element.id, (el: any) => ({...el, style: {...el.style, fontFamily: f.id}}))}
                          className={element.style?.fontFamily === f.id ? 'bg-[var(--lj-soft)] text-[var(--lj-blue)]' : ''}
                        >
                          Aa
                        </Button>
                      ))}
                    </div>
                    <div className="flex gap-1 justify-center">
                      <Button variant="ghost" size="icon" onClick={() => state.updateElement(pageId, element.id, (el: any) => ({...el, style: {...el.style, textAlign: 'left'}}))}>
                        <AlignLeft className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => state.updateElement(pageId, element.id, (el: any) => ({...el, style: {...el.style, textAlign: 'center'}}))}>
                        <AlignCenter className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => state.updateElement(pageId, element.id, (el: any) => ({...el, style: {...el.style, textAlign: 'right'}}))}>
                        <AlignRight className="w-4 h-4" />
                      </Button>
                    </div>
                    <div className="flex gap-1 justify-center">
                      {COLORS.map(c => (
                        <button
                          key={c}
                          className="h-6 w-6 rounded-full border border-black/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--lj-blue)]"
                          style={{ backgroundColor: c }}
                          onClick={() => state.updateElement(pageId, element.id, (el: any) => ({...el, style: {...el.style, color: c}}))}
                        />
                      ))}
                    </div>
                  </div>
                </PopoverContent>
              </Popover>
            )}

            {element.type === 'sticker' && (
              <Popover>
                <PopoverTrigger asChild>
                  <button
                    className="pointer-events-auto absolute -bottom-10 left-1/2 z-50 flex -translate-x-1/2 items-center gap-2 rounded-full border border-[var(--lj-line)] bg-white px-3 py-1 text-[10px] font-bold uppercase tracking-[0.05em] text-[var(--lj-black)] shadow-[0_4px_12px_rgba(16,16,16,0.1)] hover:bg-[var(--lj-soft)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--lj-blue)]"
                    onPointerDown={(event) => event.stopPropagation()}
                    aria-label="Change sticker color"
                  >
                    <Palette className="h-3.5 w-3.5" />
                    Color
                  </button>
                </PopoverTrigger>
                <PopoverContent
                  className="pointer-events-auto w-52 rounded-xl border border-[var(--lj-line)] bg-white p-3 shadow-lg"
                  onPointerDown={(event) => event.stopPropagation()}
                >
                  <div className="mb-2 text-[10px] font-bold uppercase tracking-[0.12em] text-[var(--lj-muted)]">
                    Sticker color
                  </div>
                  <div className="grid grid-cols-6 gap-2">
                    {STICKER_COLORS.map((color) => {
                      const selectedColor =
                        element.style?.color ??
                        STICKERS.find((sticker) => sticker.id === element.content)?.color ??
                        '#101010';
                      const active = selectedColor.toLowerCase() === color.toLowerCase();
                      return (
                        <button
                          key={color}
                          type="button"
                          className={`h-7 w-7 rounded-full border transition-transform hover:scale-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--lj-blue)] focus-visible:ring-offset-2 ${
                            active
                              ? 'ring-2 ring-[var(--lj-blue)] ring-offset-2'
                              : 'border-black/15'
                          }`}
                          style={{ backgroundColor: color }}
                          onClick={() =>
                            state.updateElement(
                              pageId,
                              element.id,
                              (current: JournalElement) => ({
                                ...current,
                                style: { ...current.style, color },
                              }),
                            )
                          }
                          aria-label={`Set sticker color to ${color}`}
                          aria-pressed={active}
                        />
                      );
                    })}
                  </div>
                </PopoverContent>
              </Popover>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
}
