import {
  forwardRef,
  useCallback,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import HTMLFlipBook from 'react-pageflip';
import { useReducedMotion } from 'framer-motion';
import {
  ArrowLeft,
  ArrowRight,
  Images,
  Move,
  RotateCw,
  Sticker,
} from 'lucide-react';
import { JOURNAL_COVERS, PAGE_STYLES } from '@/lib/constants';

const asset = (filename: string) => {
  const base = import.meta.env.BASE_URL.endsWith('/')
    ? import.meta.env.BASE_URL
    : `${import.meta.env.BASE_URL}/`;
  return `${base}images/${filename}`;
};

const steps = [
  {
    eyebrow: '01 / PICK A COVER',
    title: 'Choose the journal that feels like yours.',
  },
  {
    eyebrow: '02 / CHOOSE YOUR PAPER',
    title: 'Set the mood on every page.',
  },
  {
    eyebrow: '03 / KEEP THE MOMENT',
    title: 'Photo cards turn camera-roll memories into keepsakes.',
  },
  {
    eyebrow: '04 / MAKE A MESS',
    title: 'Move it, resize it, rotate it. There is no wrong layout.',
  },
] as const;

const onboardingPageStyles = PAGE_STYLES.filter((style) =>
  ['lined', 'grid', 'dot'].includes(style.id),
);

type PageFlipRef = {
  pageFlip: () =>
    | {
        flipNext: (corner?: 'top' | 'bottom') => void;
        flipPrev: (corner?: 'top' | 'bottom') => void;
      }
    | undefined;
};

const OnboardingPage = forwardRef<
  HTMLDivElement,
  { children: ReactNode; label: string }
>(({ children, label }, ref) => (
  <div
    ref={ref}
    className="onboarding-flipbook-page"
    data-density="soft"
    aria-label={label}
  >
    {children}
  </div>
));

OnboardingPage.displayName = 'OnboardingPage';

const primaryButton =
  'inline-flex items-center justify-center gap-1.5 rounded-lg bg-[var(--lj-black)] px-5 py-2.5 text-[10px] font-bold uppercase tracking-[0.14em] text-white transition hover:bg-[var(--lj-blue)] disabled:cursor-wait disabled:opacity-60 focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-[var(--lj-blue)]/60';

const backButton =
  'inline-flex size-9 items-center justify-center rounded-full border border-[var(--lj-line)] bg-white text-[var(--lj-black)] transition hover:bg-[var(--lj-soft)] disabled:cursor-wait disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--lj-blue)]';

function getShortLandscapePageSize() {
  if (typeof window === 'undefined') {
    return { width: 360, height: 252 };
  }

  const height = Math.max(180, Math.min(360, window.innerHeight - 140));
  return {
    width: Math.floor(Math.min((window.innerWidth - 64) / 2, height * 1.55)),
    height,
  };
}

function getSpreadPageSize() {
  if (typeof window === 'undefined') {
    return { width: 500, height: 700 };
  }

  const bookWidth = Math.min(1000, Math.max(560, window.innerWidth * 0.75));
  const width = Math.floor(bookWidth / 2);
  return {
    width,
    height: Math.floor(width * 1.4),
  };
}

export default function Onboarding({
  onComplete,
  onBack,
}: {
  onComplete: (coverId: string, pageStyle: string) => Promise<void> | void;
  onBack: () => void;
}) {
  const [selectedCover, setSelectedCover] = useState<string>(
    JOURNAL_COVERS[0].id,
  );
  const [selectedPageStyle, setSelectedPageStyle] = useState('lined');
  const [activeStep, setActiveStep] = useState(0);
  const [isDesktop, setIsDesktop] = useState(() =>
    typeof window === 'undefined'
      ? true
      : window.matchMedia('(min-width: 768px)').matches,
  );
  const [isShortLandscape, setIsShortLandscape] = useState(() =>
    typeof window !== 'undefined' &&
    window.matchMedia('(orientation: landscape) and (max-height: 600px)').matches,
  );
  const [shortLandscapePageSize, setShortLandscapePageSize] = useState(
    getShortLandscapePageSize,
  );
  const [spreadPageSize, setSpreadPageSize] = useState(getSpreadPageSize);
  const [isReady, setIsReady] = useState(false);
  const [isFlipping, setIsFlipping] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const bookRef = useRef<PageFlipRef | null>(null);
  const reducedMotion = useReducedMotion();

  useEffect(() => {
    const media = window.matchMedia('(min-width: 768px)');
    const shortLandscape = window.matchMedia(
      '(orientation: landscape) and (max-height: 600px)',
    );
    const updateLayout = (event: MediaQueryListEvent) => {
      setIsDesktop(event.matches);
      setActiveStep(0);
      setIsReady(false);
      setIsFlipping(false);
    };
    const updateOrientation = (event: MediaQueryListEvent) => {
      setIsShortLandscape(event.matches);
      setShortLandscapePageSize(getShortLandscapePageSize());
      setActiveStep(0);
      setIsReady(false);
      setIsFlipping(false);
    };
    const updatePageSize = () => {
      setShortLandscapePageSize(getShortLandscapePageSize());
      setSpreadPageSize(getSpreadPageSize());
    };

    media.addEventListener('change', updateLayout);
    shortLandscape.addEventListener('change', updateOrientation);
    window.addEventListener('resize', updatePageSize);
    return () => {
      media.removeEventListener('change', updateLayout);
      shortLandscape.removeEventListener('change', updateOrientation);
      window.removeEventListener('resize', updatePageSize);
    };
  }, []);

  const usesSpread = isDesktop || isShortLandscape;
  const isFixedSpread = usesSpread;
  const pageToStep = useCallback(
    (pageIndex: number) =>
      Math.min(
        steps.length - 1,
        usesSpread ? Math.floor(pageIndex / 2) : pageIndex,
      ),
    [usesSpread],
  );

  const goTo = (nextStep: number) => {
    if (
      nextStep < 0 ||
      nextStep >= steps.length ||
      !isReady ||
      isFlipping
    ) {
      return;
    }

    const pageFlip = bookRef.current?.pageFlip();
    if (!pageFlip) return;

    setError(null);
    setIsFlipping(true);

    if (nextStep > activeStep) {
      pageFlip.flipNext('bottom');
    } else {
      pageFlip.flipPrev('bottom');
    }
  };

  const finish = async () => {
    if (isSubmitting || isFlipping) return;
    setIsSubmitting(true);
    setError(null);

    try {
      await onComplete(selectedCover, selectedPageStyle);
    } catch {
      setError('Your journal could not be created. Please try again.');
      setIsSubmitting(false);
    }
  };

  const coverPicker = (
    <div className="onboarding-cover-grid grid grid-cols-4 gap-2">
      {JOURNAL_COVERS.map((cover) => (
        <button
          key={cover.id}
          type="button"
          onClick={() => setSelectedCover(cover.id)}
          aria-label={`Select ${cover.name} cover`}
          aria-pressed={selectedCover === cover.id}
          className={`relative aspect-[4/5] overflow-hidden rounded-lg border bg-[var(--lj-soft)] transition focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-[var(--lj-blue)] ${
            selectedCover === cover.id
              ? 'scale-[1.03] border-[var(--lj-blue)] shadow-[0_8px_16px_rgba(75,116,255,0.15)]'
              : 'border-transparent opacity-70 hover:scale-[1.03] hover:opacity-100'
          }`}
        >
          <img
            src={asset(cover.src)}
            alt=""
            className="h-full w-full object-cover"
          />
        </button>
      ))}
    </div>
  );

  const pageStylePicker = (
    <div className="mt-7">
      <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--lj-blue)]">
        Choose the paper
      </p>
      <p className="mt-2 text-xs leading-5 text-[var(--lj-muted)]">
        Pick a starting style for every page. You can still change one page
        later from the journal toolbar.
      </p>
      <div className="mt-3 grid grid-cols-3 gap-2">
        {onboardingPageStyles.map((style) => (
          <button
            key={style.id}
            type="button"
            onClick={() => setSelectedPageStyle(style.id)}
            aria-label={`Use ${style.name} for all journal pages`}
            aria-pressed={selectedPageStyle === style.id}
            className={`rounded-lg border p-2 text-left transition focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-[var(--lj-blue)] ${
              selectedPageStyle === style.id
                ? 'border-[var(--lj-blue)] bg-[var(--lj-soft)] shadow-[0_6px_14px_rgba(75,116,255,0.12)]'
                : 'border-[var(--lj-line)] bg-white hover:border-[var(--lj-blue)]/50'
            }`}
          >
            <span
              className={`block h-14 rounded-md border border-black/5 page-style-${style.id}`}
              aria-hidden="true"
            />
            <span className="mt-2 block text-[9px] font-bold uppercase tracking-[0.08em] text-[var(--lj-black)]">
              {style.id === 'dot'
                ? 'Dotted'
                : style.id === 'grid'
                  ? 'Squared'
                  : 'Lined'}
            </span>
          </button>
        ))}
      </div>
    </div>
  );

  const desktopPages = [
    <OnboardingPage key="cover-preview" label="Selected cover preview">
      <div className="onboarding-desktop-page flex h-full flex-col items-center justify-center bg-[var(--lj-soft)] p-10">
        <img
          src={asset(selectedCover)}
          alt={`${JOURNAL_COVERS.find((cover) => cover.id === selectedCover)?.name} journal cover`}
          className="h-[68%] w-[76%] object-contain drop-shadow-[0_28px_24px_rgba(16,16,16,0.12)]"
        />
        <div className="mt-5 rounded-full border border-[var(--lj-line)] bg-white px-4 py-2 text-[9px] font-bold uppercase tracking-[0.15em] text-[var(--lj-black)] shadow-[0_4px_12px_rgba(16,16,16,0.06)]">
          Your selected cover
        </div>
      </div>
    </OnboardingPage>,
    <OnboardingPage key="cover-picker" label="Choose a journal cover">
      <div className="onboarding-desktop-page flex h-full min-h-0 flex-col bg-white p-10">
        <p className="mb-3 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--lj-blue)]">
          Start with the outside
        </p>
        <h1 className="font-sans text-5xl font-extrabold leading-[1.03] tracking-[-0.06em] text-[var(--lj-black)]">
          {steps[0].title}
        </h1>
        <p className="mt-3 text-sm leading-6 text-[var(--lj-muted)]">
          Every memory starts with a cover. Pick one now; you can change it
          later.
        </p>
        <div className="mt-6 min-h-0 flex-1 overflow-y-auto p-1">
          {coverPicker}
        </div>
        <button
          type="button"
          onClick={() => goTo(1)}
          disabled={!isReady || isFlipping}
          className={`${primaryButton} onboarding-cover-next mt-5 self-end`}
        >
          Next: paper style
          <ArrowRight size={14} />
        </button>
      </div>
    </OnboardingPage>,
    <OnboardingPage key="page-style-picker" label="Choose a page style">
      <div className="onboarding-desktop-page flex h-full flex-col bg-white p-12">
        <p className="mb-3 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--lj-blue)]">
          Make it yours from the inside
        </p>
        <h2 className="font-sans text-5xl font-extrabold leading-[1.03] tracking-[-0.06em] text-[var(--lj-black)]">
          {steps[1].title}
        </h2>
        {pageStylePicker}
        <div className="onboarding-action-row mt-8 flex items-center justify-between">
          <button
            type="button"
            onClick={() => goTo(0)}
            disabled={!isReady || isFlipping}
            className={backButton}
            aria-label="Previous step"
          >
            <ArrowLeft size={14} strokeWidth={2.5} />
          </button>
          <button
            type="button"
            onClick={() => goTo(2)}
            disabled={!isReady || isFlipping}
            className={primaryButton}
          >
            Next: photo cards
            <ArrowRight size={14} />
          </button>
        </div>
      </div>
    </OnboardingPage>,
    <OnboardingPage key="page-style-preview" label="Page style preview">
      <div
        className={`onboarding-desktop-page flex h-full flex-col items-center justify-center p-10 page-style-${selectedPageStyle}`}
      >
        <p className="mb-3 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--lj-blue)]">
          Your pages, your rhythm
        </p>
        <div className="w-[72%] rounded-xl border border-black/10 bg-white/80 p-6 shadow-[0_16px_30px_rgba(16,16,16,0.08)]">
          <div className="font-handwriting text-3xl text-[var(--lj-black)]">
            A place for little things
          </div>
          <p className="mt-4 text-xs leading-6 text-[var(--lj-muted)]">
            Every starter page will use your selected paper. You can still
            give individual pages a different style later.
          </p>
        </div>
        <span className="mt-5 rounded-full border border-[var(--lj-line)] bg-white px-4 py-2 text-[9px] font-bold uppercase tracking-[0.15em] text-[var(--lj-black)]">
          {selectedPageStyle === 'dot'
            ? 'Dotted'
            : selectedPageStyle === 'grid'
              ? 'Squared'
              : 'Lined'}{' '}
          pages
        </span>
      </div>
    </OnboardingPage>,
    <OnboardingPage key="photos-preview" label="Photo card preview">
      <div className="onboarding-desktop-page relative h-full overflow-hidden bg-[var(--lj-soft)] p-10">
        <div className="absolute left-[9%] top-[13%] w-[49%] -rotate-6 border border-[var(--lj-line)] bg-white p-3 pb-10 shadow-[0_12px_24px_rgba(16,16,16,0.08)]">
          <img
            src={asset('journal-photo-besties.png')}
            alt="Friends sharing a memory"
            className="aspect-square w-full object-cover"
          />
          <span className="mt-2 block font-handwriting text-xl text-[var(--lj-black)]">
            besties forever
          </span>
        </div>
        <div className="absolute bottom-[10%] right-[8%] w-[46%] rotate-6 border border-[var(--lj-line)] bg-white p-3 pb-9 shadow-[0_16px_32px_rgba(16,16,16,0.1)]">
          <img
            src={asset('journal-photo-bubbles.png')}
            alt="A colorful moment with bubbles"
            className="aspect-square w-full object-cover"
          />
          <span className="mt-2 block font-handwriting text-xl text-[var(--lj-black)]">
            little magic
          </span>
        </div>
        <img
          src={asset('sticker-heart.png')}
          alt=""
          className="absolute right-[39%] top-[41%] w-24 -rotate-12 drop-shadow-md"
        />
      </div>
    </OnboardingPage>,
    <OnboardingPage key="photos-copy" label="Learn about photo cards">
      <div className="onboarding-desktop-page flex h-full flex-col justify-start bg-white p-12">
        <Images
          className="mb-6 text-[var(--lj-blue)]"
          size={32}
          strokeWidth={1.6}
        />
        <h2 className="font-sans text-5xl font-extrabold leading-[1.03] tracking-[-0.06em] text-[var(--lj-black)]">
          {steps[2].title}
        </h2>
        <p className="mt-5 text-sm leading-7 text-[var(--lj-muted)]">
          Drop in a photo and it becomes a card you can place anywhere. Add a
          caption, stack it with stickers, and keep the moment private.
        </p>
        <div className="onboarding-action-row mt-8 flex items-center justify-between">
          <button
            type="button"
            onClick={() => goTo(0)}
            disabled={!isReady || isFlipping}
            className={backButton}
            aria-label="Previous step"
          >
            <ArrowLeft size={14} strokeWidth={2.5} />
          </button>
          <button
            type="button"
            onClick={() => goTo(3)}
            disabled={!isReady || isFlipping}
            className={primaryButton}
          >
            Next: move and decorate
            <ArrowRight size={14} />
          </button>
        </div>
      </div>
    </OnboardingPage>,
    <OnboardingPage key="tools-copy" label="Learn about editing tools">
      <div className="onboarding-desktop-page flex h-full flex-col justify-start bg-white p-12">
        <p className="mb-3 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--lj-blue)]">
          Nothing is locked in place
        </p>
        <h2 className="font-sans text-5xl font-extrabold leading-[1.03] tracking-[-0.06em] text-[var(--lj-black)]">
          {steps[3].title}
        </h2>
        <div className="mt-8 grid grid-cols-3 gap-3">
          {[
            { icon: Move, label: 'Drag' },
            { icon: RotateCw, label: 'Rotate' },
            { icon: Sticker, label: 'Decorate' },
          ].map(({ icon: Icon, label }) => (
            <div
              key={label}
              className="rounded-xl border border-[var(--lj-line)] bg-[var(--lj-soft)] p-4 text-center text-[var(--lj-black)]"
            >
              <Icon
                className="mx-auto mb-2 text-[var(--lj-blue)]"
                size={21}
              />
              <span className="text-[9px] font-bold uppercase tracking-[0.14em]">
                {label}
              </span>
            </div>
          ))}
        </div>
        <p className="mt-7 text-sm leading-7 text-[var(--lj-muted)]">
          Turn real-looking pages, arrange every piece by hand, and come back
          whenever you want. Your journal saves as you work.
        </p>
      </div>
    </OnboardingPage>,
    <OnboardingPage key="ready" label="Open your journal">
      <div className="onboarding-desktop-page flex h-full flex-col items-center justify-center bg-[var(--lj-soft)] p-10">
        <img
          src={asset(selectedCover)}
          alt=""
          className="h-[58%] w-[76%] object-contain drop-shadow-[0_22px_20px_rgba(16,16,16,0.12)]"
        />
        <p className="mt-2 max-w-xs text-center font-handwriting text-3xl text-[var(--lj-black)]">
          Ready for your first page?
        </p>
        {error && (
          <p className="mt-3 text-center text-xs font-semibold text-[var(--lj-danger)]">
            {error}
          </p>
        )}
        <div className="onboarding-action-row mt-6 flex w-full items-center justify-between">
          <button
            type="button"
            onClick={() => goTo(2)}
            disabled={!isReady || isFlipping || isSubmitting}
            className={backButton}
            aria-label="Previous step"
          >
            <ArrowLeft size={14} strokeWidth={2.5} />
          </button>
          <button
            type="button"
            onClick={finish}
            disabled={isSubmitting || isFlipping}
            className="onboarding-finish-button rounded-lg bg-[var(--lj-blue)] px-6 py-3 text-[10px] font-bold uppercase tracking-[0.16em] text-white shadow-[0_8px_16px_rgba(75,116,255,0.2)] transition hover:bg-[var(--lj-black)] disabled:cursor-wait disabled:opacity-65 focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-[var(--lj-blue)]/60"
          >
            {isSubmitting ? 'Opening…' : 'Open my journal'}
          </button>
        </div>
      </div>
    </OnboardingPage>,
  ];

  const mobilePages = [
    <OnboardingPage key="mobile-cover" label="Choose a journal cover">
      <div className="onboarding-mobile-page onboarding-mobile-cover h-full overflow-y-auto bg-white p-6">
        <p className="onboarding-mobile-eyebrow mb-2 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--lj-blue)]">
          Start with the outside
        </p>
        <h1 className="onboarding-mobile-title font-sans text-3xl font-extrabold leading-[1.03] tracking-[-0.06em] text-[var(--lj-black)]">
          {steps[0].title}
        </h1>
        <img
          src={asset(selectedCover)}
          alt={`${JOURNAL_COVERS.find((cover) => cover.id === selectedCover)?.name} journal cover`}
          className="onboarding-mobile-cover-image mx-auto my-5 h-52 w-44 object-contain drop-shadow-[0_18px_16px_rgba(16,16,16,0.12)]"
        />
        {coverPicker}
        <button
          type="button"
          onClick={() => goTo(1)}
          disabled={!isReady || isFlipping}
          className={`${primaryButton} onboarding-mobile-primary mt-6 w-full`}
        >
          Next: paper style
          <ArrowRight size={14} />
        </button>
      </div>
    </OnboardingPage>,
    <OnboardingPage key="mobile-page-style" label="Choose a page style">
      <div className="onboarding-mobile-page h-full overflow-y-auto bg-white p-6">
        <p className="onboarding-mobile-eyebrow mb-2 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--lj-blue)]">
          Make it yours from the inside
        </p>
        <h2 className="onboarding-mobile-title font-sans text-3xl font-extrabold leading-[1.03] tracking-[-0.06em] text-[var(--lj-black)]">
          {steps[1].title}
        </h2>
        {pageStylePicker}
        <div className="onboarding-mobile-actions mt-6 flex items-center gap-3">
          <button
            type="button"
            onClick={() => goTo(0)}
            disabled={!isReady || isFlipping}
            className={backButton}
            aria-label="Previous step"
          >
            <ArrowLeft size={14} strokeWidth={2.5} />
          </button>
          <button
            type="button"
            onClick={() => goTo(2)}
            disabled={!isReady || isFlipping}
            className={`${primaryButton} flex-1`}
          >
            Next: photo cards
            <ArrowRight size={14} />
          </button>
        </div>
      </div>
    </OnboardingPage>,
    <OnboardingPage key="mobile-photos" label="Learn about photo cards">
      <div className="onboarding-mobile-page onboarding-mobile-photos h-full overflow-y-auto bg-white p-6">
        <Images
          className="onboarding-mobile-photo-icon mb-4 text-[var(--lj-blue)]"
          size={28}
          strokeWidth={1.6}
        />
        <h2 className="onboarding-mobile-title font-sans text-3xl font-extrabold leading-[1.03] tracking-[-0.06em] text-[var(--lj-black)]">
          {steps[2].title}
        </h2>
        <div className="onboarding-mobile-photo-stage relative my-5 h-56 overflow-hidden rounded-xl bg-[var(--lj-soft)]">
          <img
            src={asset('journal-photo-besties.png')}
            alt="Friends sharing a memory"
            className="absolute left-5 top-5 h-40 w-32 -rotate-6 border-8 border-white object-cover shadow-lg"
          />
          <img
            src={asset('journal-photo-bubbles.png')}
            alt="A colorful moment with bubbles"
            className="absolute bottom-5 right-5 h-40 w-32 rotate-6 border-8 border-white object-cover shadow-lg"
          />
        </div>
        <p className="onboarding-mobile-copy text-sm leading-6 text-[var(--lj-muted)]">
          Drop in a photo, add a caption, and stack it with stickers anywhere
          on the page.
        </p>
        <div className="onboarding-mobile-actions mt-6 flex items-center gap-3">
          <button
            type="button"
            onClick={() => goTo(0)}
            disabled={!isReady || isFlipping}
            className={backButton}
            aria-label="Previous step"
          >
            <ArrowLeft size={14} strokeWidth={2.5} />
          </button>
          <button
            type="button"
            onClick={() => goTo(2)}
            disabled={!isReady || isFlipping}
            className={`${primaryButton} flex-1`}
          >
            Next: move and decorate
            <ArrowRight size={14} />
          </button>
        </div>
      </div>
    </OnboardingPage>,
    <OnboardingPage key="mobile-tools" label="Open your journal">
      <div className="onboarding-mobile-page onboarding-mobile-tools h-full overflow-y-auto bg-white p-6">
        <p className="onboarding-mobile-eyebrow mb-2 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--lj-blue)]">
          Nothing is locked in place
        </p>
        <h2 className="onboarding-mobile-title font-sans text-3xl font-extrabold leading-[1.03] tracking-[-0.06em] text-[var(--lj-black)]">
          {steps[3].title}
        </h2>
        <div className="onboarding-mobile-tools-grid my-6 grid grid-cols-3 gap-2">
          {[
            { icon: Move, label: 'Drag' },
            { icon: RotateCw, label: 'Rotate' },
            { icon: Sticker, label: 'Decorate' },
          ].map(({ icon: Icon, label }) => (
            <div
              key={label}
              className="rounded-xl border border-[var(--lj-line)] bg-[var(--lj-soft)] p-3 text-center text-[var(--lj-black)]"
            >
              <Icon
                className="mx-auto mb-2 text-[var(--lj-blue)]"
                size={20}
              />
              <span className="text-[8px] font-bold uppercase tracking-[0.12em]">
                {label}
              </span>
            </div>
          ))}
        </div>
        <img
          src={asset(selectedCover)}
          alt=""
          className="onboarding-mobile-tools-cover mx-auto h-44 w-36 object-contain drop-shadow-[0_18px_16px_rgba(16,16,16,0.12)]"
        />
        {error && (
          <p className="mt-3 text-center text-xs font-semibold text-[var(--lj-danger)]">
            {error}
          </p>
        )}
        <div className="onboarding-mobile-actions mt-6 flex items-center gap-3">
          <button
            type="button"
            onClick={() => goTo(2)}
            disabled={!isReady || isFlipping || isSubmitting}
            className={backButton}
            aria-label="Previous step"
          >
            <ArrowLeft size={14} strokeWidth={2.5} />
          </button>
          <button
            type="button"
            onClick={finish}
            disabled={isSubmitting || isFlipping}
            className="flex-1 rounded-lg bg-[var(--lj-blue)] px-6 py-4 text-[11px] font-bold uppercase tracking-[0.17em] text-white shadow-[0_8px_16px_rgba(75,116,255,0.2)] transition hover:bg-[var(--lj-black)] disabled:cursor-wait disabled:opacity-65 focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-[var(--lj-blue)]/60"
          >
            {isSubmitting ? 'Opening…' : 'Open my journal'}
          </button>
        </div>
      </div>
    </OnboardingPage>,
  ];

  return (
    <main className="onboarding-shell relative flex min-h-[100dvh] w-full items-center justify-center overflow-hidden bg-[var(--lj-mist)] px-4 py-20 font-sans md:px-8 md:py-16">
      <img
        src={asset(selectedCover)}
        alt=""
        className="pointer-events-none absolute inset-[-12%] h-[124%] w-[124%] object-cover opacity-5 blur-[75px]"
      />

      <button
        type="button"
        onClick={onBack}
        className="onboarding-back absolute left-5 top-5 z-40 inline-flex items-center gap-2 rounded-full border border-[var(--lj-line)] bg-white px-4 py-2 text-[10px] font-bold uppercase tracking-[0.15em] text-[var(--lj-black)] shadow-[0_2px_10px_rgba(16,16,16,0.04)] transition hover:bg-[var(--lj-soft)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--lj-blue)]"
      >
        <ArrowLeft size={14} />
        Back
      </button>

      <div
        className="onboarding-content relative z-10 w-full max-w-6xl"
        style={
          isFixedSpread
            ? {
                maxWidth: Math.min(
                  1152,
                  (isShortLandscape
                    ? shortLandscapePageSize.width
                    : spreadPageSize.width) *
                    2 +
                    128,
                ),
              }
            : undefined
        }
      >
        <div className="onboarding-progress mb-5 flex items-center justify-between px-1 text-[var(--lj-black)]">
          <span className="text-[10px] font-bold uppercase tracking-[0.24em] text-[var(--lj-muted)]">
            {steps[activeStep].eyebrow}
          </span>
          <div
            className="flex gap-2"
            aria-label={`Step ${activeStep + 1} of ${steps.length}`}
          >
            {steps.map((_, index) => (
              <span
                key={index}
                className={`h-1.5 rounded-full transition-all ${
                  index === activeStep
                    ? 'w-8 bg-[var(--lj-black)]'
                    : 'w-1.5 bg-[var(--lj-line)]'
                }`}
              />
            ))}
          </div>
        </div>

        <div
          className="onboarding-stage relative mx-auto flex w-full items-center justify-center"
          style={
            isFixedSpread
              ? {
                  maxWidth:
                    (isShortLandscape
                      ? shortLandscapePageSize.width
                      : spreadPageSize.width) *
                      2 +
                    8,
                  height:
                    isShortLandscape
                      ? shortLandscapePageSize.height
                      : spreadPageSize.height,
                }
              : undefined
          }
        >
          <HTMLFlipBook
            key={
              isShortLandscape
                ? 'compact-landscape-spreads'
                : isDesktop
                  ? 'desktop-spreads'
                  : 'mobile-pages'
            }
            ref={bookRef}
            className="onboarding-flipbook"
            style={{}}
             width={
               isShortLandscape
                 ? shortLandscapePageSize.width
                 : isDesktop
                   ? spreadPageSize.width
                   : 500
             }
             height={
               isShortLandscape
                 ? shortLandscapePageSize.height
                 : isDesktop
                   ? spreadPageSize.height
                   : 700
             }
             size={isFixedSpread ? 'fixed' : 'stretch'}
             minWidth={
               isShortLandscape
                 ? shortLandscapePageSize.width
                 : isDesktop
                   ? spreadPageSize.width
                   : 280
             }
             maxWidth={
               isShortLandscape
                 ? shortLandscapePageSize.width
                 : isDesktop
                   ? spreadPageSize.width
                   : 500
             }
             minHeight={
               isShortLandscape
                 ? shortLandscapePageSize.height
                 : isDesktop
                   ? spreadPageSize.height
                   : 500
             }
             maxHeight={
               isShortLandscape
                 ? shortLandscapePageSize.height
                 : isDesktop
                   ? spreadPageSize.height
                   : 760
             }
            startPage={0}
            drawShadow
            flippingTime={reducedMotion ? 120 : 900}
             usePortrait={!isDesktop && !isShortLandscape}
            startZIndex={10}
             autoSize={!isFixedSpread}
            maxShadowOpacity={0.35}
            showCover={false}
            mobileScrollSupport
            clickEventForward
            useMouseEvents={false}
            swipeDistance={1000}
            showPageCorners={false}
            disableFlipByClick
            renderOnlyPageLengthChange={false}
            onFlip={(event: { data: number }) => {
              setActiveStep(pageToStep(Number(event.data)));
              setIsFlipping(false);
            }}
            onChangeState={(event: { data: string }) => {
              setIsFlipping(event.data === 'flipping');
            }}
            onInit={(event: { data: { page: number } }) => {
              setActiveStep(pageToStep(Number(event.data.page)));
              setIsReady(true);
            }}
          >
            {isDesktop || isShortLandscape ? desktopPages : mobilePages}
          </HTMLFlipBook>
        </div>
      </div>
    </main>
  );
}