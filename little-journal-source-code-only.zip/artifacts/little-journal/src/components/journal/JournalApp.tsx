import { useState } from 'react';
import { useJournalState } from '@/lib/use-journal-state';
import type { Journal } from '@/lib/types';
import JournalBook from './JournalBook';
import Toolbar from './Toolbar';
import { ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

export default function JournalApp({ initialJournal }: { initialJournal: Journal }) {
  return <JournalEditor initialJournal={initialJournal} />;
}

function JournalEditor({ initialJournal }: { initialJournal: Journal }) {
  const journalState = useJournalState(initialJournal, { localPersistence: true });
  const [isCoverVisible, setIsCoverVisible] = useState(true);

  const exitToHome = () => {
    window.location.assign(import.meta.env.BASE_URL || '/');
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-[100dvh] w-full flex flex-col items-center justify-center bg-[var(--lj-mist)] relative overflow-hidden perspective-[2000px]"
      onClick={() => journalState.setSelectedElementId(null)}
    >
      {!isCoverVisible && (
        <div className="absolute top-4 left-4 z-50 flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={exitToHome}
            className="rounded-full border-[var(--lj-line)] bg-white text-[var(--lj-black)] shadow-[0_2px_10px_rgba(16,16,16,0.04)] hover:bg-[var(--lj-soft)]"
            aria-label="Back to home"
          >
            <ArrowLeft className="mr-1.5 h-4 w-4" />
            Home
          </Button>
          <div className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.1em] text-[var(--lj-muted)] bg-white px-3 py-1.5 rounded-full shadow-[0_2px_10px_rgba(16,16,16,0.04)] border border-[var(--lj-line)]">
            {journalState.saveError ? (
              <>
                <span>Local save failed</span>
                <button type="button" onClick={journalState.retrySave} className="underline underline-offset-2 hover:text-[var(--lj-black)]">Retry</button>
              </>
            ) : journalState.isSaving ? 'Saving locally' : 'Saved locally'}
          </div>
        </div>
      )}
      <motion.div
        initial={{ rotateX: 20, scale: 0.9, y: 50, opacity: 0 }}
        animate={{ rotateX: 0, scale: 1, y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="w-full flex justify-center"
      >
        <JournalBook state={journalState} onCoverVisibilityChange={setIsCoverVisible} />
      </motion.div>
      {!isCoverVisible && (journalState.journal?.pages.length ?? 0) > 0 && <Toolbar state={journalState} />}
    </motion.div>
  );
}