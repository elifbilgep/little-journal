import { useState, type FormEvent } from "react";
import { ArrowLeft, Eye, EyeOff, Sparkles } from "lucide-react";

import "./CurrentSignUp.css";

const image = (filename: string) => `/__mockup/images/${filename}`;

export function CurrentSignUp() {
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
  };

  return (
    <main className="lj-signup">
      <div className="lj-signup__shell">
        <section className="lj-signup__form-pane">
          <header className="lj-signup__topbar">
            <span className="lj-signup__back">
              <ArrowLeft size={14} strokeWidth={3} />
              Back
            </span>
            <span className="lj-signup__brand">Little Journal</span>
          </header>

          <div className="lj-signup__content">
            <div className="lj-signup__surface">
              <header className="lj-signup__header">
                <div className="lj-signup__logo">
                  <Sparkles size={21} strokeWidth={1.8} />
                </div>
                <p className="lj-signup__eyebrow">A private place for little things</p>
                <h1>Start your journal</h1>
                <p className="lj-signup__subtitle">A tiny collection of memories</p>
              </header>

              <form className="lj-signup__form" onSubmit={handleSubmit}>
                <button className="lj-signup__google" type="button">
                  <span className="lj-signup__google-mark">G</span>
                  Continue with Google
                </button>

                <div className="lj-signup__divider">OR</div>

                <label className="lj-signup__field">
                  <span>Email address</span>
                  <input type="email" placeholder="Enter your email address" autoComplete="email" />
                </label>

                <label className="lj-signup__field">
                  <span>Password</span>
                  <div className="lj-signup__input-wrap">
                    <input
                      type={showPassword ? "text" : "password"}
                      placeholder="Create a password"
                      autoComplete="new-password"
                    />
                    <button
                      className="lj-signup__password"
                      type="button"
                      aria-label={showPassword ? "Hide password" : "Show password"}
                      onClick={() => setShowPassword((visible) => !visible)}
                    >
                      {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>
                </label>

                <button className="lj-signup__submit" type="submit">
                  Continue <span aria-hidden="true">›</span>
                </button>
              </form>

              <p className="lj-signup__footer">
                Already have an account? <a href="#sign-in">Sign in</a>
              </p>
            </div>
          </div>
        </section>

        <aside className="lj-signup__art" aria-label="Scrapbook artwork">
          <div className="lj-signup__art-grid" />
          <div className="lj-signup__composition">
            <img
              className="lj-signup__journal"
              src={image("studio-scrap-journal-cover-11.png")}
              alt="Pink plaid journal cover"
            />
            <div className="lj-signup__besties">
              <img src={image("journal-photo-besties.png")} alt="Two friends outdoors" />
              <span>Besties</span>
            </div>
            <img className="lj-signup__sticker" src={image("sticker-star.png")} alt="Star sticker" />
            <img className="lj-signup__camera" src={image("camera.png")} alt="Camera" />
            <div className="lj-signup__tag">Yours only</div>
          </div>
        </aside>
      </div>
    </main>
  );
}