import { useState } from 'react';
import { ArrowUpRight, BookOpen, Check, Feather, Menu, X } from 'lucide-react';
import './Editorial.css';

function NavLink({
  href,
  children,
  className = '',
  onClick,
}: {
  href: string;
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}) {
  return (
    <a
      href={href}
      className={className}
      onClick={(event) => {
        event.preventDefault();
        onClick?.();
      }}
    >
      {children}
    </a>
  );
}

function PaperClip({ className = '' }: { className?: string }) {
  return <span aria-hidden="true" className={`lj-paper-clip ${className}`} />;
}

export function Editorial() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [saved, setSaved] = useState(false);

  return (
    <main className="lj-editorial">
      <div className="lj-editorial__grain" aria-hidden="true" />
      <nav className="lj-nav">
        <NavLink href="/" className="lj-brand" onClick={() => setMenuOpen(false)}>
          <span className="lj-brand__mark"><Feather size={16} strokeWidth={1.5} /></span>
          <span>little journal</span>
        </NavLink>
        <div className={`lj-nav__links ${menuOpen ? 'is-open' : ''}`}>
          <NavLink href="#how-it-works" onClick={() => setMenuOpen(false)}>The idea</NavLink>
          <NavLink href="/sign-in" onClick={() => setMenuOpen(false)}>Sign in</NavLink>
          <NavLink href="/sign-up" className="lj-nav__create" onClick={() => setMenuOpen(false)}>
            Start a journal <ArrowUpRight size={14} />
          </NavLink>
        </div>
        <button className="lj-menu" type="button" aria-label="Toggle navigation" onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </nav>

      <section className="lj-stage">
        <div className="lj-copy">
          <p className="lj-kicker"><span /> A place for the in-between</p>
          <h1>Keep the days<br /><em>that kept you.</em></h1>
          <p className="lj-deck">
            Little Journal is a quiet corner for the photographs, sentences,
            and small treasures you want to find again.
          </p>
          <div className="lj-actions">
            <NavLink href="/sign-up" className="lj-button lj-button--ink">
              Make your first page <ArrowUpRight size={15} />
            </NavLink>
            <NavLink href="/journal?demo=1" className="lj-text-link">
              <BookOpen size={15} /> Open the demo journal
            </NavLink>
          </div>
          <div className="lj-note">
            <span className="lj-note__line" />
            <span>For the things you nearly forgot.</span>
          </div>
        </div>

        <div className="lj-scene" aria-label="A tactile open journal with keepsakes">
          <div className="lj-surface-shadow" />
          <div className="lj-postcard lj-postcard--back">
            <div className="lj-postcard__stamp">LJ<br /><small>04</small></div>
            <p>somewhere<br />near the sea</p>
            <span className="lj-postcard__rule" />
          </div>
          <div className="lj-paper lj-paper--loose">
            <PaperClip />
            <span className="lj-paper__date">Sunday, 14 April</span>
            <p>It was an ordinary day<br />until it wasn&apos;t.</p>
            <div className="lj-paper__scribble">remember this</div>
          </div>
          <div className="lj-ribbon" />
          <div className="lj-book">
            <div className="lj-book__cover">
              <span className="lj-book__small">A COLLECTION OF</span>
              <strong>little<br /><i>moments</i></strong>
              <span className="lj-book__year">est. 2024 &nbsp; · &nbsp; vol. 01</span>
            </div>
            <div className="lj-book__pages">
              <div className="lj-page lj-page--left">
                <span className="lj-page__running">LITTLE JOURNAL &nbsp; / &nbsp; 01</span>
                <p className="lj-page__date">MAY 28, 2024</p>
                <p className="lj-page__title">A slow morning<br /><i>in the kitchen</i></p>
                <p className="lj-page__body">The light came in low and golden. We made toast, played the same song twice, and let the afternoon wait.</p>
                <span className="lj-page__folio">07</span>
              </div>
              <div className="lj-page lj-page--right">
                <div className="lj-photo">
                  <div className="lj-photo__sun" />
                  <div className="lj-photo__hills" />
                  <span>the long way home</span>
                </div>
                <p className="lj-page__caption">“Keep a little room in your heart for the unimaginable.”</p>
                <span className="lj-page__folio">08</span>
              </div>
            </div>
          </div>
          <div className="lj-ticket">
            <span>ADMIT ONE</span>
            <strong>MATINEE</strong>
            <small>Saturday · 2:15 PM</small>
            <div className="lj-ticket__perforation" />
          </div>
          <div className="lj-petal lj-petal--one" />
          <div className="lj-petal lj-petal--two" />
        </div>
      </section>

      <footer className="lj-footer">
        <div><span className="lj-footer__dot" /> A softer way to remember</div>
        <div className="lj-footer__center">Made for your bedside table</div>
        <div className="lj-footer__right">
          <span>01 / 03</span>
          <button type="button" aria-label="Save this page" onClick={() => setSaved(!saved)} className={saved ? 'is-saved' : ''}>
            {saved ? <Check size={14} /> : 'save this feeling'}
          </button>
        </div>
      </footer>
    </main>
  );
}