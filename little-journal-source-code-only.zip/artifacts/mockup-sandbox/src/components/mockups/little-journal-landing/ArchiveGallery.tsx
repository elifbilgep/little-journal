import { useMemo, useState } from 'react';
import { Archive, ArrowRight, CalendarDays, ChevronDown, Image, Menu, Plus, Search, Sparkles, X } from 'lucide-react';

type Memory = { date: string; month: string; title: string; note: string; tone: string; tag: string; year: string };

const memories: Memory[] = [
  { date: '28', month: 'MAY', title: 'A slow morning in the kitchen.', note: 'The light came in low and golden. We made toast, played the same song twice, and let the afternoon wait.', tone: 'coral', tag: 'ordinary', year: '2024' },
  { date: '14', month: 'APR', title: 'The long way home.', note: 'A Sunday made of small detours, a paper ticket, and the last of the spring light.', tone: 'blue', tag: 'wandering', year: '2024' },
  { date: '03', month: 'MAR', title: 'Rain against the window.', note: 'Nothing happened, exactly. That was the lovely part of it.', tone: 'sage', tag: 'ordinary', year: '2024' },
  { date: '19', month: 'JAN', title: 'A good idea over two coffees.', note: 'We wrote it on the back of a receipt so it would have somewhere to start.', tone: 'gold', tag: 'people', year: '2024' },
  { date: '22', month: 'DEC', title: 'The year, gathered softly.', note: 'A little list of what stayed: warm bread, open doors, the green coat.', tone: 'rose', tag: 'kept', year: '2023' },
];

export function ArchiveGallery() {
  const [filter, setFilter] = useState('All entries');
  const [selected, setSelected] = useState<Memory | null>(memories[0]);
  const [menuOpen, setMenuOpen] = useState(false);
  const [composerOpen, setComposerOpen] = useState(false);
  const [query, setQuery] = useState('');
  const shown = useMemo(() => memories.filter((memory) =>
    (filter === 'All entries' || memory.tag === filter) &&
    `${memory.title} ${memory.note}`.toLowerCase().includes(query.toLowerCase())
  ), [filter, query]);

  return (
    <main className="archive-gallery">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Caveat:wght@500;600&family=DM+Mono:wght@400;500&family=DM+Sans:wght@400;500;600&family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&display=swap');
        .archive-gallery{--ink:#20343b;--muted:#73858a;--paper:#eef3f2;--panel:#f8f6ef;--coral:#d87060;--teal:#376b6e;--gold:#d8ad55;min-height:100dvh;background:var(--paper);color:var(--ink);font-family:'DM Sans',sans-serif;padding:28px clamp(20px,5vw,72px);position:relative;overflow:hidden}
        .archive-gallery:before{content:'';position:absolute;inset:0;pointer-events:none;opacity:.16;background-image:url("data:image/svg+xml,%3Csvg width='100' height='100' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence baseFrequency='.65' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='.13'/%3E%3C/svg%3E")}
        .ag-top,.ag-layout{position:relative;z-index:1}.ag-top{display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #c9d5d3;padding-bottom:22px}.ag-brand{display:flex;align-items:center;gap:11px;font:500 17px Fraunces,serif}.ag-mark{background:var(--ink);color:var(--paper);width:29px;height:29px;border-radius:50%;display:grid;place-items:center}.ag-topnote,.ag-nav button,.ag-kicker,.ag-filter,.ag-meta,.ag-date,.ag-label,.ag-foot{font:10px 'DM Mono',monospace;letter-spacing:.1em;text-transform:uppercase}.ag-topnote{color:var(--muted)}.ag-nav{display:flex;gap:25px;align-items:center}.ag-nav button,.ag-menu{border:0;background:none;color:var(--ink);cursor:pointer}.ag-nav .ag-cta{border-bottom:1px solid var(--ink);padding:9px 0}.ag-menu{display:none}.ag-layout{display:grid;grid-template-columns:minmax(310px,.72fr) minmax(530px,1.28fr);gap:clamp(30px,7vw,110px);padding:65px 0 42px}.ag-kicker{color:var(--coral);display:flex;align-items:center;gap:9px}.ag-head h1{font:500 clamp(50px,6vw,88px)/.88 Fraunces,serif;letter-spacing:-.07em;margin:20px 0}.ag-head h1 em{color:var(--coral);font-weight:400}.ag-lead{max-width:380px;color:var(--muted);line-height:1.7;font-size:15px}.ag-toolbar{display:flex;gap:12px;align-items:center;margin-top:42px;flex-wrap:wrap}.ag-search{display:flex;align-items:center;gap:8px;border-bottom:1px solid #aab9b8;padding:8px 0;color:var(--muted)}.ag-search input{border:0;background:transparent;outline:0;width:130px;font:12px 'DM Mono',monospace;color:var(--ink)}.ag-filter{border:0;border-bottom:1px solid #aab9b8;background:transparent;color:var(--ink);padding:8px 0;cursor:pointer}.ag-count{margin-top:54px;color:var(--muted);font:italic 16px Fraunces,serif}.ag-count strong{font-style:normal;color:var(--coral)}.ag-entries{background:rgba(248,246,239,.7);border:1px solid #d5dfdc;padding:15px 17px 13px;box-shadow:10px 14px 30px rgba(49,83,83,.08)}.ag-list-head{display:flex;justify-content:space-between;color:var(--muted);padding:4px 8px 15px}.ag-entry{display:grid;grid-template-columns:49px 1fr 25px;gap:14px;align-items:center;border-top:1px solid #dde4df;padding:17px 8px;cursor:pointer;transition:transform .2s,background-color .2s}.ag-entry:hover,.ag-entry.active{background:#e4eeec;transform:translateX(4px)}.ag-date{color:var(--coral);line-height:1.2}.ag-date strong{display:block;color:var(--ink);font:500 28px Fraunces,serif;letter-spacing:-.06em}.ag-entry h3{font:500 19px Fraunces,serif;margin:0 0 5px;letter-spacing:-.03em}.ag-entry p{color:var(--muted);font-size:11px;margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ag-arrow{color:#9aabaa}.ag-detail{grid-column:1 / -1;display:grid;grid-template-columns:1.1fr .9fr;gap:0;background:var(--panel);margin-top:18px;min-height:260px;box-shadow:8px 13px 25px rgba(49,83,83,.12);transform:rotate(-1deg)}.ag-detail-copy{padding:30px 34px}.ag-detail-art{position:relative;min-height:260px;background:#d37968;overflow:hidden}.ag-detail-art:before{content:'';position:absolute;width:170px;height:170px;border-radius:50%;background:#f2c677;right:18%;top:18%;box-shadow:0 0 0 19px rgba(55,107,110,.28)}.ag-detail-art:after{content:'08:14';position:absolute;left:22px;bottom:18px;color:#fff;font:9px 'DM Mono',monospace;letter-spacing:.14em}.ag-detail .ag-label{color:var(--coral)}.ag-detail h2{font:500 clamp(27px,3vw,43px)/.95 Fraunces,serif;letter-spacing:-.05em;margin:15px 0}.ag-detail h2 em{color:var(--coral);font-weight:400}.ag-detail p{color:var(--muted);font-size:13px;line-height:1.7;max-width:320px}.ag-hand{font:500 23px Caveat,cursive;color:var(--teal);margin-top:24px}.ag-add{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;border:1px dashed #a9bcba;background:transparent;color:var(--teal);padding:14px;margin-top:18px;cursor:pointer;font:10px 'DM Mono',monospace;text-transform:uppercase;letter-spacing:.08em}.ag-foot{color:var(--muted);display:flex;justify-content:space-between;padding-top:10px}.ag-modal{position:fixed;z-index:5;inset:0;background:rgba(32,52,59,.3);display:grid;place-items:center;padding:20px}.ag-modal-card{background:var(--panel);padding:28px;max-width:420px;width:100%;box-shadow:0 20px 60px rgba(32,52,59,.25)}.ag-modal-card h2{font:500 34px Fraunces,serif;margin:0 0 18px}.ag-modal-card input,.ag-modal-card textarea{display:block;width:100%;box-sizing:border-box;background:#edf3f1;border:1px solid #c8d7d3;padding:12px;margin:10px 0;font:13px 'DM Sans',sans-serif;outline:0}.ag-modal-actions{display:flex;justify-content:flex-end;gap:12px;margin-top:15px}.ag-modal-actions button{border:0;padding:11px 14px;background:var(--ink);color:var(--paper);font:10px 'DM Mono',monospace;cursor:pointer}.ag-modal-actions button:first-child{background:transparent;color:var(--ink)}@media(max-width:850px){.ag-nav{display:none}.ag-menu{display:block}.ag-layout{display:block;padding-top:46px}.ag-head{margin-bottom:45px}.ag-detail{margin-top:25px}}@media(max-width:560px){.archive-gallery{padding:20px 17px}.ag-topnote{display:none}.ag-layout{padding-top:35px}.ag-toolbar{margin-top:30px}.ag-detail{grid-template-columns:1fr;transform:none}.ag-detail-art{min-height:145px;order:-1}.ag-detail-copy{padding:23px}.ag-entry h3{font-size:16px}.ag-entry p{font-size:10px}.ag-foot{font-size:8px}}
      `}</style>
      <header className="ag-top">
        <div className="ag-brand"><span className="ag-mark"><Archive size={14} /></span> little journal</div>
        <div className="ag-topnote">A private place for the ordinary</div>
        <nav className="ag-nav"><button>About</button><button>Sign in</button><button className="ag-cta" onClick={() => setComposerOpen(true)}>Add a memory <ArrowRight size={12} /></button></nav>
        <button className="ag-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Open menu"><Menu size={20} /></button>
      </header>
      {menuOpen && <nav style={{ position: 'absolute', right: 20, top: 75, zIndex: 3, background: '#f8f6ef', padding: 18, display: 'grid', gap: 15, boxShadow: '0 8px 25px #20343b22' }}><button className="ag-filter">About</button><button className="ag-filter">Sign in</button></nav>}
      <section className="ag-layout">
        <div className="ag-head">
          <div className="ag-kicker"><Sparkles size={12} /> your collected days</div>
          <h1>The things<br /><em>you kept.</em></h1>
          <p className="ag-lead">An index of the ordinary moments that became something else. Search the little archive, or add a new page to it.</p>
          <div className="ag-toolbar">
            <label className="ag-search"><Search size={14} /><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search entries" /></label>
            <select className="ag-filter" value={filter} onChange={e => setFilter(e.target.value)}><option>All entries</option><option value="ordinary">ordinary</option><option value="wandering">wandering</option><option value="people">people</option><option value="kept">kept</option></select>
          </div>
          <p className="ag-count"><strong>{shown.length}</strong> pages found · last opened today</p>
        </div>
        <div className="ag-entries">
          <div className="ag-list-head"><span className="ag-meta">The archive</span><span className="ag-meta">2023—24 <ChevronDown size={12} /></span></div>
          {shown.map(memory => <article className={`ag-entry ${selected?.title === memory.title ? 'active' : ''}`} key={memory.title} onClick={() => setSelected(memory)}><div className="ag-date"><strong>{memory.date}</strong>{memory.month}</div><div><h3>{memory.title}</h3><p>{memory.note}</p></div><ArrowRight className="ag-arrow" size={15} /></article>)}
          {shown.length === 0 && <p style={{ padding: 28, color: 'var(--muted)', font: '14px Fraunces,serif' }}>No pages match that search. Try a softer word.</p>}
          <button className="ag-add" onClick={() => setComposerOpen(true)}><Plus size={14} /> Add a new page</button>
        </div>
        {selected && <article className="ag-detail"><div className="ag-detail-copy"><span className="ag-label">{selected.month} {selected.date}, {selected.year} · {selected.tag}</span><h2>{selected.title.split(' ').slice(0, 3).join(' ')} <em>{selected.title.split(' ').slice(3).join(' ')}</em></h2><p>{selected.note}</p><div className="ag-hand">leave room for the good parts</div></div><div className={`ag-detail-art tone-${selected.tone}`} /></article>}
      </section>
      <footer className="ag-foot"><span><CalendarDays size={12} /> 5 pages across 2 years</span><span><Image size={12} /> every page is yours</span></footer>
      {composerOpen && <div className="ag-modal" onClick={() => setComposerOpen(false)}><div className="ag-modal-card" onClick={e => e.stopPropagation()}><button onClick={() => setComposerOpen(false)} style={{ float: 'right', border: 0, background: 'none', cursor: 'pointer' }}><X size={18} /></button><h2>A new little page.</h2><input placeholder="Give it a title" /><textarea rows={4} placeholder="What do you want to remember?" /><div className="ag-modal-actions"><button onClick={() => setComposerOpen(false)}>Not yet</button><button onClick={() => setComposerOpen(false)}>Keep this page</button></div></div></div>}
    </main>
  );
}