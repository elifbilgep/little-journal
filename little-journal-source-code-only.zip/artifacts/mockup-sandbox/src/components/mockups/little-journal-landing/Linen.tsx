import { useState } from 'react';
import { ArrowUpRight, BookOpen, Check, Menu, PenLine, Sparkles } from 'lucide-react';
import './Linen.css';

export function Linen() {
  const [open, setOpen] = useState(false);
  const [saved, setSaved] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <main className={`lj-linen ${open ? 'is-open' : ''}`}>
      <header className="lj-linen__top">
        <div className="lj-linen__brand"><span><PenLine size={14} /></span> little journal</div>
        <div className="lj-linen__topnote">A private place for the ordinary</div>
        <nav className={menuOpen ? 'is-menu-open' : ''}>
          <button onClick={() => setSaved(true)}>The idea</button>
          <button onClick={() => setSaved(true)}>Sign in</button>
          <button className="lj-linen__start" onClick={() => setOpen(true)}>Start a journal <ArrowUpRight size={13} /></button>
        </nav>
        <button className="lj-linen__menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu"><Menu size={20} /></button>
      </header>

      <section className="lj-linen__hero">
        <div className="lj-linen__copy">
          <p className="lj-linen__eyebrow"><Sparkles size={12} /> a record of the in-between</p>
          <h1>Keep the days<br /><em>that keep you.</em></h1>
          <p className="lj-linen__intro">A quiet corner for the photographs, sentences, and small treasures you want to find again.</p>
          <div className="lj-linen__actions">
            <button className="lj-linen__primary" onClick={() => setOpen(true)}>{open ? 'Your journal is open' : 'Make your first page'} <ArrowUpRight size={14} /></button>
            <button className="lj-linen__secondary" onClick={() => setOpen(true)}><BookOpen size={15} /> Open the demo journal</button>
          </div>
          <div className="lj-linen__rule"><span /> <i>For the things you nearly forgot.</i></div>
          {saved && <p className="lj-linen__notice"><Check size={13} /> A little note saved for later.</p>}
        </div>

        <div className="lj-linen__scene" aria-label="An open journal on a blue linen desk">
          <div className="lj-linen__window"><i /><i /><i /></div>
          <div className="lj-linen__cloth" />
          <div className="lj-linen__book-shadow" />
          <div className="lj-linen__open-book">
            <div className="lj-linen__page page-left">
              <div className="lj-linen__meta"><small>JUNE 04, 2024</small><small>ENTRY / 018</small></div>
              <div className="lj-linen__tape" />
              <div className="lj-linen__sketch"><span>08:14</span><i /></div>
              <p className="lj-linen__hand">The house was quiet<br /><em>in the good way.</em></p>
              <p className="lj-linen__body">A blue morning. The kettle clicked off, a sparrow found the sill, and we let the day arrive without asking it to hurry.</p>
              <div className="lj-linen__check">○ buy peaches &nbsp; ✓ call home</div>
              <b>18</b>
            </div>
            <div className="lj-linen__page page-right">
              <div className="lj-linen__meta"><small>LITTLE JOURNAL / 01</small><small>KEPT</small></div>
              <div className="lj-linen__collage"><div className="lj-linen__photo photo-window"><span>the long way</span></div><div className="lj-linen__photo photo-ticket"><span>MATINEE</span></div></div>
              <h3 className="lj-linen__hand">the long way<br /><em>home</em></h3>
              <blockquote>“Leave a little room for the unimaginable.”</blockquote>
              <div className="lj-linen__mini-note"><span>FIELD NOTE 04</span><strong>take the long way<br />when you can</strong></div>
              <div className="lj-linen__stamp">KEPT<br /><small>HERE</small></div>
              <b>19</b>
            </div>
          </div>
          <div className="lj-linen__receipt"><span>09:38</span><strong>two coffees<br />one good idea</strong></div>
          <div className="lj-linen__note">Tuesday, 04<br /><strong>It was an ordinary day<br />until it wasn't.</strong></div>
          <div className="lj-linen__pencil">/ a life in fragments /</div>
        </div>
      </section>
      <footer className="lj-linen__footer"><span>01 — Open a page</span><span>02 — Leave a trace</span><span>03 — Come back to it</span></footer>
    </main>
  );
}