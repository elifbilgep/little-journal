import { useState } from 'react';
import { ArrowUpRight, BookOpen, Check, Menu, PenLine, Sparkles } from 'lucide-react';
import './Archive.css';

export function Archive() {
  const [saved, setSaved] = useState(false);
  const [open, setOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <main className={`lj-home ${open ? 'is-open' : ''}`}>
      <header className="lj-home__top">
        <div className="lj-home__brand"><span className="lj-home__brandmark"><PenLine size={14} /></span> little journal</div>
        <div className="lj-home__topnote">A private place for the ordinary</div>
        <nav className={`lj-home__nav ${menuOpen ? 'is-menu-open' : ''}`}>
          <button onClick={() => setSaved(true)}>The idea</button>
          <button onClick={() => setSaved(true)}>Sign in</button>
          <button className="lj-home__nav-start" onClick={() => setOpen(true)}>Start a journal <ArrowUpRight size={13} /></button>
        </nav>
        <button className="lj-home__menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle journal menu"><Menu size={20} /></button>
      </header>
      <section className="lj-home__hero">
        <div className="lj-home__copy">
          <p className="lj-home__eyebrow"><Sparkles size={12} /> A place for the in-between</p>
          <h1>Keep the days<br /><em>that kept you.</em></h1>
          <p className="lj-home__intro">Little Journal is a quiet corner for the photographs, sentences, and small treasures you want to find again.</p>
          <div className="lj-home__actions">
            <button className="lj-home__primary" onClick={() => setOpen(true)}>{open ? 'Your journal is open' : 'Make your first page'} <ArrowUpRight size={14} /></button>
            <button className="lj-home__secondary" onClick={() => setOpen(true)}><BookOpen size={15} /> Open the demo journal</button>
          </div>
          <div className="lj-home__rule"><span /> <i>For the things you nearly forgot.</i></div>
          {saved && <p className="lj-home__notice"><Check size={13} /> A little note saved for later.</p>}
        </div>
        <div className="lj-home__scene" aria-label="A tactile open journal with keepsakes">
          <div className="lj-home__sun" />
          <div className="lj-home__cloth" />
          <div className="lj-home__book-shadow" />
          <div className="lj-home__closed-book">
            <span>A COLLECTION OF</span><strong>little<br />moments</strong><small>est. 2024</small>
          </div>
          <div className="lj-home__open-book">
            <div className="lj-home__page lj-home__page--left">
              <div className="lj-page-meta"><small>MAY 28, 2024</small><small>TUESDAY / 07</small></div>
              <div className="lj-page-tape lj-page-tape--rose" />
              <div className="lj-memory-photo lj-memory-photo--coffee"><span>08:14</span><i /></div>
              <p className="lj-hand-note lj-handwritten">A slow morning<br /><em>in the kitchen.</em></p>
              <p className="lj-page-copy lj-handwritten">The light came in low and golden. We made toast, played the same song twice, and let the afternoon wait.</p>
              <div className="lj-page-check lj-handwritten"><span>○</span> buy peaches <span>✓</span> call home</div>
              <b>07</b>
            </div>
            <div className="lj-home__page lj-home__page--right">
              <div className="lj-page-meta"><small>LITTLE JOURNAL / 01</small><small>KEPT</small></div>
              <div className="lj-page-collage">
                <div className="lj-memory-photo lj-memory-photo--window"><span>the long way</span><i /></div>
                <div className="lj-memory-photo lj-memory-photo--ticket"><span>MATINEE</span><i /></div>
              </div>
              <h3 className="lj-handwritten">the long way<br /><em>home</em></h3>
              <blockquote className="lj-handwritten">“Keep a little room in your heart for the unimaginable.”</blockquote>
              <p className="lj-page-caption lj-handwritten">A Sunday made of small detours.</p>
              <div className="lj-page-mini-note"><span>FIELD NOTE 04</span><strong className="lj-handwritten">take the long way<br />when you can</strong></div>
              <div className="lj-page-washi" />
              <div className="lj-page-stamp">KEPT<br /><small>HERE</small></div>
              <b>08</b>
            </div>
          </div>
           <div className="lj-home__note">Sunday, 14<br /><strong className="lj-handwritten">It was an ordinary day<br />until it wasn't.</strong></div>
          <div className="lj-home__ticket">ADMIT ONE<br /><strong>MATINEE</strong><small>Saturday · 2:15 PM</small></div>
           <div className="lj-home__receipt"><span>09:38</span><strong>two coffees<br />one good idea</strong></div>
          <div className="lj-home__pencil">/ a life in fragments /</div>
        </div>
      </section>
      <footer className="lj-home__footer">
        <span>01 — Open a page</span><span>02 — Leave a trace</span><span>03 — Come back to it</span>
      </footer>
    </main>
  );
}