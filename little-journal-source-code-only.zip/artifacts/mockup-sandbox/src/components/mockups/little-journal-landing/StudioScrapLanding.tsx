import { useEffect, useState } from 'react';
import { ArrowUpRight, BookOpen, Check, Cloud, Menu, MousePointer2, X } from 'lucide-react';
import './_group.css';
import './StudioScrapLanding.css';

const floatingScraps = [
  { src: '/__mockup/images/sticker-star.png', className: 'scrap scrap--star', alt: 'Leopard star patch' },
  { src: '/__mockup/images/sticker-heart.png', className: 'scrap scrap--heart', alt: 'Fabric heart patch' },
  { src: '/__mockup/images/sticker-dog.png', className: 'scrap scrap--dog', alt: 'Pink dog patch' },
  { src: '/__mockup/images/sticker-cat.png', className: 'scrap scrap--cat', alt: 'Cat mermaid patch' },
  { src: '/__mockup/images/sticker-button-heart.png', className: 'scrap scrap--button-heart', alt: 'Plaid heart button' },
  { src: '/__mockup/images/sticker-button.png', className: 'scrap scrap--button', alt: 'Yellow button' },
  { src: '/__mockup/images/sticker-bow.png', className: 'scrap scrap--bow', alt: 'Polka dot bow' },
  { src: '/__mockup/images/camera.png', className: 'scrap scrap--camera', alt: 'Compact camera' },
];

const cards = [
  {
    src: '/__mockup/images/journal-photo-headphones.png',
    label: 'late night',
    alt: 'A child wearing headphones and sunglasses',
  },
  {
    src: '/__mockup/images/journal-photo-besties.png',
    label: 'besties',
    alt: 'Two friends making silly faces outdoors',
  },
  {
    src: '/__mockup/images/journal-photo-bubbles.png',
    label: 'summer',
    alt: 'A friend surrounded by iridescent bubbles',
  },
  {
    src: '/__mockup/images/journal-photo-guitars.png',
    label: 'music store',
    alt: 'A wall of colorful guitars',
  },
  {
    src: '/__mockup/images/journal-photo-skate.png',
    label: 'sky high',
    alt: 'A skateboarder jumping against a blue sky',
  },
];

const journalCovers = [
  { src: '/__mockup/images/studio-scrap-journal-cover-11.png', alt: 'Pink plaid journal cover' },
  { src: '/__mockup/images/studio-scrap-journal-cover-12.png', alt: 'Pink star journal cover' },
  { src: '/__mockup/images/studio-scrap-journal-cover-13.png', alt: 'Charcoal polka dot journal cover' },
  { src: '/__mockup/images/studio-scrap-journal-cover-14.png', alt: 'Mint floral journal cover' },
  { src: '/__mockup/images/studio-scrap-journal-cover-15.png', alt: 'Purple plaid journal cover' },
  { src: '/__mockup/images/studio-scrap-journal-cover-16.png', alt: 'Cream cat journal cover' },
  { src: '/__mockup/images/studio-scrap-journal-cover-17.png', alt: 'Black polka dot journal cover' },
  { src: '/__mockup/images/studio-scrap-journal-cover-18.png', alt: 'White polka dot journal cover' },
];

export function StudioScrapLanding() {
  const [journalCoverIndex, setJournalCoverIndex] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);
  const [notice, setNotice] = useState('');
  const journalCover = journalCovers[journalCoverIndex];

  useEffect(() => {
    journalCovers.forEach(({ src }) => {
      const image = new Image();
      image.decoding = 'async';
      image.src = src;
    });
  }, []);

  const showNotice = (message: string) => {
    setNotice(message);
    window.setTimeout(() => setNotice(''), 2600);
  };

  const pickNextJournal = () => {
    setJournalCoverIndex((index) => (index + 1) % journalCovers.length);
  };

  return (
    <main className="studio-scrap">
      <div className="studio-scrap__shell">
        <header className="studio-scrap__header">
          <a className="studio-scrap__new" href="#journal">
            <span>✣</span> NEW
          </a>
          <nav className={`studio-scrap__nav ${menuOpen ? 'is-open' : ''}`}>
            <a href="#journal">Journal</a>
            <a href="#features">How it works</a>
            <a href="#features">Features</a>
          </nav>
          <button
            className="studio-scrap__start"
            onClick={() => showNotice('Your first page is ready.')}
          >
            Start a journal <ArrowUpRight size={13} />
          </button>
          <button
            className="studio-scrap__menu"
            onClick={() => setMenuOpen((open) => !open)}
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
          >
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </header>

        <section className="studio-scrap__hero" id="journal">
          <div className="studio-scrap__badge">LITTLE JOURNAL</div>
          <h1>Your memories deserve<br />more than a camera roll.</h1>
          <p className="studio-scrap__intro">
            Turn real-looking pages. Drop in Polaroids, notes and stickers.
            Move everything until the page feels like yours.
          </p>
          <div className="studio-scrap__actions">
            <button onClick={() => showNotice('Your first page is ready.')}>
              <BookOpen size={15} /> Open the journal
            </button>
            <button onClick={() => showNotice('Demo journal opened.')}>
              Try the demo <ArrowUpRight size={14} />
            </button>
          </div>

          <div className="studio-scrap__scene">
            <div className="studio-scrap__scene-grid" />
            {floatingScraps.map((scrap) => (
              <img key={scrap.className} {...scrap} />
            ))}

            <button
              className="studio-scrap__journal"
              onClick={pickNextJournal}
              aria-label="Pick a journal cover"
            >
              <img
                className="studio-scrap__journal-closed"
                src={journalCover.src}
                alt={journalCover.alt}
              />
              <span>pick your journal ↗</span>
            </button>

            <div className="studio-scrap__callout studio-scrap__callout--drag">
              <MousePointer2 size={13} /> drag, resize, rotate
            </div>
            <div className="studio-scrap__callout studio-scrap__callout--cloud">
              <Cloud size={13} /> saved on every screen
            </div>
          </div>

          <div className="studio-scrap__card-stage">
            <div className="studio-scrap__card-strip" aria-hidden="true" />
            <div className="studio-scrap__card-row" aria-label="Scrapbook elements">
              {cards.map((card, index) => (
                <div className={`studio-scrap__card studio-scrap__card--${index + 1}`} key={card.label}>
                  <img src={card.src} alt={card.alt} />
                  <span>{card.label}</span>
                </div>
              ))}
            </div>
          </div>
          {notice && <div className="studio-scrap__notice"><Check size={14} /> {notice}</div>}
        </section>

        <section className="studio-scrap__dark" id="features">
          <div className="studio-scrap__dark-label"><span /> HOW IT WORKS</div>
          <div className="studio-scrap__dark-copy">
            <h2>Flip it. Fill it.<br />Make it unmistakably yours.</h2>
            <p>
              A private digital scrapbook that behaves like a real journal —
              tactile pages, loose memories and no rigid templates.
            </p>
          </div>
          <div className="studio-scrap__feature-grid">
            <article>
              <span>01</span>
              <h3>Turn the page</h3>
              <p>Drag the corner and move through a journal with real 3D page motion.</p>
            </article>
            <article>
              <span>02</span>
              <h3>Leave a trace</h3>
              <p>Add photos as Polaroids, then move, resize and rotate every object.</p>
            </article>
            <article>
              <span>03</span>
              <h3>Come back to it</h3>
              <p>Your account keeps every page available on phone and desktop.</p>
            </article>
          </div>
        </section>
      </div>
    </main>
  );
}