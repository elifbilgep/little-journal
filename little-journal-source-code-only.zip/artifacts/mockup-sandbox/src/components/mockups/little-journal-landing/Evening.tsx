import { useState } from 'react';
import { ArrowUpRight, BookOpen, Check, Menu, PenLine, Sparkles } from 'lucide-react';
import './Evening.css';

export function Evening() {
  const [open, setOpen] = useState(false);
  const [saved, setSaved] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <main className={`lj-evening ${open ? 'is-open' : ''}`}>
      <header className="lj-evening__top">
        <div className="lj-evening__brand"><span><PenLine size={14} /></span> little journal</div>
        <div className="lj-evening__topnote">A private place for the ordinary</div>
        <nav className={menuOpen ? 'is-menu-open' : ''}>
          <button onClick={() => setSaved(true)}>The idea</button>
          <button onClick={() => setSaved(true)}>Sign in</button>
          <button className="lj-evening__start" onClick={() => setOpen(true)}>Start a journal <ArrowUpRight size={13} /></button>
        </nav>
        <button className="lj-evening__menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu"><Menu size={20} /></button>
      </header>
      <section className="lj-evening__hero">
        <div className="lj-evening__copy">
          <p className="lj-evening__eyebrow"><Sparkles size={12} /> before the lights go out</p>
          <h1>Keep the days<br /><em>that keep you.</em></h1>
          <p className="lj-evening__intro">A quiet corner for the photographs, sentences, and small treasures you want to find again.</p>
          <div className="lj-evening__actions">
            <button className="lj-evening__primary" onClick={() => setOpen(true)}>{open ? 'Your journal is open' : 'Make your first page'} <ArrowUpRight size={14} /></button>
            <button className="lj-evening__secondary" onClick={() => setOpen(true)}><BookOpen size={15} /> Open the demo journal</button>
          </div>
          <div className="lj-evening__rule"><span /> <i>For the things you nearly forgot.</i></div>
          {saved && <p className="lj-evening__notice"><Check size={13} /> A little note saved for later.</p>}
        </div>
        <div className="lj-evening__scene" aria-label="An open journal on a bedside table at evening">
          <div className="lj-evening__wall-light" />
          <div className="lj-evening__lamp"><i /><b /><span /></div>
          <div className="lj-evening__table" />
          <div className="lj-evening__book-shadow" />
          <div className="lj-evening__open-book">
            <div className="lj-evening__page page-left"><small>THURSDAY / 10:42 PM</small><h2>Things worth<br /><em>leaving the lamp on for</em></h2><p>The blue hour stayed by the window. You laughed at the wrong part of the film.</p><b>12</b></div>
            <div className="lj-evening__page page-right"><div className="lj-evening__moon">☾</div><h3>notes from<br /><em>the edge of sleep</em></h3><blockquote>“The room remembered us softly.”</blockquote><b>13</b></div>
          </div>
          <div className="lj-evening__pencil"><i /> wooden pencil</div>
          <div className="lj-evening__photo"><span /><small>us, last summer</small></div>
          <div className="lj-evening__match">MATCHES<br /><strong>ST. LUCY</strong><small>light a little</small></div>
          <div className="lj-evening__ring">○</div>
          <div className="lj-evening__note">leave this here<br /><strong>Tomorrow, call<br />your sister.</strong></div>
        </div>
      </section>
      <footer className="lj-evening__footer"><span>01 — Open a page</span><span>02 — Leave a trace</span><span>03 — Come back to it</span></footer>
    </main>
  );
}