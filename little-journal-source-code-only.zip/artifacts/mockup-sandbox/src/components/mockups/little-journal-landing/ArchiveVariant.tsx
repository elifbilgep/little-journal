import { useMemo, useState } from 'react';
import { Archive as ArchiveIcon, ArrowLeft, ArrowUpRight, Bookmark, CalendarDays, ChevronRight, Image, Plus, Search, SlidersHorizontal, X } from 'lucide-react';

type Entry = {
  id: number;
  date: string;
  month: string;
  title: string;
  excerpt: string;
  tag: string;
  tone: string;
};

const entries: Entry[] = [
  { id: 1, date: '28', month: 'MAY 2024', title: 'The long way home', excerpt: 'A Sunday made of small detours, orange light, and a bus we did not need to catch.', tag: 'Sunday / 07', tone: 'coral' },
  { id: 2, date: '14', month: 'MAY 2024', title: 'Two coffees, one good idea', excerpt: 'We took the table beside the window and let the afternoon wait for us.', tag: 'Saturday / 06', tone: 'blue' },
  { id: 3, date: '02', month: 'MAY 2024', title: 'A little weather', excerpt: 'Rain on the glass. A song played twice. The whole day felt like a kept secret.', tag: 'Thursday / 05', tone: 'gold' },
];

export function ArchiveVariant() {
  const [activeId, setActiveId] = useState(1);
  const [query, setQuery] = useState('');
  const [saved, setSaved] = useState(false);
  const [composeOpen, setComposeOpen] = useState(false);
  const [view, setView] = useState<'index' | 'stack'>('index');

  const active = entries.find((entry) => entry.id === activeId) ?? entries[0];
  const filtered = useMemo(
    () => entries.filter((entry) => `${entry.title} ${entry.excerpt} ${entry.tag}`.toLowerCase().includes(query.toLowerCase())),
    [query],
  );

  return (
    <main className="archive-variant">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Caveat:wght@500;600&family=DM+Mono:wght@400;500&family=DM+Sans:wght@400;500;600&family=Fraunces:opsz,wght@9..144,500;9..144,600&display=swap');
        .archive-variant{--ink:#203641;--paper:#edf3f4;--panel:#f8f5ed;--muted:#70818a;--teal:#2c686c;--coral:#d96758;--gold:#e2b650;min-height:100dvh;background:var(--paper);color:var(--ink);font-family:'DM Sans',sans-serif;overflow:hidden;position:relative}
        .archive-variant:before{content:'';position:absolute;inset:0;pointer-events:none;opacity:.16;background-image:url("data:image/svg+xml,%3Csvg width='100' height='100' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence baseFrequency='.75' numOctaves='2'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='.1'/%3E%3C/svg%3E")}
        .av-shell{position:relative;z-index:1;display:grid;grid-template-columns:330px 1fr;min-height:100dvh;max-width:1440px;margin:auto}
        .av-sidebar{padding:35px 29px 28px;border-right:1px solid rgba(32,54,65,.16);display:flex;flex-direction:column}
        .av-brand{display:flex;align-items:center;gap:11px;font:500 18px 'Fraunces',serif}.av-mark{width:29px;height:29px;border-radius:50%;background:var(--ink);color:var(--paper);display:grid;place-items:center}
        .av-kicker{margin:66px 0 10px;font:9px 'DM Mono',monospace;color:var(--coral);letter-spacing:.15em;text-transform:uppercase}.av-sidebar h1{margin:0;font:500 38px/.95 'Fraunces',serif;letter-spacing:-.05em}.av-sidebar h1 em{color:var(--coral);font-weight:500}
        .av-search{display:flex;align-items:center;gap:9px;margin:36px 0 20px;padding:11px 0;border-bottom:1px solid rgba(32,54,65,.25);color:var(--muted)}.av-search input{width:100%;border:0;outline:0;background:transparent;color:var(--ink);font:11px 'DM Mono',monospace}.av-search input::placeholder{color:#8b9aa0}
        .av-list{display:grid;gap:5px;overflow:auto}.av-entry{position:relative;display:grid;grid-template-columns:47px 1fr;gap:12px;padding:14px 9px;border:0;border-radius:2px;background:transparent;text-align:left;color:var(--ink);cursor:pointer;transition:background-color .2s,transform .2s}.av-entry:hover{background:rgba(255,255,255,.45);transform:translateX(3px)}.av-entry.is-active{background:var(--panel);box-shadow:0 7px 22px rgba(32,54,65,.08)}.av-entry.is-active:before{content:'';position:absolute;left:0;top:16px;bottom:16px;width:3px;background:var(--coral)}
        .av-date{font:500 25px/.9 'Fraunces',serif;color:var(--teal)}.av-date small{display:block;margin-top:7px;font:8px 'DM Mono',monospace;color:var(--muted);letter-spacing:.03em}.av-entry h2{margin:0 0 7px;font:500 15px/1.05 'Fraunces',serif}.av-entry p{margin:0;color:var(--muted);font-size:10px;line-height:1.45;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
        .av-footer{margin-top:auto;padding-top:27px;color:var(--muted);font:9px 'DM Mono',monospace;letter-spacing:.08em;text-transform:uppercase;display:flex;justify-content:space-between}.av-footer strong{color:var(--coral);font-weight:500}
        .av-main{padding:35px clamp(25px,5vw,75px);display:flex;flex-direction:column}.av-toolbar{display:flex;align-items:center;justify-content:space-between}.av-back{border:0;background:transparent;color:var(--muted);font:10px 'DM Mono',monospace;letter-spacing:.08em;text-transform:uppercase;display:flex;align-items:center;gap:8px;cursor:pointer}.av-tools{display:flex;gap:8px}.av-icon{width:33px;height:33px;border:1px solid rgba(32,54,65,.2);background:transparent;color:var(--ink);display:grid;place-items:center;cursor:pointer}.av-icon.is-on,.av-icon:hover{background:var(--ink);color:var(--paper)}
        .av-stage{flex:1;display:grid;grid-template-columns:minmax(260px,.75fr) minmax(350px,1.25fr);align-items:center;gap:clamp(30px,6vw,100px);padding:48px 0 25px}.av-intro{align-self:center}.av-meta{display:flex;align-items:center;gap:10px;color:var(--coral);font:9px 'DM Mono',monospace;letter-spacing:.12em;text-transform:uppercase}.av-meta span{width:28px;border-top:1px solid var(--coral)}.av-intro h3{margin:26px 0 19px;font:500 clamp(42px,5.2vw,77px)/.88 'Fraunces',serif;letter-spacing:-.07em}.av-intro h3 em{color:var(--coral);font-weight:500}.av-intro>p{max-width:330px;margin:0;color:var(--muted);font-size:14px;line-height:1.7}.av-note{display:flex;align-items:center;gap:7px;margin-top:37px;color:var(--teal);font:10px 'DM Mono',monospace}
        .av-card{position:relative;background:var(--panel);min-height:430px;padding:28px 31px 25px;box-shadow:17px 20px 0 rgba(44,104,108,.13),0 18px 35px rgba(32,54,65,.14);transform:rotate(1.8deg)}.av-card:before{content:'';position:absolute;left:50%;top:-17px;width:80px;height:28px;background:rgba(226,182,80,.75);transform:translateX(-50%) rotate(-4deg)}.av-card-top{display:flex;justify-content:space-between;color:var(--muted);font:8px 'DM Mono',monospace;letter-spacing:.1em;text-transform:uppercase}.av-card-number{color:var(--coral)}.av-card-photo{height:153px;margin:27px 0 24px;background:var(--teal);position:relative;overflow:hidden}.av-card-photo:before{content:'';position:absolute;width:150px;height:150px;right:18%;top:23px;border-radius:50%;background:var(--gold);opacity:.85}.av-card-photo:after{content:'';position:absolute;left:13%;right:13%;bottom:-46px;height:125px;border-radius:50% 50% 0 0;background:#d66c5a;box-shadow:75px -9px 0 #447b78}.av-card-photo span{position:absolute;z-index:2;left:14px;bottom:12px;color:#eff4eb;font:8px 'DM Mono',monospace;letter-spacing:.1em}.av-card h4{margin:0;font:500 35px/.9 'Fraunces',serif;letter-spacing:-.06em}.av-card h4 em{color:var(--coral);font-weight:500}.av-card-copy{max-width:310px;margin:13px 0 0;color:var(--muted);font:15px/1.15 'Caveat',cursive}.av-card-bottom{display:flex;align-items:end;justify-content:space-between;margin-top:22px}.av-tag{color:var(--muted);font:8px 'DM Mono',monospace;letter-spacing:.09em;text-transform:uppercase}.av-bookmark{border:0;background:transparent;color:var(--coral);cursor:pointer;display:flex;align-items:center;gap:6px;font:9px 'DM Mono',monospace;text-transform:uppercase}.av-bookmark.is-saved{color:var(--teal)}
        .av-actions{display:flex;justify-content:space-between;align-items:center;border-top:1px solid rgba(32,54,65,.16);padding-top:19px}.av-actions small{color:var(--muted);font:9px 'DM Mono',monospace;letter-spacing:.08em}.av-add{display:flex;align-items:center;gap:9px;border:1px solid var(--ink);background:var(--ink);color:var(--paper);padding:12px 14px;font:9px 'DM Mono',monospace;letter-spacing:.06em;text-transform:uppercase;cursor:pointer;transition:transform .2s,background-color .2s}.av-add:hover{transform:translateY(-2px);background:var(--teal)}
        .av-modal{position:fixed;inset:0;z-index:10;background:rgba(32,54,65,.26);display:grid;place-items:center;padding:22px}.av-dialog{width:min(410px,100%);padding:29px;background:var(--panel);box-shadow:0 18px 45px rgba(32,54,65,.23);position:relative}.av-dialog h2{margin:0 0 9px;font:500 30px 'Fraunces',serif}.av-dialog p{margin:0 0 25px;color:var(--muted);font-size:13px;line-height:1.5}.av-dialog input,.av-dialog textarea{display:block;width:100%;box-sizing:border-box;border:1px solid rgba(32,54,65,.2);background:#fffdf7;padding:12px;margin-top:10px;outline:0;color:var(--ink);font:12px 'DM Mono',monospace}.av-dialog textarea{height:100px;resize:none}.av-dialog button[type=submit]{margin-top:17px}.av-close{position:absolute;right:15px;top:15px;border:0;background:transparent;color:var(--muted);cursor:pointer}
        @media(max-width:800px){.av-shell{display:block}.av-sidebar{padding:22px 22px 18px;border-right:0;border-bottom:1px solid rgba(32,54,65,.16)}.av-kicker{margin-top:32px}.av-sidebar h1{font-size:32px}.av-search{margin:22px 0 12px}.av-list{display:flex;overflow:auto;margin:0 -8px;padding:0 8px}.av-entry{min-width:210px}.av-footer{display:none}.av-main{padding:22px}.av-stage{grid-template-columns:1fr;gap:32px;padding:42px 0 28px}.av-intro h3{font-size:54px;margin-top:20px}.av-card{min-height:390px;max-width:510px;width:calc(100% - 17px);justify-self:center}.av-card-photo{height:135px}}
        @media(max-width:430px){.av-card{padding:23px 22px;min-height:365px}.av-card h4{font-size:29px}.av-card-photo{margin:22px 0 19px}.av-card-copy{font-size:14px}.av-stage{padding-top:30px}}
      `}</style>
      <div className="av-shell">
        <aside className="av-sidebar">
          <div className="av-brand"><span className="av-mark"><ArchiveIcon size={14} /></span> little journal</div>
          <p className="av-kicker">Your kept things</p>
          <h1>A small index<br /><em>of the days.</em></h1>
          <label className="av-search"><Search size={15} /><input aria-label="Search entries" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search your pages" /></label>
          <div className="av-list">
            {filtered.map((entry) => (
              <button className={`av-entry ${activeId === entry.id ? 'is-active' : ''}`} key={entry.id} onClick={() => setActiveId(entry.id)}>
                <div className="av-date">{entry.date}<small>{entry.month}</small></div>
                <div><h2>{entry.title}</h2><p>{entry.excerpt}</p></div>
              </button>
            ))}
            {filtered.length === 0 && <p style={{ color: 'var(--muted)', fontSize: 12, padding: '20px 8px' }}>No pages found. Try another little phrase.</p>}
          </div>
          <div className="av-footer"><span><strong>{entries.length}</strong> pages kept</span><span>May 2024</span></div>
        </aside>
        <section className="av-main">
          <div className="av-toolbar"><button className="av-back" onClick={() => setQuery('')}><ArrowLeft size={14} /> Clear index</button><div className="av-tools"><button className={`av-icon ${view === 'index' ? 'is-on' : ''}`} onClick={() => setView('index')} aria-label="Index view"><SlidersHorizontal size={15} /></button><button className={`av-icon ${view === 'stack' ? 'is-on' : ''}`} onClick={() => setView('stack')} aria-label="Stack view"><Image size={15} /></button></div></div>
          <div className={`av-stage ${view === 'stack' ? 'is-stack' : ''}`}>
            <div className="av-intro"><div className="av-meta"><span /> Selected page</div><h3>Remember<br /><em>the ordinary.</em></h3><p>Not a feed. Not a performance. Just a gentle index of what you might want to meet again.</p>{saved && <div className="av-note"><Bookmark size={13} fill="currentColor" /> Kept in your pocket</div>}</div>
            <article className={`av-card tone-${active.tone}`}><div className="av-card-top"><span>{active.month}</span><span className="av-card-number">No. {String(active.id).padStart(2, '0')}</span></div><div className="av-card-photo"><span>AN ORDINARY DAY / {active.tag}</span></div><h4>{active.title.split(' ').slice(0, -1).join(' ')} <em>{active.title.split(' ').slice(-1)}</em></h4><p className="av-card-copy">{active.excerpt}</p><div className="av-card-bottom"><span className="av-tag"><CalendarDays size={12} style={{ verticalAlign: 'middle', marginRight: 6 }} /> {active.tag}</span><button className={`av-bookmark ${saved ? 'is-saved' : ''}`} onClick={() => setSaved(!saved)}><Bookmark size={14} fill={saved ? 'currentColor' : 'none'} /> {saved ? 'Kept' : 'Keep this'}</button></div></article>
          </div>
          <div className="av-actions"><small>Turn the page slowly <ChevronRight size={12} style={{ verticalAlign: 'middle' }} /></small><button className="av-add" onClick={() => setComposeOpen(true)}><Plus size={14} /> Add a page <ArrowUpRight size={13} /></button></div>
        </section>
      </div>
      {composeOpen && <div className="av-modal" role="dialog" aria-modal="true"><form className="av-dialog" onSubmit={(event) => { event.preventDefault(); setComposeOpen(false); }}><button className="av-close" type="button" aria-label="Close" onClick={() => setComposeOpen(false)}><X size={17} /></button><h2>Leave a trace.</h2><p>Start with one true thing from today. You can fill in the edges later.</p><input aria-label="Page title" placeholder="A title for this day" required /><textarea aria-label="Page note" placeholder="What do you want to remember?" required /><button className="av-add" type="submit"><Plus size={14} /> Keep this page</button></form></div>}
    </main>
  );
}