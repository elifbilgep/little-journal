import type { AnchorHTMLAttributes, ButtonHTMLAttributes, HTMLAttributes, ReactNode } from 'react';
import './_group.css';

type ShowProps = {
  when: 'signed-in' | 'signed-out';
  children: ReactNode;
};

function Show({ when, children }: ShowProps) {
  return when === 'signed-out' ? <>{children}</> : null;
}

function Link({ href, children, onClick, ...props }: AnchorHTMLAttributes<HTMLAnchorElement>) {
  return (
    <a
      href={href}
      onClick={(event) => {
        onClick?.(event);
        if (!event.defaultPrevented) event.preventDefault();
      }}
      {...props}
    >
      {children}
    </a>
  );
}

function MotionDiv({
  initial: _initial,
  animate: _animate,
  transition: _transition,
  ...props
}: HTMLAttributes<HTMLDivElement> & {
  initial?: unknown;
  animate?: unknown;
  transition?: unknown;
}) {
  return <div {...props} />;
}

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'default' | 'outline';
};

function Button({ className = '', variant = 'default', ...props }: ButtonProps) {
  const base =
    'inline-flex min-h-9 px-4 py-2 items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50';
  const style =
    variant === 'outline'
      ? 'border [border-color:var(--button-outline)] shadow-xs active:shadow-none'
      : 'border border-transparent';

  return <button className={`${base} ${style} ${className}`} {...props} />;
}

export function Current() {
  return (
    <div className="lj-landing min-h-[100dvh] w-full flex flex-col items-center justify-center bg-[#f5f0eb] paper-texture overflow-hidden relative">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#e5b3b9] rounded-full blur-3xl opacity-20" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#a8b8ad] rounded-full blur-3xl opacity-20" />
      </div>

      <MotionDiv
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="relative z-10 flex flex-col items-center max-w-md w-full px-6"
      >
        <div className="relative w-64 h-80 rounded-r-xl rounded-l border border-[rgba(0,0,0,0.1)] shadow-2xl mb-12 cover-style-cream transition-transform hover:scale-105 duration-500 spine-shadow cursor-pointer">
          <div className="absolute left-0 top-0 bottom-0 w-8 bg-black/5 rounded-l border-r border-black/5" />
          <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center mix-blend-multiply">
            <h1 className="font-serif text-4xl font-semibold mb-2 text-[#33241d]">Little Journal</h1>
            <p className="font-handwriting text-2xl text-[#665349] opacity-80">my tiny collection of memories ♡</p>
          </div>
        </div>

        <div className="flex flex-col gap-4 w-full">
          <Show when="signed-in">
            <Link href="/journal">
              <Button className="w-full bg-[#d16f80] hover:bg-[#b85b6b] text-white rounded-full py-6 text-lg shadow-lg hover:shadow-xl transition-all">
                Open Journal
              </Button>
            </Link>
          </Show>

          <Show when="signed-out">
            <Link href="/sign-up">
              <Button className="w-full bg-[#d16f80] hover:bg-[#b85b6b] text-white rounded-full py-6 text-lg shadow-lg hover:shadow-xl transition-all">
                Create a Journal
              </Button>
            </Link>
            <div className="text-center text-[#665349] mt-2">
              Already have one? <Link href="/sign-in" className="text-[#d16f80] hover:underline font-medium">Sign in</Link>
            </div>
            <Link href="/journal?demo=1">
              <Button variant="outline" className="w-full border-[#d16f80]/40 text-[#d16f80] hover:bg-[#fcf1f3] rounded-full py-5 shadow-sm transition-all">
                Open Demo Journal
              </Button>
            </Link>
          </Show>
        </div>
      </MotionDiv>
    </div>
  );
}