import { useState } from 'react';
import {
  ArrowUpRight,
  BookOpen,
  Check,
  Cloud,
  Menu,
  MousePointer2,
  Sparkles,
  X,
} from 'lucide-react';
import './_group.css';
import './NotebookLanding.css';

const featureCopy = {
  arrange: {
    number: '01',
    title: 'Arrange it your way.',
    body: 'Drop in a photo, drag it somewhere better, turn it a little. There is no grid to obey.',
  },
  keep: {
    number: '02',
    title: 'Keep the in-between.',
    body: 'Layer Polaroids, small notes, stickers and the things that would otherwise disappear.',
  },
  return: {
    number: '03',
    title: 'Return from anywhere.',
    body: 'Your pages stay with you. Pick up the same journal on your phone or your computer.',
  },
};

type FeatureId = keyof typeof featureCopy;

export function NotebookLanding() {
  const [activeFeature, setActiveFeature] = useState<FeatureId>('arrange');
  const [menuOpen, setMenuOpen] = useState(false);
  const [notice, setNotice] = useState('');
  const [demoOpen, setDemoOpen] = useState(false);

  const showNotice = (message: string) => {
    setNotice(message);
    window.setTimeout(() => setNotice(''), 2800);
  };

  const openJournal = () => {
    setDemoOpen(false);
    showNotice('Your first page is waiting.');
  };

  const openDemo = () => {
    setDemoOpen(true);
    showNotice('Demo journal opened — try turning the page.');
  };

  return (
    <main className={`lj-notebook ${demoOpen ? 'is-demo' : ''}`}>
      <header className="lj-notebook__header">
        <a className="lj-notebook__brand" href="#top" aria-label="Little Journal home">
          <span className="lj-notebook__brand-mark">LJ</span>
          <span>little journal</span>
        </a>
        <div className="lj-notebook__header-note">A digital scrapbook for real life</div>
        <nav className={`lj-notebook__nav ${menuOpen ? 'is-open' : ''}`}>
          <a href="#how-it-works">How it works</a>
          <a href="#features">Features</a>
          <button onClick={openJournal}>Start a journal <ArrowUpRight size={13} /></button>
        </nav>
        <button
          className="lj-notebook__menu"
          onClick={() => setMenuOpen((current) => !current)}
          aria-label={menuOpen ? 'Close menu' : 'Open menu'}
          aria-expanded={menuOpen}
        >
          {menuOpen ? <X size={19} /> : <Menu size={19} />}
        </button>
      </header>

      <section className="lj-notebook__hero" id="top">
        <div className="lj-notebook__copy">
          <p className="lj-notebook__eyebrow"><Sparkles size={13} /> A place for the small stuff</p>
          <h1>Make room<br /><em>for the days.</em></h1>
          <p className="lj-notebook__intro">
            Little Journal is a digital scrapbook for photographs, sentences and
            small pieces of life you want to keep close.
          </p>
          <div className="lj-notebook__actions">
            <button className="lj-notebook__primary" onClick={openJournal}>
              Make a page <ArrowUpRight size={15} />
            </button>
            <button className="lj-notebook__secondary" onClick={openDemo}>
              <BookOpen size={15} /> Open the demo
            </button>
          </div>
          <div className="lj-notebook__rule">
            <span />
            <i>Not polished. Just yours.</i>
          </div>
          {notice && <p className="lj-notebook__notice"><Check size={13} /> {notice}</p>}
        </div>

        <div className="lj-notebook__stage" aria-label="The real notebook used for Little Journal">
          <div className="lj-notebook__stage-label">
            <span>THE OBJECT</span>
            <strong>your pages, kept online</strong>
          </div>
          <div className="lj-notebook__index">LJ / 001</div>
          <div className="lj-notebook__crosshair lj-notebook__crosshair--one" />
          <div className="lj-notebook__crosshair lj-notebook__crosshair--two" />
          <div className="lj-notebook__image-wrap">
            <img
              className="lj-notebook__image"
              src="/__mockup/images/little-journal-notebook.png"
              alt="Open lined notebook with a pink cover and ribbon bookmark"
            />
            <div className="lj-notebook__image-caption">open / place / keep</div>
          </div>
          <div className="lj-notebook__callout lj-notebook__callout--photo">
            <MousePointer2 size={14} />
            <span><b>drag</b> a Polaroid anywhere</span>
          </div>
          <div className="lj-notebook__callout lj-notebook__callout--cloud">
            <Cloud size={14} />
            <span><b>saved</b> across every screen</span>
          </div>
          <div className="lj-notebook__sticker">YOUR<br />STORY<br /><small>01—∞</small></div>
          <div className="lj-notebook__demo-tag">
            <span className="lj-notebook__demo-dot" />
            {demoOpen ? 'DEMO JOURNAL OPEN' : 'THE FIRST PAGE'}
          </div>
        </div>
      </section>

      <section className="lj-notebook__lower" id="features">
        <div className="lj-notebook__manifesto" id="how-it-works">
          <span>THE IDEA</span>
          <p>Make a little space<br />for what made today<br /><em>different.</em></p>
        </div>
        <div className="lj-notebook__features">
          {(Object.keys(featureCopy) as FeatureId[]).map((id) => (
            <button
              key={id}
              className={`lj-notebook__feature ${activeFeature === id ? 'is-active' : ''}`}
              onClick={() => setActiveFeature(id)}
            >
              <span className="lj-notebook__feature-number">{featureCopy[id].number}</span>
              <span className="lj-notebook__feature-title">{featureCopy[id].title}</span>
              {activeFeature === id && <span className="lj-notebook__feature-body">{featureCopy[id].body}</span>}
            </button>
          ))}
        </div>
      </section>

      <footer className="lj-notebook__footer">
        <span>little journal / keep what you nearly forgot</span>
        <span>03 — come back to it</span>
      </footer>
    </main>
  );
}