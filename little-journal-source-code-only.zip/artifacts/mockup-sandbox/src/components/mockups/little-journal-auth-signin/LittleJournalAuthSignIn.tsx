import { useState, type FormEvent } from "react";
import { ArrowLeft, Eye, EyeOff, Sparkles } from "lucide-react";

import "./LittleJournalAuthSignIn.css";

const image = (filename: string) => `/__mockup/images/${filename}`;

export function LittleJournalAuthSignIn() {
  const [showPassword, setShowPassword] = useState(false);
  const [status, setStatus] = useState("");

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setStatus("Your journal is ready to open.");
  };

  return (
    <main className="lj-signin">
      <div className="lj-signin__shell">
        <section className="lj-signin__form-pane">
          <header className="lj-signin__topbar">
            <span className="lj-signin__back">
              <ArrowLeft size={14} strokeWidth={3} />
              Back
            </span>
            <span className="lj-signin__brand">Little Journal</span>
          </header>

          <div className="lj-signin__content">
            <div className="lj-signin__surface">
              <header className="lj-signin__header">
                <div className="lj-signin__logo">
                  <Sparkles size={21} strokeWidth={1.8} />
                </div>
                <p className="lj-signin__eyebrow">A quiet place for your memories</p>
                <h1>Welcome back</h1>
                <p className="lj-signin__subtitle">Your little things are here</p>
              </header>

              <form className="lj-signin__form" onSubmit={handleSubmit}>
                <button
                  className="lj-signin__google"
                  type="button"
                  onClick={() => setStatus("Google sign in is ready to connect.")}
                >
                  <span className="lj-signin__google-mark">G</span>
                  Continue with Google
                </button>

                <div className="lj-signin__divider">OR</div>

                <label className="lj-signin__field">
                  <span>Email address</span>
                  <input type="email" placeholder="Enter your email address" autoComplete="email" />
                </label>

                <label className="lj-signin__field">
                  <span>Password</span>
                  <div className="lj-signin__input-wrap">
                    <input
                      type={showPassword ? "text" : "password"}
                      placeholder="Enter your password"
                      autoComplete="current-password"
                    />
                    <button
                      className="lj-signin__password"
                      type="button"
                      aria-label={showPassword ? "Hide password" : "Show password"}
                      onClick={() => setShowPassword((visible) => !visible)}
                    >
                      {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>
                </label>

                <button className="lj-signin__forgot" type="button" onClick={() => setStatus("Password reset is ready to connect.")}>
                  Forgot password?
                </button>

                <button className="lj-signin__submit" type="submit">
                  Open my journal <span aria-hidden="true">›</span>
                </button>
                <p className="lj-signin__status" role="status">
                  {status}
                </p>
              </form>

              <p className="lj-signin__footer">
                New to Little Journal? <a href="#sign-up">Make one</a>
              </p>
            </div>
          </div>
        </section>

        <aside className="lj-signin__art" aria-label="Scrapbook artwork">
          <div className="lj-signin__art-grid" />
          <div className="lj-signin__composition">
            <img
              className="lj-signin__journal"
              src={image("little-journal-auth-copy-meFqqY1l-notebook.png")}
              alt="Open journal notebook"
            />
            <div className="lj-signin__besties">
              <img src={image("journal-photo-besties.png")} alt="Two friends outdoors" />
            </div>
            <div className="lj-signin__photo-strip">
              <img src={image("journal-photo-bubbles.png")} alt="Friends by the water" />
              <img src={image("journal-photo-guitars.png")} alt="Guitars and a sunny day" />
            </div>
            <img className="lj-signin__sticker" src={image("sticker-bow.png")} alt="Bow sticker" />
            <img className="lj-signin__sticker-alt" src={image("sticker-butterfly-purple.png")} alt="Butterfly sticker" />
            <img className="lj-signin__camera" src={image("camera.png")} alt="Camera" />
            <img className="lj-signin__mini-photo" src={image("journal-photo-headphones.png")} alt="Headphones on a table" />
            <img className="lj-signin__tag" src={image("sticker-star.png")} alt="Star sticker" />
          </div>
        </aside>
      </div>
    </main>
  );
}