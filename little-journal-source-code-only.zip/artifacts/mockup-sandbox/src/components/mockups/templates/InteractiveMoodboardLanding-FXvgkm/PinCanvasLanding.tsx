import asset0 from "./assets/pincanvas-mood1.png";
import asset1 from "./assets/pincanvas-photo2.png";
import asset2 from "./assets/pincanvas-texture1.png";

import React, { useState, useRef, useEffect } from 'react';
import { MousePointer2, Plus, Sparkles, GripHorizontal, ArrowRight, LayoutGrid } from 'lucide-react';

type DragItem = {
  id: string;
  type: 'image' | 'note' | 'swatch' | 'link';
  x: number;
  y: number;
  rotation: number;
  zIndex: number;
  content?: string;
  src?: string;
  color?: string;
  title?: string;
  subtitle?: string;
};

const INITIAL_ITEMS: DragItem[] = [
  {
    id: '1',
    type: 'image',
    x: 850,
    y: 120,
    rotation: 4,
    zIndex: 10,
    src: asset0,
  },
  {
    id: '2',
    type: 'note',
    x: 180,
    y: 500,
    rotation: -6,
    zIndex: 15,
    content: 'Find the space between chaos and structure.',
  },
  {
    id: '3',
    type: 'image',
    x: 120,
    y: 140,
    rotation: -3,
    zIndex: 8,
    src: asset1,
  },
  {
    id: '4',
    type: 'swatch',
    x: 920,
    y: 480,
    rotation: 8,
    zIndex: 12,
    color: '#D87A5D',
    title: 'Terracotta',
    subtitle: 'Hex #D87A5D',
  },
  {
    id: '5',
    type: 'image',
    x: 660,
    y: 715,
    rotation: -2,
    zIndex: 9,
    src: asset2,
  },
  {
    id: '6',
    type: 'link',
    x: 750,
    y: 80,
    rotation: 2,
    zIndex: 20,
    title: 'Typography Inspiration',
    subtitle: 'typewolf.com',
  }
];

export default function PinCanvasLanding() {
  const [items, setItems] = useState<DragItem[]>(INITIAL_ITEMS);
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [highestZ, setHighestZ] = useState(20);
  const containerRef = useRef<HTMLDivElement>(null);

  const captureElRef = useRef<HTMLElement | null>(null);

  // Convert viewport coordinates to container-local coordinates so dragging
  // works no matter where the canvas root sits in the embedding page.
  const toLocal = (clientX: number, clientY: number) => {
    const rect = containerRef.current?.getBoundingClientRect();
    return {
      x: clientX - (rect?.left ?? 0),
      y: clientY - (rect?.top ?? 0)
    };
  };

  const handlePointerDown = (e: React.PointerEvent, id: string) => {
    // Only drag on left click / primary pointer
    if (e.button !== 0) return;

    const captureEl = e.currentTarget as HTMLElement;
    captureEl.setPointerCapture(e.pointerId);
    captureElRef.current = captureEl;

    const item = items.find(i => i.id === id);
    if (!item) return;

    const newZ = highestZ + 1;
    setHighestZ(newZ);

    setItems(prev => prev.map(i => 
      i.id === id ? { ...i, zIndex: newZ } : i
    ));

    setDraggingId(id);

    const local = toLocal(e.clientX, e.clientY);
    setDragOffset({
      x: local.x - item.x,
      y: local.y - item.y
    });
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!draggingId) return;

    const local = toLocal(e.clientX, e.clientY);
    setItems(prev => prev.map(i => {
      if (i.id === draggingId) {
        return {
          ...i,
          x: local.x - dragOffset.x,
          y: local.y - dragOffset.y
        };
      }
      return i;
    }));
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (!draggingId) return;
    const captureEl = captureElRef.current;
    if (captureEl && captureEl.hasPointerCapture(e.pointerId)) {
      captureEl.releasePointerCapture(e.pointerId);
    }
    captureElRef.current = null;
    setDraggingId(null);
  };

  return (
    <div 
      ref={containerRef}
      className="relative w-full h-full bg-[#F4F1EB] overflow-hidden text-[#1C1A17] font-['Inter',sans-serif] selection:bg-[#D87A5D] selection:text-white"
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      onPointerLeave={handlePointerUp}
      style={{ touchAction: 'none' }} // Prevent scrolling while dragging on touch devices
    >
      {/* Subtle Background Grid/Texture */}
      <div className="absolute inset-0 pointer-events-none opacity-20"
           style={{
             backgroundImage: `radial-gradient(#1C1A17 1px, transparent 1px)`,
             backgroundSize: '32px 32px'
           }}
      />

      {/* Navigation */}
      <nav className="absolute top-0 left-0 right-0 p-8 flex justify-between items-center z-50 pointer-events-none">
        <div className="flex items-center gap-3 pointer-events-auto">
          <div className="w-8 h-8 bg-[#D87A5D] rounded-md flex items-center justify-center rotate-3">
            <LayoutGrid size={18} className="text-white" />
          </div>
          <span className="font-['Space_Grotesk',sans-serif] font-bold text-xl tracking-tight">PinCanvas</span>
        </div>
        <div className="flex items-center gap-6 pointer-events-auto">
          <a href="#" className="text-sm font-medium hover:text-[#D87A5D] transition-colors">Manifesto</a>
          <a href="#" className="text-sm font-medium hover:text-[#D87A5D] transition-colors">Gallery</a>
          <a href="#" className="text-sm font-medium hover:text-[#D87A5D] transition-colors">Pricing</a>
          <button className="bg-[#1C1A17] text-white px-5 py-2.5 rounded-full text-sm font-medium hover:bg-[#333] transition-transform hover:scale-105 active:scale-95 flex items-center gap-2">
            Start Collecting <ArrowRight size={16} />
          </button>
        </div>
      </nav>

      {/* Hero Content - Centered */}
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none z-30">
        <div className="max-w-[700px] text-center flex flex-col items-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/60 backdrop-blur-md border border-white/40 shadow-sm mb-8 pointer-events-auto">
            <Sparkles size={14} className="text-[#D87A5D]" />
            <span className="text-xs font-semibold tracking-wide uppercase">Your ideas, unboxed</span>
          </div>
          <h1 className="text-[64px] font-['Playfair_Display',serif] font-medium leading-[1.1] text-[#1C1A17] mb-6 drop-shadow-sm">
            Think outside <br /> the grid.
          </h1>
          <p className="text-lg text-[#555] max-w-[480px] leading-relaxed mb-10 font-['Space_Grotesk',sans-serif]">
            The infinite workspace for spatial thinkers. Pin images, drop links, tear notes, and arrange your thoughts exactly how your brain works.
          </p>
          
          <div className="flex items-center gap-4 pointer-events-auto">
             <button className="h-14 px-8 bg-[#D87A5D] text-white rounded-full font-medium text-lg shadow-[0_4px_14px_rgba(216,122,93,0.4)] hover:-translate-y-1 hover:shadow-[0_6px_20px_rgba(216,122,93,0.5)] transition-all flex items-center gap-2">
              Create your board
            </button>
          </div>
        </div>
      </div>

      {/* Draggable Area Container */}
      <div className="absolute inset-0 z-40 pointer-events-none">
        {/* Render Items */}
        {items.map(item => {
          const isDragging = draggingId === item.id;
          
          return (
            <div
              key={item.id}
              onPointerDown={(e) => handlePointerDown(e, item.id)}
              className={`absolute cursor-grab active:cursor-grabbing pointer-events-auto origin-center transition-[box-shadow,transform] duration-200 ease-out will-change-transform
                ${isDragging ? 'shadow-2xl scale-105' : 'shadow-md hover:shadow-lg'}`}
              style={{
                left: item.x,
                top: item.y,
                zIndex: item.zIndex,
                transform: `rotate(${isDragging ? 0 : item.rotation}deg)`,
              }}
            >
              {/* Item Renderers based on type */}
              {item.type === 'image' && (
                <div className="bg-white p-3 pb-12 rounded-sm border border-black/5 flex flex-col w-[260px] group">
                  <div className="w-full h-[320px] bg-gray-100 overflow-hidden relative">
                    <img src={item.src} alt="Pinned" className="w-full h-full object-cover pointer-events-none" draggable={false} />
                    {/* Drag Hint overlay on hover */}
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                      <div className="bg-white/90 backdrop-blur text-xs font-semibold px-3 py-1.5 rounded-full flex items-center gap-2 shadow-sm">
                        <GripHorizontal size={14} /> Drag me
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {item.type === 'note' && (
                <div className="w-[220px] min-h-[220px] bg-[#FDF9C4] p-6 shadow-sm border border-[#E9E4A6] relative group">
                  {/* Tape piece */}
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-12 h-6 bg-white/40 rotate-2 border border-black/5 shadow-sm backdrop-blur-sm"></div>
                  <p className="font-['Playfair_Display',serif] italic text-xl leading-relaxed text-[#4A4835] pointer-events-none">
                    {item.content}
                  </p>
                  <div className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                     <GripHorizontal size={16} className="text-black/20" />
                  </div>
                </div>
              )}

              {item.type === 'swatch' && (
                <div className="bg-white rounded-xl overflow-hidden shadow-sm border border-black/5 w-[180px] group">
                  <div className="w-full h-[180px]" style={{ backgroundColor: item.color }}></div>
                  <div className="p-4 bg-white">
                    <h3 className="font-bold text-sm">{item.title}</h3>
                    <p className="text-xs text-gray-500 mt-1 uppercase tracking-wider">{item.subtitle}</p>
                  </div>
                  <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity bg-white/20 backdrop-blur rounded-full p-1">
                     <GripHorizontal size={16} className="text-white" />
                  </div>
                </div>
              )}

              {item.type === 'link' && (
                <div className="bg-white rounded-xl p-4 shadow-sm border border-black/5 w-[240px] flex items-center gap-4 group">
                  <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <div className="w-6 h-6 border-2 border-black rounded-sm"></div>
                  </div>
                  <div className="overflow-hidden pointer-events-none">
                    <h3 className="font-bold text-sm truncate">{item.title}</h3>
                    <p className="text-xs text-gray-500 mt-1 truncate">{item.subtitle}</p>
                  </div>
                  <div className="absolute right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                     <GripHorizontal size={16} className="text-black/20" />
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Floating Action Button (UI Decor) */}
      <div className="absolute bottom-8 right-8 z-50">
        <div className="w-14 h-14 bg-[#1C1A17] rounded-full shadow-lg flex items-center justify-center cursor-pointer hover:scale-105 transition-transform">
          <Plus size={24} className="text-white" />
        </div>
      </div>
      
      {/* Decorative cursor element */}
      <div className="absolute bottom-[20%] left-[25%] pointer-events-none z-50 flex items-center gap-2 animate-bounce">
         <MousePointer2 size={24} className="text-[#D87A5D] fill-[#D87A5D]" style={{ transform: 'rotate(-15deg)' }} />
         <div className="bg-black text-white text-[10px] font-bold uppercase tracking-wider px-3 py-1.5 rounded-full shadow-md">
           Grab and drag!
         </div>
      </div>
    </div>
  );
}