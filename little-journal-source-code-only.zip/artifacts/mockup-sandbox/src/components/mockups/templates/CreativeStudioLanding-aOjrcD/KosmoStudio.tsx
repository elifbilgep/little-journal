import React, { useState } from 'react';
import './fonts.css';
import './KosmoStudio.css';
import asset0 from "./assets/kosmo-art1.png";
import asset1 from "./assets/kosmo-art2.png";
import asset2 from "./assets/kosmo-art3.png";
import asset3 from "./assets/kosmo-art4.png";
import asset4 from "./assets/kosmo-art5.png";
import asset5 from "./assets/kosmo-portrait1.png";
import asset6 from "./assets/kosmo-portrait2.png";
import asset7 from "./assets/kosmo-portrait3.png";

export default function KosmoStudio() {
  const [selectedWork, setSelectedWork] = useState(0);
  const [contactOpen, setContactOpen] = useState(false);
  const works = [
    { title: 'Morrow / objects for a slower future', meta: 'Identity · 2024', src: asset0 },
    { title: 'Field Notes / a visual language for outside', meta: 'Campaign · 2024', src: asset1 },
    { title: 'Room 17 / sound, light, movement', meta: 'Digital · 2023', src: asset2 },
    { title: 'Common Practice / tools for making', meta: 'Editorial · 2023', src: asset3 },
    { title: 'No. 05 / a study in contrast', meta: 'Art direction · 2022', src: asset4 },
  ];

  return (
    <main className="kosmo-shell">
      <div className="kosmo-topline">
        <span>KOSMO / INDEPENDENT DESIGN OFFICE</span>
        <span>EST. 2016 — 51°03′N 13°44′E</span>
        <span className="kosmo-status"><i /> Taking on 02 new projects</span>
      </div>

      <header className="kosmo-nav">
        <a className="kosmo-wordmark" href="#top" aria-label="Kosmo home">KOSMO<span>®</span></a>
        <nav aria-label="Primary navigation">
          <a href="#work">Selected work</a>
          <a href="#studio">Studio</a>
          <a href="#contact">Contact</a>
        </nav>
        <button className="kosmo-menu" type="button" onClick={() => setContactOpen(!contactOpen)}>
          {contactOpen ? 'Close ×' : 'Menu +'}
        </button>
      </header>

      <section className="kosmo-hero" id="top">
        <div className="kosmo-hero-copy">
          <p className="kosmo-kicker">[ 00 / INTRODUCTION ]</p>
          <h1>Good ideas<br /><em>need a point<br />of view.</em></h1>
          <p className="kosmo-dek">Kosmo is a small design office for brands with something to say. We make identities, digital places and printed matter that refuse to blend in.</p>
          <a className="kosmo-arrow-link" href="#work">See the work <span>↘</span></a>
        </div>
        <div className="kosmo-hero-art" aria-label="Featured studio work">
          <div className="kosmo-art-label">CURRENTLY<br />LOOKING AT</div>
          <img src={works[selectedWork].src} alt={works[selectedWork].title} />
          <span className="kosmo-art-note">FIG. 0{selectedWork + 1} / 05</span>
          <span className="kosmo-cross kosmo-cross-one">+</span>
          <span className="kosmo-cross kosmo-cross-two">+</span>
        </div>
      </section>

      <section className="kosmo-work" id="work">
        <div className="kosmo-section-head">
          <p className="kosmo-kicker">[ 01 / SELECTED WORK ]</p>
          <p className="kosmo-index">05 projects / 2019—24</p>
        </div>
        <div className="kosmo-work-grid">
          <div className="kosmo-work-list">
            {works.map((work, index) => (
              <button
                className={`kosmo-work-row ${selectedWork === index ? 'is-selected' : ''}`}
                key={work.title}
                type="button"
                onClick={() => setSelectedWork(index)}
              >
                <span className="kosmo-work-number">0{index + 1}</span>
                <span className="kosmo-work-title">{work.title}</span>
                <span className="kosmo-work-meta">{work.meta}</span>
                <span className="kosmo-work-arrow">↗</span>
              </button>
            ))}
          </div>
          <div className="kosmo-selection">
            <img src={works[selectedWork].src} alt="" />
            <p>{works[selectedWork].meta}</p>
            <strong>{works[selectedWork].title}</strong>
            <button type="button" onClick={() => setSelectedWork((selectedWork + 1) % works.length)}>Next project ↗</button>
          </div>
        </div>
      </section>

      <section className="kosmo-bottom" id="studio">
        <div className="kosmo-bottom-title">Small team.<br /><span>Big signal.</span></div>
        <div className="kosmo-bottom-copy">
          <p className="kosmo-kicker">[ 02 / THE STUDIO ]</p>
          <p>Strategy, identity and digital craft — all under one roof, without the layers in between.</p>
          <div className="kosmo-faces">
            {[asset5, asset6, asset7].map((src, index) => <img key={src} src={src} alt={`Kosmo team member ${index + 1}`} />)}
          </div>
        </div>
      </section>

      {contactOpen && (
        <aside className="kosmo-contact" id="contact">
          <p className="kosmo-kicker">[ LET'S MAKE SOMETHING ]</p>
          <h2>Tell us the<br /><em>uncomfortable</em> bit.</h2>
          <a href="mailto:hello@kosmo.studio">hello@kosmo.studio ↗</a>
          <button type="button" onClick={() => setContactOpen(false)}>Dismiss</button>
        </aside>
      )}
      {!contactOpen && <button className="kosmo-project-cta" type="button" onClick={() => setContactOpen(true)}>Start a project <span>↗</span></button>}
      <footer className="kosmo-footer"><span>© KOSMO STUDIO</span><span>Made with intent, not templates.</span><span>Scroll to explore ↓</span></footer>
    </main>
  );
}
