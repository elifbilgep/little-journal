import './fonts.css';
import './KosmoStudio.css';
import asset0 from "./assets/kosmo-art1.png";
import asset1 from "./assets/kosmo-art2.png";
import asset2 from "./assets/kosmo-art3.png";
import asset3 from "./assets/kosmo-art4.png";
import asset4 from "./assets/kosmo-art5.png";
import asset5 from "./assets/kosmo-portrait1.png";
import asset6 from "./assets/kosmo-portrait2.png";
import asset7 from "./assets/kosmo-portrait3.png";

import React, { useState } from 'react';
import { ArrowUpRight, Menu, Plus, X } from 'lucide-react';

export default function KosmoStudio() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [journalOpen, setJournalOpen] = useState(false);
  const [noteAdded, setNoteAdded] = useState(false);
  const [activeSection, setActiveSection] = useState('Journal');
  const memories = [
    { src: asset0, label: '01 / Morning walk', date: '14.04.24', tone: 'memory-a' },
    { src: asset1, label: '02 / Near the water', date: '28.05.24', tone: 'memory-b' },
    { src: asset2, label: '03 / A small detour', date: '06.06.24', tone: 'memory-c' },
  ];

  return (
    <div className="lj-landing">
      <div className="lj-shell">
        <header className="lj-header">
          <button className="lj-wordmark" onClick={() => setActiveSection('Journal')} aria-label="Little Journal home">
            <span className="lj-mark">LJ</span>
            <span>Little Journal</span>
          </button>
          <nav className={`lj-nav ${menuOpen ? 'is-open' : ''}`} aria-label="Primary navigation">
            {['Journal', 'Archive', 'About'].map((item) => (
              <button key={item} className={activeSection === item ? 'is-active' : ''} onClick={() => { setActiveSection(item); setMenuOpen(false); }}>
                {item}
              </button>
            ))}
          </nav>
          <div className="lj-header-actions">
            <span className="lj-edition">Issue 01 / 2024</span>
            <button className="lj-menu-button" onClick={() => setMenuOpen((open) => !open)} aria-label="Toggle menu">
              {menuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
            <button className="lj-open-button" onClick={() => setJournalOpen(true)}>
              Open journal <ArrowUpRight size={15} />
            </button>
          </div>
        </header>

        <main className="lj-main">
          <section className="lj-hero">
            <div className="lj-kicker"><span /> A private place for public days</div>
            <h1>Keep the parts<br /><em>worth keeping.</em></h1>
            <div className="lj-intro-row">
              <p>Little Journal is a quiet digital notebook for photographs, fragments, and the ordinary details you do not want to lose.</p>
              <button className="lj-text-link" onClick={() => setJournalOpen(true)}>Make a page <ArrowUpRight size={16} /></button>
            </div>
          </section>

          <section className="lj-index" aria-label="Journal preview">
            <div className="lj-index-header">
              <span>Selected pages</span>
              <span>03 / 24</span>
            </div>
            <div className="lj-memory-grid">
              {memories.map((memory, index) => (
                <button key={memory.label} className={`lj-memory ${memory.tone}`} onClick={() => setActiveSection(memory.label)}>
                  <div className="lj-memory-image"><img src={memory.src} alt="" /></div>
                  <div className="lj-memory-meta"><span>{memory.label}</span><span>{memory.date}</span></div>
                  {index === 1 && <span className="lj-memory-note">kept here</span>}
                </button>
              ))}
              <button className="lj-add-memory" onClick={() => { setNoteAdded(true); setActiveSection('New page'); }}>
                <Plus size={19} />
                <span>{noteAdded ? 'Page added' : 'Add a memory'}</span>
              </button>
            </div>
          </section>

          <section className="lj-footer-strip">
            <div><span className="lj-strip-number">01</span><span>Make space for what happened.</span></div>
            <div className="lj-strip-right"><span>Built for remembering</span><span className="lj-dot" /></div>
          </section>
        </main>

        {journalOpen && (
          <div className="lj-dialog-backdrop" role="presentation" onClick={() => setJournalOpen(false)}>
            <div className="lj-dialog" role="dialog" aria-modal="true" onClick={(event) => event.stopPropagation()}>
              <button className="lj-dialog-close" onClick={() => setJournalOpen(false)} aria-label="Close"><X size={18} /></button>
              <span className="lj-kicker"><span /> Start a page</span>
              <h2>What do you want<br /><em>to remember?</em></h2>
              <textarea placeholder="A sentence, a place, a small thing..." autoFocus />
              <button className="lj-dialog-submit" onClick={() => { setJournalOpen(false); setNoteAdded(true); setActiveSection('New page'); }}>Save a first note <ArrowUpRight size={16} /></button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
