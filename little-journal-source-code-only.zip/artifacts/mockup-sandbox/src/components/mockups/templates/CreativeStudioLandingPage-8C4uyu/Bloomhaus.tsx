import './fonts.css';
import asset0 from "./assets/bloomhaus-architecture.png";
import asset1 from "./assets/bloomhaus-dessert.png";
import asset2 from "./assets/bloomhaus-flower.png";
import asset3 from "./assets/bloomhaus-portrait.png";
import asset4 from "./assets/bloomhaus-silhouette.png";
import asset5 from "./assets/bloomhaus-sunglasses.png";

const MOCKUP_ASSETS: Record<string, string> = {
  "bloomhaus-architecture.png": asset0,
  "bloomhaus-dessert.png": asset1,
  "bloomhaus-flower.png": asset2,
  "bloomhaus-portrait.png": asset3,
  "bloomhaus-silhouette.png": asset4,
  "bloomhaus-sunglasses.png": asset5,
};

import React from 'react';
import { Star, ArrowRight, PenTool, Layout, Layers, Box } from 'lucide-react';

export default function Bloomhaus() {
  const cards = [
    { src: 'bloomhaus-dessert.png', rotation: -24, x: -290, y: 60, z: 10 },
    { src: 'bloomhaus-flower.png', rotation: -14, x: -170, y: 20, z: 20 },
    { src: 'bloomhaus-portrait.png', rotation: -4, x: -60, y: 0, z: 30 },
    { src: 'bloomhaus-sunglasses.png', rotation: 4, x: 50, y: 0, z: 40 },
    { src: 'bloomhaus-architecture.png', rotation: 14, x: 160, y: 20, z: 30 },
    { src: 'bloomhaus-silhouette.png', rotation: 24, x: 280, y: 60, z: 20 },
  ];

  const services = [
    { title: "BRAND IDENTITY", icon: <PenTool className="w-5 h-5"/>, bg: "bg-[#FFE4E9]" },
    { title: "WEB DESIGN", icon: <Layout className="w-5 h-5"/>, bg: "bg-[#FFF4D4]" },
    { title: "DEVELOPMENT", icon: <Layers className="w-5 h-5"/>, bg: "bg-[#E4F9F0]" },
    { title: "CONTENT", icon: <Box className="w-5 h-5"/>, bg: "bg-[#E4F2FF]" },
  ];

  return (
    <div className="w-full h-full bg-[#3B2B23] p-4 overflow-hidden relative font-['Montserrat'] text-[#1c1a19] flex justify-center items-center">
      <div className="w-full h-full bg-white rounded-[2rem] overflow-hidden flex flex-col relative shadow-2xl shadow-black/20">
        
        {/* Header */}
        <header className="w-full flex justify-between items-center px-12 py-8 z-20 relative shrink-0">
          <div className="font-extrabold text-2xl tracking-tight">
            Bloomhaus<span className="text-[#FF9B71]">.</span>
          </div>
          <nav className="flex gap-12 text-[11px] font-bold tracking-[0.15em] uppercase">
            <a href="#" className="hover:text-[#FF9B71] transition-colors">Work</a>
            <a href="#" className="hover:text-[#FF9B71] transition-colors">Services</a>
            <a href="#" className="hover:text-[#FF9B71] transition-colors">Studio</a>
            <a href="#" className="hover:text-[#FF9B71] transition-colors">Journal</a>
          </nav>
          <div className="w-[100px] flex justify-end">
             <div className="w-10 h-10 rounded-full border border-[#1c1a19]/20 flex items-center justify-center hover:bg-[#1c1a19] hover:text-white transition-all cursor-pointer">
               <ArrowRight className="w-4 h-4 -rotate-45" />
             </div>
          </div>
        </header>

        {/* Hero Section */}
        <div className="flex-1 flex flex-col items-center pt-2 z-10 relative">
          
          <h1 className="font-black text-[220px] leading-[0.75] tracking-[-0.06em] text-[#1c1a19]">
            BLMHS
          </h1>
          
          <div className="flex items-center gap-8 mt-10">
            <p className="text-[12px] font-bold tracking-[0.2em] uppercase text-[#1c1a19]/70 text-right leading-relaxed">
              We architect digital <br/> experiences that defy <br/> the ordinary.
            </p>
            <div className="w-[1px] h-10 bg-[#1c1a19]/20"></div>
            <button className="bg-[#1c1a19] text-white px-8 py-4 rounded-full text-[11px] font-bold tracking-[0.15em] uppercase flex items-center gap-3 hover:bg-[#3B2B23] transition-colors shadow-xl shadow-black/10">
              Let's Discuss <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Fanned Arc */}
          <div className="relative w-full h-[240px] flex justify-center z-10 mt-8">
            <div className="relative w-[600px] h-full flex justify-center">
              {cards.map((card, i) => (
                <div 
                  key={i}
                  className="absolute bottom-2 w-[140px] h-[190px] rounded-[24px] overflow-hidden border-[6px] border-white shadow-xl shadow-black/10 origin-bottom"
                  style={{ 
                    transform: `translateX(${card.x}px) translateY(${card.y}px) rotate(${card.rotation}deg)`,
                    zIndex: card.z
                  }}
                >
                  <img src={MOCKUP_ASSETS[card.src]} className="w-full h-full object-cover" alt="Portfolio thumbnail" />
                </div>
              ))}
            </div>
          </div>

          {/* Star Rating */}
          <div className="flex flex-col items-center mt-2 z-20 relative">
            <div className="flex gap-1 mb-1.5">
              {[...Array(5)].map((_, i) => <Star key={i} className="w-[14px] h-[14px] fill-[#1c1a19] text-[#1c1a19]" />)}
            </div>
            <div className="text-[10px] font-bold tracking-[0.15em] text-[#1c1a19]/60 uppercase">
              4.9/5.0 Rated By 10K+ Global Brands
            </div>
          </div>

        </div>

        {/* Bottom Secondary Section */}
        <div className="absolute bottom-0 left-0 w-full h-[220px] bg-[#F4F1ED] px-16 py-8 flex items-center justify-between z-20 rounded-b-[2rem]">
          {/* Wavy Divider (Cream) */}
          <svg viewBox="0 0 1280 80" preserveAspectRatio="none" className="absolute bottom-full left-0 w-full h-[80px] fill-[#F4F1ED]">
            <path d="M0,80 L1280,80 L1280,40 C960,-20 320,100 0,40 Z" />
          </svg>
          
          <div className="relative flex flex-col justify-center h-full pt-4">
            <h2 className="font-black text-[38px] leading-[1.1] tracking-tight text-[#1c1a19]">
              WE BUILT THE ROCKET,<br/>THEY FLEW TO MARS.
            </h2>
            <div className="absolute -top-2 right-12 bg-[#FFD166] text-[#1c1a19] text-[10px] font-black tracking-widest px-4 py-1.5 rounded-full rotate-[8deg] border-[1.5px] border-[#1c1a19] shadow-[2px_2px_0px_#1c1a19]">
              PROVEN
            </div>
          </div>
          
          {/* Pastel Cards */}
          <div className="flex gap-4 pt-4 z-10 relative">
            {services.map((service, i) => (
              <div key={i} className={`w-[130px] h-[130px] rounded-[24px] ${service.bg} p-4 flex flex-col justify-between transition-transform hover:-translate-y-1`}>
                <div className="w-10 h-10 rounded-full bg-white/60 flex items-center justify-center text-[#1c1a19]">
                  {service.icon}
                </div>
                <div className="text-[11px] font-bold tracking-wider leading-tight text-[#1c1a19]">
                  {service.title}
                </div>
              </div>
            ))}
          </div>
        </div>
        
      </div>
    </div>
  );
}
