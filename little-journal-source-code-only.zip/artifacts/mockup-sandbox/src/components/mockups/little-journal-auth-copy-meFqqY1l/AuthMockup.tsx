import { useState, type FormEvent } from "react";
import { ArrowLeft, Eye, EyeOff, Sparkles } from "lucide-react";

import "./_group.css";

type AuthMode = "sign-in" | "sign-up";

const image = (filename: string) => `/__mockup/images/${filename}`;

function AuthMockup({ mode }: { mode: AuthMode }) {
  const [showPassword, setShowPassword] = useState(false);
  const isSignUp = mode === "sign-up";

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
  };

  return (
    <main className="lj-auth-mockup">
      <div className="lj-auth-mockup__layout">
        <section className="lj-auth-mockup__pane">
          <div className="lj-auth-mockup__topbar">
            <span className="lj-auth-mockup__back">
              <ArrowLeft size={14} strokeWidth={3} />
              Back
            </span>
            <span className="lj-auth-mockup__brand">Little Journal</span>
          </div>

          <div className="lj-auth-mockup__form-scroll">
            <div className="lj-auth-mockup__surface">
              <header className="lj-auth-mockup__header">
                <div className="lj-auth-mockup__logo">
                  <Sparkles size={22} strokeWidth={1.8} />
                </div>
                <h1 className="lj-auth-mockup__title">
                  {isSignUp ? "Start your journal" : "Welcome back"}
                </h1>
                <p className="lj-auth-mockup__subtitle">
                  {isSignUp
                    ? "A tiny collection of memories"
                    : "Sign in to open your journal"}
                </p>
              </header>

              <form className="lj-auth-mockup__form" onSubmit={handleSubmit}>
                <button className="lj-auth-mockup__google" type="button">
                  <span className="lj-auth-mockup__google-mark">G</span>
                  Continue with Google
                </button>

                <div className="lj-auth-mockup__divider">OR</div>

                <div className="lj-auth-mockup__field">
                  <label htmlFor={`${mode}-email`}>Email address</label>
                  <input
                    className="lj-auth-mockup__input"
                    id={`${mode}-email`}
                    type="email"
                    placeholder="Enter your email address"
                    autoComplete="email"
                  />
                </div>

                <div className="lj-auth-mockup__field">
                  <label htmlFor={`${mode}-password`}>Password</label>
                  <div className="lj-auth-mockup__input-wrap">
                    <input
                      className="lj-auth-mockup__input"
                      id={`${mode}-password`}
                      type={showPassword ? "text" : "password"}
                      placeholder={isSignUp ? "Create a password" : "Enter your password"}
                      autoComplete={isSignUp ? "new-password" : "current-password"}
                    />
                    <button
                      className="lj-auth-mockup__password"
                      type="button"
                      aria-label={showPassword ? "Hide password" : "Show password"}
                      onClick={() => setShowPassword((visible) => !visible)}
                    >
                      {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>
                </div>

                {!isSignUp && <a className="lj-auth-mockup__forgot" href="#forgot">Forgot password?</a>}

                <button className="lj-auth-mockup__submit" type="submit">
                  Continue
                  <span aria-hidden="true"> &nbsp;›</span>
                </button>
              </form>

              <p className="lj-auth-mockup__footer">
                {isSignUp ? "Already have an account? " : "New to Little Journal? "}
                <a href={isSignUp ? "#sign-in" : "#sign-up"}>
                  {isSignUp ? "Sign in" : "Sign up"}
                </a>
              </p>
              <div className="lj-auth-mockup__mode">Development mode</div>
            </div>
          </div>
        </section>

        <aside className="lj-auth-mockup__art" aria-label="Scrapbook artwork">
          <div className="lj-auth-mockup__art-grid" />
          <div className="lj-auth-mockup__composition">
            <img
              className="lj-auth-mockup__journal"
              src={image("studio-scrap-journal-cover-11.png")}
              alt="Pink plaid journal cover"
            />
            <div className="lj-auth-mockup__besties">
              <img src={image("journal-photo-besties.png")} alt="Two friends outdoors" />
              <span>Besties</span>
            </div>
            <img
              className="lj-auth-mockup__sticker"
              src={image("sticker-star.png")}
              alt="Star sticker"
            />
            <img className="lj-auth-mockup__camera" src={image("camera.png")} alt="Camera" />
            <div className="lj-auth-mockup__tag">Yours only</div>
          </div>
        </aside>
      </div>
    </main>
  );
}

export default AuthMockup;