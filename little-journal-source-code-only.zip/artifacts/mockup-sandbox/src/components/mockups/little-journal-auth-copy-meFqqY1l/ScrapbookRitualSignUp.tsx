import { useState, type FormEvent } from "react";
import { ArrowLeft, Eye, EyeOff } from "lucide-react";
import "./ScrapbookRitualSignUp.css";

const image = (filename: string) => `/__mockup/images/${filename}`;

export function ScrapbookRitualSignUp() {
  const [showPassword, setShowPassword] = useState(false);
  const [status, setStatus] = useState("");
  const [isSignIn, setIsSignIn] = useState(false);
  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setStatus(isSignIn ? "Your journal is ready to open." : "Your first page is waiting.");
  };
  return <main className="scrapbook-ritual"><div className="scrapbook-ritual__layout">
    <section className="scrapbook-ritual__left"><nav className="scrapbook-ritual__nav" aria-label="Authentication navigation"><button className="scrapbook-ritual__back" type="button" onClick={() => window.history.back()}><ArrowLeft size={13} aria-hidden="true" /> Back</button><span className="scrapbook-ritual__brand">Little Journal</span></nav>
      <div className="scrapbook-ritual__inner"><p className="scrapbook-ritual__eyebrow">A place to keep the little things</p><h1 className="scrapbook-ritual__title">{isSignIn ? "Welcome back, keeper." : "Make room for memories."}</h1><p className="scrapbook-ritual__subtitle">{isSignIn ? "Your pages have been tucked safely away. Let’s open them." : "Start a private collection of the days you want to remember."}</p>
        <form className="scrapbook-ritual__form" onSubmit={handleSubmit}><button className="scrapbook-ritual__google" type="button" onClick={() => setStatus("Google sign-in is ready when you are.")}><span className="scrapbook-ritual__google-mark">G</span> Continue with Google</button><div className="scrapbook-ritual__or">OR</div>
          <div className="scrapbook-ritual__field"><label htmlFor="ritual-email">Email address</label><input className="scrapbook-ritual__input" id="ritual-email" type="email" placeholder="you@example.com" autoComplete="email" required /></div>
          <div className="scrapbook-ritual__field"><label htmlFor="ritual-password">Password</label><div className="scrapbook-ritual__input-wrap"><input className="scrapbook-ritual__input" id="ritual-password" type={showPassword ? "text" : "password"} placeholder={isSignIn ? "Your password" : "Create a password"} autoComplete={isSignIn ? "current-password" : "new-password"} required minLength={6} /><button className="scrapbook-ritual__password" type="button" aria-label={showPassword ? "Hide password" : "Show password"} onClick={() => setShowPassword((visible) => !visible)}>{showPassword ? <EyeOff size={15} /> : <Eye size={15} />}</button></div></div>
          {!isSignIn && <p className="scrapbook-ritual__terms">By continuing, you agree to keep this little corner kind and private. <button type="button" onClick={() => setStatus("We keep things simple: your pages belong to you.")}>Read our promise</button></p>}<button className="scrapbook-ritual__submit" type="submit">{isSignIn ? "Open my journal" : "Start my journal"} <span aria-hidden="true">→</span></button><p className="scrapbook-ritual__status" role="status">{status}</p>
        </form><p className="scrapbook-ritual__footer">{isSignIn ? "New to Little Journal? " : "Already have an account? "}<button type="button" onClick={() => { setIsSignIn((value) => !value); setStatus(""); }}>{isSignIn ? "Make one" : "Sign in"}</button></p><p className="scrapbook-ritual__edition">No. 01 · made for remembering</p>
      </div></section>
    <aside className="scrapbook-ritual__right" aria-label="A scrapbook page"><div className="scrapbook-ritual__sun" /><div className="scrapbook-ritual__caption">keep this one</div><div className="scrapbook-ritual__stack"><div className="scrapbook-ritual__tape" /><div className="scrapbook-ritual__card"><img src={image("journal-photo-besties.png")} alt="Two friends making a memory together" /><h2>Small days,<br />saved well.</h2><p>notes from a life in progress</p></div><div className="scrapbook-ritual__sticker">KEEP<br />GOING</div></div><div className="scrapbook-ritual__scribble">today was good.</div></aside>
  </div></main>;
}

export default ScrapbookRitualSignUp;