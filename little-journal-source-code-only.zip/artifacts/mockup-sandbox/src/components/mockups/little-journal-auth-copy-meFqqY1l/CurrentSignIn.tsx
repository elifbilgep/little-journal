import AuthMockup from "./AuthMockup";

export function CurrentSignIn() {
  return <AuthMockup mode="sign-in" />;
}