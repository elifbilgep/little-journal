import { useState, type FormEvent } from "react";
import { ArrowRight, Check, Eye, EyeOff, Heart, LockKeyhole, Sparkles } from "lucide-react";
import "./MemoryPagesSignUp.css";

const image = (name: string) => `/__mockup/images/${name}`;

export function MemoryPagesSignUp() {
  const [visible, setVisible] = useState(false);
  const [done, setDone] = useState(false);
  const [google, setGoogle] = useState(false);
  const submit = (event: FormEvent<HTMLFormElement>) => { event.preventDefault(); setDone(true); };

  return (
    <main className="memory-pages">
      <div className="memory-pages__paper">
        <header className="memory-pages__top">
          <a href="#back" className="memory-pages__back"><ArrowRight size={14} /> Back to Little Journal</a>
          <div className="memory-pages__brand"><Sparkles size={14} /> Little Journal</div>
          <span className="memory-pages__issue">No. 01 / private pages</span>
        </header>
        <section className="memory-pages__intro">
          <div>
            <p className="memory-pages__eyebrow">A place for the in-between</p>
            <h1>Keep the little<br /><em>things.</em></h1>
            <p className="memory-pages__lede">A private home for the details you never want to lose: Sunday light, voice notes, and the people who make a day brighter.</p>
          </div>
          <div className="memory-pages__stamp"><Heart size={16} fill="currentColor" /><span>made<br />for you</span></div>
        </section>
        <div className="memory-pages__ribbon">
          <div className="memory-pages__photo"><img src={image("journal-photo-besties.png")} alt="Two friends outdoors" /></div>
          <div className="memory-pages__cover"><img src={image("studio-scrap-journal-cover-11.png")} alt="Pink plaid journal cover" /></div>
          <span className="memory-pages__caption">your memories, in one soft place</span><b>★</b>
        </div>
        <section className="memory-pages__body">
          <aside className="memory-pages__promise"><i /><p><strong>Yours only.</strong><br />No feeds. No noise.<br />Just your pages.</p><div><LockKeyhole size={14} /></div></aside>
          <div className="memory-pages__card">
            <span className="memory-pages__tape" />
            <div className="memory-pages__heading"><div><small>Page one</small><h2>Start your journal</h2></div><span>01</span></div>
            <p className="memory-pages__subhead">A tiny collection of memories.</p>
            <form onSubmit={submit}>
              <button type="button" className="memory-pages__google" onClick={() => setGoogle(true)}><b>G</b>{google ? "Google sign-up selected" : "Continue with Google"}</button>
              <div className="memory-pages__or"><span>or use your email</span></div>
              <label>Email address<input type="email" placeholder="you@example.com" autoComplete="email" required /></label>
              <label>Password<span className="memory-pages__input"><input type={visible ? "text" : "password"} placeholder="Create a password" minLength={8} autoComplete="new-password" required /><button type="button" aria-label="Toggle password visibility" onClick={() => setVisible(!visible)}>{visible ? <EyeOff size={16} /> : <Eye size={16} />}</button></span></label>
              <button type="submit" className="memory-pages__submit">{done ? <><Check size={16} /> Your journal is ready</> : <>Open my journal <ArrowRight size={16} /></>}</button>
            </form>
            <p className="memory-pages__login">Already have an account? <a href="#sign-in">Sign in</a></p>
          </div>
        </section>
        <footer className="memory-pages__footer"><span>Take a moment. Make it yours.</span><span>Development mode · <a href="#privacy">Private by default</a></span></footer>
      </div>
    </main>
  );
}

export default MemoryPagesSignUp;