import { getAuth } from '@clerk/express';
import { db, journalObjectOwnersTable } from '@workspace/db';
import { eq } from 'drizzle-orm';
import express, {
  Router,
  type ErrorRequestHandler,
  type IRouter,
  type Request,
  type Response,
} from 'express';

import { getObjectAclPolicy, ObjectPermission } from '../lib/objectAcl';
import {
  ObjectNotFoundError,
  ObjectStorageService,
} from '../lib/objectStorage';

const router: IRouter = Router();
const objectStorageService = new ObjectStorageService();
const MAX_UPLOAD_SIZE_BYTES = 10 * 1024 * 1024;
const ALLOWED_IMAGE_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp']);

function userIdFrom(req: Request): string | null {
  return getAuth(req).userId ?? null;
}

function isPrivateUploadObjectPath(objectPath: string): boolean {
  return /^\/objects\/uploads\/[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
    objectPath,
  );
}

function contentTypeFrom(req: Request): string {
  return req.get('content-type')?.split(';')[0].trim().toLowerCase() ?? '';
}

function matchesImageMagicBytes(body: Buffer, contentType: string): boolean {
  if (contentType === 'image/jpeg') {
    return body.length >= 3 && body[0] === 0xff && body[1] === 0xd8 && body[2] === 0xff;
  }
  if (contentType === 'image/png') {
    return body.length >= 8 && body.subarray(0, 8).equals(
      Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    );
  }
  return body.length >= 12 &&
    body.subarray(0, 4).equals(Buffer.from('RIFF')) &&
    body.subarray(8, 12).equals(Buffer.from('WEBP'));
}

function validateUploadHeaders(req: Request, res: Response, next: () => void): void {
  if (!userIdFrom(req)) {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }
  if (!ALLOWED_IMAGE_TYPES.has(contentTypeFrom(req))) {
    res.status(415).json({ error: 'Photos must be JPEG, PNG, or WebP images' });
    return;
  }
  const contentLength = req.get('content-length');
  if (!contentLength || !/^\d+$/.test(contentLength)) {
    res.status(400).json({ error: 'A valid Content-Length header is required' });
    return;
  }
  const length = Number(contentLength);
  if (!Number.isSafeInteger(length) || length === 0) {
    res.status(400).json({ error: 'Photo upload must not be empty' });
    return;
  }
  if (length > MAX_UPLOAD_SIZE_BYTES) {
    res.status(413).json({ error: 'Photos must be no larger than 10MB' });
    return;
  }
  next();
}

router.post(
  '/storage/uploads',
  validateUploadHeaders,
  express.raw({ type: () => true, limit: MAX_UPLOAD_SIZE_BYTES }),
  async (req: Request, res: Response) => {
    const userId = userIdFrom(req);
    const contentType = contentTypeFrom(req);
    const body = req.body;
    if (!userId) {
      res.status(401).json({ error: 'Unauthorized' });
      return;
    }
    if (!Buffer.isBuffer(body) || body.length === 0) {
      res.status(400).json({ error: 'Photo upload must not be empty' });
      return;
    }
    if (body.length > MAX_UPLOAD_SIZE_BYTES) {
      res.status(413).json({ error: 'Photos must be no larger than 10MB' });
      return;
    }
    if (!matchesImageMagicBytes(body, contentType)) {
      res.status(415).json({ error: 'Photo contents do not match its image type' });
      return;
    }

    let objectPath: string | undefined;
    try {
      objectPath = await objectStorageService.uploadPrivateImage({
        body,
        contentType,
        ownerId: userId,
      });
      await db.insert(journalObjectOwnersTable).values({ objectPath, ownerId: userId });
      res.status(201).json({ objectPath });
    } catch (error) {
      if (objectPath) {
        try {
          await objectStorageService.deleteObjectEntity(objectPath);
        } catch (cleanupError) {
          req.log.error({ err: cleanupError, objectPath }, 'Error cleaning up unowned upload');
        }
      }
      req.log.error({ err: error }, 'Error saving photo upload');
      res.status(500).json({ error: 'Failed to save photo upload' });
    }
  },
);

const uploadBodyErrorHandler: ErrorRequestHandler = (error, req, res, next) => {
  if (
    req.path === '/storage/uploads' &&
    typeof error === 'object' &&
    error !== null &&
    'type' in error &&
    error.type === 'entity.too.large'
  ) {
    res.status(413).json({ error: 'Photos must be no larger than 10MB' });
    return;
  }
  next(error);
};
router.use(uploadBodyErrorHandler);

router.get(
  '/storage/public-objects/*filePath',
  async (req: Request, res: Response) => {
    try {
      const raw = req.params.filePath;
      const filePath = Array.isArray(raw) ? raw.join('/') : raw;
      const file = await objectStorageService.searchPublicObject(filePath);
      if (!file) {
        res.status(404).json({ error: 'File not found' });
        return;
      }

      const response = await objectStorageService.downloadObject(file);
      res.status(response.status);
      Object.entries(response.headers).forEach(([key, value]) =>
        res.setHeader(key, value),
      );
      response.stream.on('error', (error) => {
        req.log.error({ err: error }, 'Error streaming public object');
        if (res.headersSent) res.destroy(error);
        else res.status(500).json({ error: 'Failed to serve public object' });
      });
      response.stream.pipe(res);
    } catch (error) {
      req.log.error({ err: error }, 'Error serving public object');
      res.status(500).json({ error: 'Failed to serve public object' });
    }
  },
);

router.get('/storage/objects/*path', async (req: Request, res: Response) => {
  const userId = userIdFrom(req);
  if (!userId) {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }

  try {
    const raw = req.params.path;
    const wildcardPath = Array.isArray(raw) ? raw.join('/') : raw;
    const objectPath = `/objects/${wildcardPath}`;
    if (!isPrivateUploadObjectPath(objectPath)) {
      res.status(404).json({ error: 'Object not found' });
      return;
    }
    const objectFile = await objectStorageService.getObjectEntityFile(objectPath);
    const aclPolicy = await getObjectAclPolicy(objectFile);
    let canAccess = await objectStorageService.canAccessObjectEntity({
      userId,
      objectFile,
      requestedPermission: ObjectPermission.READ,
    });

    if (!aclPolicy && !canAccess) {
      const [ownership] = await db
        .select({ ownerId: journalObjectOwnersTable.ownerId })
        .from(journalObjectOwnersTable)
        .where(eq(journalObjectOwnersTable.objectPath, objectPath))
        .limit(1);
      if (ownership?.ownerId === userId) {
        await objectStorageService.trySetObjectEntityAclPolicy(objectPath, {
          owner: userId,
          visibility: 'private',
        });
        canAccess = true;
      }
    }
    if (!canAccess) {
      res.status(403).json({ error: 'Forbidden' });
      return;
    }

    const response = await objectStorageService.downloadObject(objectFile);
    res.status(response.status);
    Object.entries(response.headers).forEach(([key, value]) =>
      res.setHeader(key, value),
    );
    response.stream.on('error', (error) => {
      req.log.error({ err: error }, 'Error streaming private object');
      if (res.headersSent) res.destroy(error);
      else res.status(500).json({ error: 'Failed to serve object' });
    });
    response.stream.pipe(res);
  } catch (error) {
    if (error instanceof ObjectNotFoundError) {
      req.log.warn({ err: error }, 'Object not found');
      res.status(404).json({ error: 'Object not found' });
      return;
    }
    req.log.error({ err: error }, 'Error serving object');
    res.status(500).json({ error: 'Failed to serve object' });
  }
});

export default router;