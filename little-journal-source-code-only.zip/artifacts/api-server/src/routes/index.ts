import { Router, type IRouter } from "express";
import healthRouter from "./health";
import journalsRouter from "./journals";
import storageRouter from "./storage";

const router: IRouter = Router();

router.use(healthRouter);
router.use(journalsRouter);
router.use(storageRouter);

export default router;
