import { getAuth } from "@clerk/express";
import {
  GetCurrentJournalResponse,
  UpdateCurrentJournalBody,
  UpdateCurrentJournalResponse,
} from "@workspace/api-zod";
import { db, journalsTable } from "@workspace/db";
import { eq, isNull, lt, ne, or } from "drizzle-orm";
import { Router, type IRouter, type Request } from "express";

const router: IRouter = Router();

function userIdFrom(req: Request): string | null {
  const auth = getAuth(req);
  return auth.userId ?? null;
}

router.get("/journals/current", async (req, res): Promise<void> => {
  const ownerId = userIdFrom(req);
  if (!ownerId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const [journal] = await db
    .select()
    .from(journalsTable)
    .where(eq(journalsTable.ownerId, ownerId))
    .limit(1);

  if (!journal) {
    res.status(404).json({ error: "Journal not created" });
    return;
  }

  res.json(GetCurrentJournalResponse.parse(journal));
});

router.patch("/journals/current", async (req, res): Promise<void> => {
  const ownerId = userIdFrom(req);
  if (!ownerId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const parsed = UpdateCurrentJournalBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.message }, "Invalid journal update");
    res.status(400).json({ error: "Invalid journal data" });
    return;
  }

  const hasClientSaveId = parsed.data.clientSaveId !== undefined;
  const hasClientSaveSequence = parsed.data.clientSaveSequence !== undefined;
  if (hasClientSaveId !== hasClientSaveSequence) {
    res.status(400).json({
      error: "clientSaveId and clientSaveSequence must be provided together",
    });
    return;
  }

  const journalValues = {
    ownerId,
    title: parsed.data.title,
    coverStyle: parsed.data.coverStyle,
    pages: parsed.data.pages,
  };

  let journal;
  if (
    parsed.data.clientSaveId !== undefined &&
    parsed.data.clientSaveSequence !== undefined
  ) {
    const clientSaveId = parsed.data.clientSaveId;
    const clientSaveSequence = parsed.data.clientSaveSequence;
    [journal] = await db
      .insert(journalsTable)
      .values({
        ...journalValues,
        saveClientId: clientSaveId,
        saveSequence: clientSaveSequence,
      })
      .onConflictDoUpdate({
        target: journalsTable.ownerId,
        set: {
          title: parsed.data.title,
          coverStyle: parsed.data.coverStyle,
          pages: parsed.data.pages,
          saveClientId: clientSaveId,
          saveSequence: clientSaveSequence,
          updatedAt: new Date(),
        },
        setWhere: or(
          isNull(journalsTable.saveClientId),
          ne(journalsTable.saveClientId, clientSaveId),
          lt(journalsTable.saveSequence, clientSaveSequence),
        ),
      })
      .returning();
  } else {
    [journal] = await db
      .insert(journalsTable)
      .values(journalValues)
      .onConflictDoUpdate({
        target: journalsTable.ownerId,
        set: {
          title: parsed.data.title,
          coverStyle: parsed.data.coverStyle,
          pages: parsed.data.pages,
          updatedAt: new Date(),
        },
      })
      .returning();
  }

  if (!journal) {
    [journal] = await db
      .select()
      .from(journalsTable)
      .where(eq(journalsTable.ownerId, ownerId))
      .limit(1);
  }

  res.json(UpdateCurrentJournalResponse.parse(journal));
});

export default router;