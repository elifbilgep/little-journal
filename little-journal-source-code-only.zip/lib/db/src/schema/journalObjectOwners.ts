import { pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const journalObjectOwnersTable = pgTable("journal_object_owners", {
  objectPath: text("object_path").primaryKey(),
  ownerId: text("owner_id").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const insertJournalObjectOwnerSchema = createInsertSchema(
  journalObjectOwnersTable,
).omit({
  createdAt: true,
});
export type InsertJournalObjectOwner = z.infer<
  typeof insertJournalObjectOwnerSchema
>;
export type JournalObjectOwner = typeof journalObjectOwnersTable.$inferSelect;