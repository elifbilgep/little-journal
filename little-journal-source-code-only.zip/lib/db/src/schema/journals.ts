import {
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const journalsTable = pgTable(
  "journals",
  {
    id: serial("id").primaryKey(),
    ownerId: text("owner_id").notNull(),
    title: text("title").notNull().default("Little Journal"),
    coverStyle: text("cover_style").notNull().default("sage"),
    pages: jsonb("pages").$type<unknown[]>().notNull().default([]),
    saveClientId: text("save_client_id"),
    saveSequence: integer("save_sequence").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [uniqueIndex("journals_owner_id_unique").on(table.ownerId)],
);

export const insertJournalSchema = createInsertSchema(journalsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertJournal = z.infer<typeof insertJournalSchema>;
export type JournalRecord = typeof journalsTable.$inferSelect;